# Update notes — v0.3.4

Offline-world/build stability update. Includes wider OSM extract bounds, distributed sampling of building footprints across the map, a refreshed collision index after static scene colliders are registered, safe vehicle transition state handling, offline local asset checks in the build workflow, 2K procedural asphalt/plaster textures, roadside vegetation/pets, and separated HUD zones.

The OpenStreetMap extract and vendored Three.js are created by the included updated GitHub Actions workflow before Android packaging. This pass has static checks but has not been run on a physical Android device. Some previously discussed systems (real rigged characters, multiple drivable vehicle types, metro train, large-scale interiors/cinema movie) remain future work, detailed in `KOCHI_UPGRADE_NOTES.md`.


## v0.3.5 rendering/world-layer recovery
- Story missions now keep their mission-local scenery; real OpenStreetMap 3D geometry is enabled for Free Roam only.
- Separate collision bounds are restored when switching between story and mapped-world layers.
- Mission board initialization and per-frame gameplay updates are guarded so an error is logged and surfaced rather than silently leaving an unhelpful black frame.
