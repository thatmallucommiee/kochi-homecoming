# KOCHI: HOMECOMING — source update notes

## Modified files
- `www/game.js` — corrected vehicle yaw/world-translation sign mismatch across the prologue, free-roam and driving mission; adjustable steering sensitivity; larger bounded free-roam footprint; expanded traffic/pedestrian distribution; port district set dressing; fight-distance/world-coordinate fixes; procedural punch/block/dodge/hit/knockdown poses for the current pivot-based low-poly characters; local save/continue helpers; menu transitions and renderer quality setting.
- `www/index.html` — logo-led main menu; Continue/New Game/Load Game/Settings/Credits; Load panel; volume and graphics controls; Pause menu settings/main-menu option; small “MADE BY ASWIN MOHAN” footer in the main and pause/settings/credits panels.
- `www/style.css` — responsive cinematic menu/modal layouts, official-logo presentation and small-cap developer credit.
- `README.md` — architecture and limitations updated.

## Added files
- `www/audio.js` — looping main-menu audio, Android/browser playback-gesture handling, persistent master/music/SFX/ambience/mute settings, sensitivity/graphics preferences and missing-safe SFX hook.
- `www/assets/images/kochi-homecoming-logo.png` — exact supplied logo, unmodified (1536 × 1536).
- `www/assets/audio/rain-slicked_perimeter.mp3` — exact supplied theme track.
- `www/assets/audio/manifest.json` — source and rights caveat for the theme, with a transparent note that separate SFX were not supplied.

## Verified in this workspace
- JavaScript syntax check passed for `www/game.js` and `www/audio.js`.
- HTML parser check passed and found no duplicate element IDs.
- The logo/music/style/script paths referenced by the page exist in the archive.
- The source archive integrity check passed before delivery.
- Direction check: the car model's front faces local -Z; positive right-steer now rotates yaw negative and translates toward positive X, so visual heading and movement share the same convention.

## Not verified / incomplete
- No Android APK was compiled from this updated archive in this workspace; the existing GitHub Actions workflow must build it after this ZIP replaces the repository's root `Kochi_Playable_Android_Prototype.zip`.
- No on-device play test was possible here.
- The current player/NPC models are simple procedural low-poly meshes and the supplied Abraham GLB is hidden because the source says it is not a matching rigged character. Combat has responsive pivot poses/state timing, but **no genuine compatible skeletal combat clips or motion-capture assets were integrated**.
- The only supplied audio file is the menu theme. The latest patch synthesizes limited weapon/impact transients in Web Audio; separate recorded footsteps, engine loops, horns and location ambiences are still not bundled.
- The latest patch adds basic rectangular collision footprints for Free Roam buildings/containers; it is not a full collision system for every prop or story set piece. The expanded street grid and port remain procedural scenery, not a fully authored GTA-scale world.
- The supplied menu track's publication/commercial rights still need developer confirmation.


## October map, combat and bug-fix pass

- `www/index.html` adds the full-screen interactive city map, OpenStreetMap attribution, minimap open button, radial weapon selector, and Free Roam on-foot weapon/reload/fire controls.
- `www/game.js` adds an online MapLibre/OpenStreetMap view, player/target markers, follow toggle, map panning/zooming/rotation, heading-up local radar, a four-slot weapon wheel, pistol/SMG/shotgun ammunition, raycast NPC hits, tracers, wanted response, better third-person shot direction, nearby Free Roam test pedestrians, basic static collision footprints for major buildings/containers, and safer vehicle exit placement. It also hides detached weapon HUD elements during pause and side-job menus.
- `www/audio.js` adds small Web Audio generated weapon and impact transients so the new weapon actions are not silent without a supplied SFX pack.
- `www/style.css` styles the map, minimap control, reticle, weapon wheel and HUD.

### Limitations to keep clear
- The full-screen city map displays real OpenStreetMap streets. The 3D game city remains procedurally generated. Player/target geographic pins are approximate and are not GPS, precise route navigation, or proof that game roads line up with real-world roads. Internet is required for the map tiles and the app's current CDN-loaded libraries.
- Weapons are available only in Free Roam on foot. Story missions, including Rafi's garage fight, remain unarmed to preserve the story.
- The collision update is a simple set of rectangular footprints for major buildings and shipping containers; it is not a complete collision mesh for every object.
- JavaScript syntax, HTML IDs, local asset paths and ZIP integrity can be checked here. The Android UI and touch controls still require actual device testing; a local browser smoke test was blocked by this environment's loopback policy.
