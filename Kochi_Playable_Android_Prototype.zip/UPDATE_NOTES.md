# KOCHI: HOMECOMING — source update notes

## Modified files
- `www/game.js` — corrected vehicle yaw/world-translation sign mismatch across the prologue, free-roam and driving mission; adjustable steering sensitivity; larger bounded free-roam footprint; expanded traffic/pedestrian distribution; port district set dressing; fight-distance/world-coordinate fixes; procedural punch/block/dodge/hit/knockdown poses for the current pivot-based low-poly characters; local save/continue helpers; menu transitions and renderer quality setting.
- `www/index.html` — logo-led main menu; Continue/New Game/Load Game/Settings/Credits; Load panel; volume and graphics controls; Pause menu settings/main-menu option; small “MADE BY ASWIN MOHAN” footer in the main and pause/settings/credits panels.
- `www/style.css` — responsive cinematic menu/modal layouts, official-logo presentation and small-cap developer credit.
- `README.md` — architecture and limitations updated.

## Added files
- `www/audio.js` — looping main-menu audio, Android/browser playback-gesture handling, persistent master/music/SFX/ambience/mute settings, sensitivity/graphics preferences and missing-safe SFX hook.
- `www/assets/images/kochi-homecoming-logo.png` — exact supplied logo, unmodified (1536 × 1536).
- `www/assets/audio/rain-slicked_perimeter.mp3` — exact supplied theme track.
- `www/assets/audio/manifest.json` — source and rights caveat for the theme, with a transparent note that separate SFX were not supplied.

## Verified in this workspace
- JavaScript syntax check passed for `www/game.js` and `www/audio.js`.
- HTML parser check passed and found no duplicate element IDs.
- The logo/music/style/script paths referenced by the page exist in the archive.
- The source archive integrity check passed before delivery.
- Direction check: the car model's front faces local -Z; positive right-steer now rotates yaw negative and translates toward positive X, so visual heading and movement share the same convention.

## Not verified / incomplete
- No Android APK was compiled from this updated archive in this workspace; the existing GitHub Actions workflow must build it after this ZIP replaces the repository's root `Kochi_Playable_Android_Prototype.zip`.
- No on-device play test was possible here.
- The current player/NPC models are simple procedural low-poly meshes and the supplied Abraham GLB is hidden because the source says it is not a matching rigged character. Combat has responsive pivot poses/state timing, but **no genuine compatible skeletal combat clips or motion-capture assets were integrated**.
- The only uploaded audio asset was the menu theme. Separate footsteps, engine loops, collisions, fight impacts, horns and location ambiences are not bundled, so no such SFX are claimed as integrated. The audio manager has volume control and a missing-safe effect hook, but the SFX mix remains incomplete.
- There is no building/world collision system. The expanded street grid and port are larger, bounded, procedural scenery, not a fully authored GTA-scale world.
- The supplied menu track's publication/commercial rights still need developer confirmation.
