(() => {
  const STORAGE_KEY = 'kochiHomecoming.settings.v1';
  const defaults = { master: 0.8, music: 0.7, sfx: 0.8, ambient: 0.65, muted: false, sensitivity: 0.85, graphics: 'balanced' };
  let settings = { ...defaults };
  try { settings = { ...settings, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') }; } catch (_) {}
  const theme = new Audio('assets/audio/rain-slicked_perimeter.mp3');
  theme.loop = true; theme.preload = 'auto'; theme.setAttribute('aria-label', 'Main menu theme');
  let menuActive = true, playRequested = false;
  const $ = id => document.getElementById(id);
  function save() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(settings)); } catch (_) {} }
  function refresh() {
    theme.volume = Math.max(0, Math.min(1, Number(settings.master) * Number(settings.music)));
    theme.muted = !!settings.muted;
    for (const [id, key] of [['master-volume','master'],['music-volume','music'],['sfx-volume','sfx'],['ambient-volume','ambient'],['steering-sensitivity','sensitivity']]) {
      if ($(id)) $(id).value = String(settings[key]);
      const out = $(key === 'master' ? 'master-value' : key === 'music' ? 'music-value' : key === 'sfx' ? 'sfx-value' : key === 'ambient' ? 'ambient-value' : 'sensitivity-value');
      if (out) out.textContent = `${Math.round(Number(settings[key]) * 100)}%`;
    }
    if ($('graphics-quality')) $('graphics-quality').value = settings.graphics;
    const label = settings.muted ? 'MUSIC: OFF' : 'MUSIC: ON';
    if ($('music-toggle')) { $('music-toggle').textContent = label; $('music-toggle').setAttribute('aria-pressed', String(settings.muted)); }
    if ($('settings-mute')) $('settings-mute').textContent = settings.muted ? 'UNMUTE MUSIC' : 'MUTE MUSIC';
    if (window.KochiApplyGraphics) window.KochiApplyGraphics(settings.graphics);
  }
  async function syncPlayback() {
    theme.volume = Math.max(0, Math.min(1, Number(settings.master) * Number(settings.music)));
    theme.muted = !!settings.muted;
    if (menuActive && !settings.muted) {
      playRequested = true;
      try { await theme.play(); } catch (err) { /* Android/browser may require a user gesture; retry on the next menu interaction. */ }
    } else theme.pause();
  }
  function set(key, value) { if (!(key in settings)) return; settings[key] = value; save(); refresh(); syncPlayback(); }
  function toggleMute() { set('muted', !settings.muted); }
  window.KochiAudio = {
    setMenuActive(active) { menuActive = !!active; if (!menuActive) theme.pause(); else syncPlayback(); },
    toggleMute, set,
    getSettings() { return { ...settings }; },
    isMenuActive() { return menuActive; },
    // Missing sound assets are deliberately silent. No fake beeps are substituted.
    playSfx(name, options = {}) { const path = options.src; if (!path) { console.warn(`KOCHI audio: no supplied SFX asset for event "${name}"`); return false; } const a = new Audio(path); a.volume = Math.max(0, Math.min(1, settings.master * settings.sfx * (options.volume ?? 1))); a.play().catch(()=>{}); return true; }
  };
  document.addEventListener('pointerdown', () => { if (menuActive && !settings.muted) syncPlayback(); }, true);
  document.addEventListener('visibilitychange', () => { if (document.hidden) theme.pause(); else if (menuActive) syncPlayback(); });
  window.addEventListener('pagehide', () => theme.pause());
  for (const [id,key] of [['master-volume','master'],['music-volume','music'],['sfx-volume','sfx'],['ambient-volume','ambient'],['steering-sensitivity','sensitivity']]) {
    if ($(id)) $(id).addEventListener('input', e => set(key, Number(e.target.value)));
  }
  if ($('graphics-quality')) $('graphics-quality').addEventListener('change', e => set('graphics', e.target.value));
  if ($('music-toggle')) $('music-toggle').addEventListener('click', toggleMute);
  if ($('settings-mute')) $('settings-mute').addEventListener('click', toggleMute);
  function showPanel(id) { for (const other of ['settings-panel','credits-panel','load-panel']) $(other)?.classList.add('hidden'); $(id)?.classList.remove('hidden'); }
  function hidePanel(id) { $(id)?.classList.add('hidden'); }
  $('settings-open')?.addEventListener('click',()=>showPanel('settings-panel'));
  $('pause-settings-open')?.addEventListener('click',()=>showPanel('settings-panel'));
  $('settings-close')?.addEventListener('click',()=>hidePanel('settings-panel'));
  $('credits-open')?.addEventListener('click',()=>showPanel('credits-panel'));
  $('credits-close')?.addEventListener('click',()=>hidePanel('credits-panel'));
  $('load-game')?.addEventListener('click',()=>{ showPanel('load-panel'); const data=window.KochiGame?.readSave?.(); $('save-summary').textContent=data ? `Latest save · ${data.status==='complete'?'ready to continue':'mission in progress'} · ${data.missionTitle || 'Act I'} · ${new Date(data.savedAt||Date.now()).toLocaleString()}` : 'No saved progress found yet. Start a new game to create a save.'; $('load-saved-game').disabled=!data; });
  $('load-cancel')?.addEventListener('click',()=>hidePanel('load-panel'));
  $('load-saved-game')?.addEventListener('click',()=>{hidePanel('load-panel');window.KochiGame?.continueGame?.();});
  refresh(); syncPlayback();
})();
