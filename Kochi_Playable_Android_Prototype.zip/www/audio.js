(() => {
  const STORAGE_KEY = 'kochiHomecoming.settings.v1';
  const defaults = { master: 0.8, music: 0.7, sfx: 0.8, ambient: 0.65, muted: false, sensitivity: 0.85, graphics: 'balanced' };
  let settings = { ...defaults };
  try { settings = { ...settings, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') }; } catch (_) {}
  const theme = new Audio('assets/audio/rain-slicked_perimeter.mp3');
  theme.loop = true; theme.preload = 'auto'; theme.setAttribute('aria-label', 'Main menu theme');
  let menuActive = true, playRequested = false, sfxContext = null;
  let engineOsc = null, engineFilter = null, engineGain = null, roadNoiseGain = null, ambientNoiseGain = null, roadNoiseSource = null, ambientNoiseSource = null, nextFootstepAt = 0;
  const $ = id => document.getElementById(id);
  function save() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(settings)); } catch (_) {} }
  function synthTransient(type, variant) {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    try {
      sfxContext ||= new AudioContext();
      const ctx = sfxContext;
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      const now = ctx.currentTime;
      const weapon = type === 'weapon';
      const duration = weapon ? ({smg:.075, shotgun:.19, pistol:.12}[variant] || .12) : .085;
      const level = Math.max(0, Math.min(1, Number(settings.master) * Number(settings.sfx)));
      if (level < .005) return;
      const buffer = ctx.createBuffer(1, Math.max(1, Math.floor(ctx.sampleRate * duration)), ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        const fade = 1 - i / data.length;
        data[i] = (Math.random() * 2 - 1) * fade * (weapon ? (variant === 'shotgun' ? 1 : .75) : .5);
      }
      const noise = ctx.createBufferSource(); noise.buffer = buffer;
      const filter = ctx.createBiquadFilter(); filter.type = weapon ? 'bandpass' : 'lowpass';
      filter.frequency.setValueAtTime(weapon ? (variant === 'shotgun' ? 650 : variant === 'smg' ? 1450 : 1050) : 420, now);
      filter.Q.value = weapon ? .72 : .8;
      const gain = ctx.createGain(); gain.gain.setValueAtTime(.0001, now);
      gain.gain.linearRampToValueAtTime((weapon ? (variant === 'shotgun' ? .46 : .34) : .22) * level, now + .004);
      gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
      noise.connect(filter); filter.connect(gain); gain.connect(ctx.destination); noise.start(now); noise.stop(now + duration);
      if (weapon) {
        const osc = ctx.createOscillator(), body = ctx.createGain();
        osc.type = 'triangle'; osc.frequency.setValueAtTime(variant === 'shotgun' ? 92 : 118, now);
        osc.frequency.exponentialRampToValueAtTime(42, now + duration * .85);
        body.gain.setValueAtTime(.0001, now); body.gain.linearRampToValueAtTime((variant === 'shotgun' ? .26 : .16) * level, now + .003);
        body.gain.exponentialRampToValueAtTime(.0001, now + duration);
        osc.connect(body); body.connect(ctx.destination); osc.start(now); osc.stop(now + duration);
      }
    } catch (error) { console.warn('KOCHI audio: procedural effect unavailable', error); }
  }
  function ensureWorldAudio() {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return false;
    sfxContext ||= new Ctx();
    const ctx = sfxContext;
    if (ctx.state !== 'running') return false;
    if (!engineOsc) {
      engineOsc = ctx.createOscillator(); engineOsc.type = 'sawtooth';
      engineFilter = ctx.createBiquadFilter(); engineFilter.type = 'lowpass'; engineFilter.frequency.value = 170;
      engineGain = ctx.createGain(); engineGain.gain.value = .0001;
      engineOsc.connect(engineFilter); engineFilter.connect(engineGain); engineGain.connect(ctx.destination); engineOsc.start();
      const createNoiseBed = (kind, filterType, freq, gainValue) => {
        const buffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate), data = buffer.getChannelData(0);
        for (let i=0;i<data.length;i++) data[i]=(Math.random()*2-1)*.3;
        const source=ctx.createBufferSource();source.buffer=buffer;source.loop=true;
        const filter=ctx.createBiquadFilter();filter.type=filterType;filter.frequency.value=freq;
        const gain=ctx.createGain();gain.gain.value=.0001;source.connect(filter);filter.connect(gain);gain.connect(ctx.destination);source.start();
        return {source,gain,kind,gainValue};
      };
      const road=createNoiseBed('road','lowpass',260,.035);roadNoiseSource=road.source;roadNoiseGain=road.gain;
      const city=createNoiseBed('city','bandpass',680,.012);ambientNoiseSource=city.source;ambientNoiseGain=city.gain;
    }
    return true;
  }
  function updateWorldAudio(state = {}) {
    const ctx=sfxContext;if (!ctx || ctx.state !== 'running' || !ensureWorldAudio()) return;
    const now=ctx.currentTime,vol=Math.max(0,Math.min(1,Number(settings.master)*Number(settings.ambient)));
    const speed=Math.max(0,Math.min(220,Number(state.speed)||0));
    const engineLevel=state.driving ? vol*(.018+Math.min(speed/160,.12)+(state.accelerating?.025:0)) : .0001;
    engineOsc.frequency.setTargetAtTime(48+speed*.85+(state.accelerating?18:0),now,.08);
    engineFilter.frequency.setTargetAtTime(125+speed*3.2+(state.accelerating?240:0),now,.1);
    engineGain.gain.setTargetAtTime(engineLevel,now,.12);
    roadNoiseGain.gain.setTargetAtTime(state.driving?vol*(.006+speed*.00018):.0001,now,.18);
    ambientNoiseGain.gain.setTargetAtTime(state.ambient?vol*.035:.0001,now,.4);
  }
  function playFootstepIfDue(sprinting=false) {
    const ctx=sfxContext;if(!ctx||ctx.state!=='running')return;
    const now=ctx.currentTime;if(now<nextFootstepAt)return;
    nextFootstepAt=now+(sprinting?.29:.43);synthTransient('impact','footstep');
  }
  function refresh() {
    theme.volume = Math.max(0, Math.min(1, Number(settings.master) * Number(settings.music)));
    theme.muted = !!settings.muted;
    for (const [id, key] of [['master-volume','master'],['music-volume','music'],['sfx-volume','sfx'],['ambient-volume','ambient'],['steering-sensitivity','sensitivity']]) {
      if ($(id)) $(id).value = String(settings[key]);
      const out = $(key === 'master' ? 'master-value' : key === 'music' ? 'music-value' : key === 'sfx' ? 'sfx-value' : key === 'ambient' ? 'ambient-value' : 'sensitivity-value');
      if (out) out.textContent = `${Math.round(Number(settings[key]) * 100)}%`;
    }
    if ($('graphics-quality')) $('graphics-quality').value = settings.graphics;
    const label = settings.muted ? 'MUSIC: OFF' : 'MUSIC: ON';
    if ($('music-toggle')) { $('music-toggle').textContent = label; $('music-toggle').setAttribute('aria-pressed', String(settings.muted)); }
    if ($('settings-mute')) $('settings-mute').textContent = settings.muted ? 'UNMUTE MUSIC' : 'MUTE MUSIC';
    if (window.KochiApplyGraphics) window.KochiApplyGraphics(settings.graphics);
  }
  async function syncPlayback() {
    theme.volume = Math.max(0, Math.min(1, Number(settings.master) * Number(settings.music)));
    theme.muted = !!settings.muted;
    if (menuActive && !settings.muted) {
      playRequested = true;
      try { await theme.play(); } catch (err) { /* Android/browser may require a user gesture; retry on the next menu interaction. */ }
    } else theme.pause();
  }
  function set(key, value) { if (!(key in settings)) return; settings[key] = value; save(); refresh(); syncPlayback(); }
  function toggleMute() { set('muted', !settings.muted); }
  window.KochiAudio = {
    setMenuActive(active) { menuActive = !!active; if (!menuActive) theme.pause(); else syncPlayback(); },
    toggleMute, set,
    getSettings() { return { ...settings }; },
    isMenuActive() { return menuActive; },
    // Supplied audio files take priority. Weapon and impact effects also have a compact
    // synthesised fallback so the playable prototype is not silent when no SFX pack exists.
    playSfx(name, options = {}) { const path = options.src; if (!path) { console.warn(`KOCHI audio: no supplied SFX asset for event \"${name}\"`); return false; } const a = new Audio(path); a.volume = Math.max(0, Math.min(1, settings.master * settings.sfx * (options.volume ?? 1))); a.play().catch(()=>{}); return true; },
    playWeaponSfx(weapon = 'pistol') { synthTransient('weapon', weapon); },
    playImpactSfx(kind = 'punch') { synthTransient('impact', kind); },
    updateWorldAudio, playFootstepIfDue
  };
  document.addEventListener('pointerdown', () => { const Ctx=window.AudioContext||window.webkitAudioContext;if(Ctx){sfxContext ||= new Ctx();if(sfxContext.state==='suspended')sfxContext.resume().catch(()=>{});}if (menuActive && !settings.muted) syncPlayback(); }, true);
  document.addEventListener('visibilitychange', () => { if (document.hidden) theme.pause(); else if (menuActive) syncPlayback(); });
  window.addEventListener('pagehide', () => theme.pause());
  for (const [id,key] of [['master-volume','master'],['music-volume','music'],['sfx-volume','sfx'],['ambient-volume','ambient'],['steering-sensitivity','sensitivity']]) {
    if ($(id)) $(id).addEventListener('input', e => set(key, Number(e.target.value)));
  }
  if ($('graphics-quality')) $('graphics-quality').addEventListener('change', e => set('graphics', e.target.value));
  if ($('music-toggle')) $('music-toggle').addEventListener('click', toggleMute);
  if ($('settings-mute')) $('settings-mute').addEventListener('click', toggleMute);
  function showPanel(id) { for (const other of ['settings-panel','credits-panel','load-panel']) $(other)?.classList.add('hidden'); $(id)?.classList.remove('hidden'); }
  function hidePanel(id) { $(id)?.classList.add('hidden'); }
  $('settings-open')?.addEventListener('click',()=>showPanel('settings-panel'));
  $('pause-settings-open')?.addEventListener('click',()=>showPanel('settings-panel'));
  $('settings-close')?.addEventListener('click',()=>hidePanel('settings-panel'));
  $('credits-open')?.addEventListener('click',()=>showPanel('credits-panel'));
  $('credits-close')?.addEventListener('click',()=>hidePanel('credits-panel'));
  $('load-game')?.addEventListener('click',()=>{ showPanel('load-panel'); const data=window.KochiGame?.readSave?.(); $('save-summary').textContent=data ? `Latest save · ${data.status==='complete'?'ready to continue':'mission in progress'} · ${data.missionTitle || 'Act I'} · ${new Date(data.savedAt||Date.now()).toLocaleString()}` : 'No saved progress found yet. Start a new game to create a save.'; $('load-saved-game').disabled=!data; });
  $('load-cancel')?.addEventListener('click',()=>hidePanel('load-panel'));
  $('load-saved-game')?.addEventListener('click',()=>{hidePanel('load-panel');window.KochiGame?.continueGame?.();});
  refresh(); syncPlayback();
})();
