import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const host=document.querySelector('#game');
const scene=new THREE.Scene(); scene.background=new THREE.Color(0x9aa9a1); scene.fog=new THREE.Fog(0x9aa9a1,34,145);
const camera=new THREE.PerspectiveCamera(62,innerWidth/innerHeight,.1,250);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;host.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xd9e7ed,0x655444,2.0));
const sun=new THREE.DirectionalLight(0xffd4a0,2.5);sun.position.set(-20,35,10);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-45;sun.shadow.camera.right=45;sun.shadow.camera.top=45;sun.shadow.camera.bottom=-45;scene.add(sun);
const mat=(color,roughness=.9)=>new THREE.MeshStandardMaterial({color,roughness});
const materials={ground:mat(0x5e6a4c),road:mat(0x333a3a),line:mat(0xd7c7a0),wall:mat(0xc4ad8b),white:mat(0xd7d0bd),blue:mat(0x5d777b),red:mat(0x8b4b3d),roof:mat(0x514b3e),leaf:mat(0x315c3d),trunk:mat(0x624832),glass:new THREE.MeshStandardMaterial({color:0x8ba8a6,metalness:.2,roughness:.25}),dark:mat(0x1e2422),skin:mat(0x9a6747),shirt:mat(0xb8b4a1),pants:mat(0x343a3b),car:mat(0x343b3a),rust:mat(0x76503a)};
function box(parent,x,y,z,w,h,d,m){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o}
function cylinder(parent,x,y,z,r1,r2,h,m,segments=8){const o=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,h,segments),m);o.position.set(x,y,z);o.castShadow=true;parent.add(o);return o}
const ground= new THREE.Mesh(new THREE.PlaneGeometry(220,220),materials.ground);ground.rotation.x=-Math.PI/2;ground.position.y=-.08;ground.receiveShadow=true;scene.add(ground);
// Small coastal street grid
box(scene,0,.005,0,13,.03,180,materials.road);box(scene,0,.025,0,.13,.02,180,materials.line);
box(scene,0,.006,0,180,.03,12,materials.road);
for(let i=-80;i<90;i+=8){box(scene,0,.045,i,.12,.012,2.5,materials.line);box(scene,i,.045,0,2.5,.012,.12,materials.line)}
function palm(x,z,h=6){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);cylinder(g,0,h/2,0,.17,.28,h,materials.trunk,7);for(let i=0;i<7;i++){const a=i*Math.PI*2/7;const leaf=box(g,Math.cos(a)*1.05,h+.08,Math.sin(a)*1.05,2.5,.09,.35,materials.leaf);leaf.rotation.y=-a;leaf.rotation.z=Math.cos(a)*-.35;}cylinder(g,0,h,0,.22,.22,.3,materials.leaf,8)}
function building(x,z,w,d,h,m,shop=false){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);box(g,0,h/2,0,w,h,d,m);box(g,0,h+.15,0,w+.35,.3,d+.35,materials.roof);const floors=Math.max(1,Math.floor(h/2.4));for(let f=0;f<floors;f++)for(let xx=-w/2+.8;xx<w/2-.4;xx+=1.8){box(g,xx,1.2+f*2.35,d/2+.015,.72,1.0,.04,materials.glass);box(g,xx,1.2+f*2.35,d/2+.05,.78,.08,.06,materials.dark)}if(shop){box(g,0,1.2,d/2+.08,w*.65,1.35,.08,materials.dark);box(g,0,2.05,d/2+.13,w*.75,.28,.12,materials.rust)}return g}
building(-12,-10,8,8,7,materials.wall);building(-14,4,6,7,5,materials.white,true);building(12,-12,8,8,9,materials.blue);building(14,4,7,7,5,materials.wall,true);building(-13,16,7,7,6,materials.red);building(13,17,8,8,7,materials.white);building(-21,-1,7,9,10,materials.white);building(22,0,7,8,8,materials.blue);
for(const [x,z] of [[-8,-19],[8,-18],[-9,13],[9,13],[-23,12],[23,12],[-20,-13],[20,-14],[-8,24],[8,25]])palm(x,z,5+Math.random()*2);
// garage
const garage=building(-5,-7,8,6,4.4,materials.roof,true);box(scene,-5,1.3,-3.94,4.8,2.5,.15,materials.dark);box(scene,-5,2.65,-4.02,5,.22,.15,materials.rust);
// Player mesh: intentionally stylized but proportioned, with head/torso/legs rather than cubes
const player=new THREE.Group();scene.add(player);
const body=new THREE.Group();player.add(body);
cylinder(body,0,1.22,0,.28,.32,.72,materials.shirt,10);
const head=new THREE.Mesh(new THREE.SphereGeometry(.22,12,10),materials.skin);head.position.y=1.78;head.castShadow=true;body.add(head);
const hair=new THREE.Mesh(new THREE.SphereGeometry(.225,12,8,0,Math.PI*2,0,Math.PI*.55),materials.dark);hair.position.y=1.84;body.add(hair);
for(const s of [-1,1]){const leg=box(body,s*.13,.48,0,.16,.72,.18,materials.pants);leg.position.z=0;const arm=box(body,s*.36,1.24,0,.13,.62,.14,materials.skin);arm.rotation.z=s*-.12}
player.position.set(1,0,7);
// Damaged sedan
const car=new THREE.Group();car.position.set(-5,0,-1.5);car.rotation.y=Math.PI;scene.add(car);
box(car,0,.55,0,1.9,.55,3.6,materials.car);box(car,0,1.0,-.2,1.55,.62,1.7,materials.glass);box(car,0,.95,1.25,1.6,.22,.75,materials.rust);
for(const x of [-.98,.98])for(const z of [-1.1,1.1]){const wh=cylinder(car,x,.32,z,.31,.31,.18,materials.dark,12);wh.rotation.z=Math.PI/2;const hub=cylinder(car,x*1.01,.32,z,.14,.14,.19,materials.line,10);hub.rotation.z=Math.PI/2}
box(car,-.45,.46,-1.85,.3,.14,.05,materials.rust);box(car,.45,.46,-1.85,.3,.14,.05,materials.rust);
const clue=new THREE.Mesh(new THREE.SphereGeometry(.24,12,8),new THREE.MeshBasicMaterial({color:0xf4b866}));clue.position.set(-4.2,.9,-3.7);scene.add(clue);
// distant water beyond town
const water=new THREE.Mesh(new THREE.PlaneGeometry(220,80),new THREE.MeshStandardMaterial({color:0x526f76,roughness:.3,metalness:.1}));water.rotation.x=-Math.PI/2;water.position.set(0,-.02,-85);scene.add(water);
let started=false,inCar=false,run=false,driveSpeed=0,toastTimer=0,found=false;
const toast=document.querySelector('#toast'),hint=document.querySelector('#hint'),objective=document.querySelector('#objective');
function message(s){toast.textContent=s;toast.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.add('hidden'),3400)}
document.querySelector('#begin').onclick=()=>{started=true;document.querySelector('#storycard').classList.add('hidden');document.querySelector('#loading').style.opacity=0;setTimeout(()=>document.querySelector('#loading').remove(),650);message('MG Road outskirts · Find Abraham’s car');};
const stick=document.querySelector('#stick'),nub=document.querySelector('#nub');let moveX=0,moveY=0,stickId=null;
function setStick(e){const r=stick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const max=40,len=Math.hypot(dx,dy)||1;if(len>max){dx=dx/len*max;dy=dy/len*max}moveX=dx/max;moveY=dy/max;nub.style.left=(34+dx)+'px';nub.style.top=(34+dy)+'px'}
stick.addEventListener('pointerdown',e=>{stickId=e.pointerId;stick.setPointerCapture(stickId);setStick(e)});stick.addEventListener('pointermove',e=>{if(e.pointerId===stickId)setStick(e)});function release(){stickId=null;moveX=moveY=0;nub.style.left='34px';nub.style.top='34px'}stick.addEventListener('pointerup',release);stick.addEventListener('pointercancel',release);
document.querySelector('#run').onpointerdown=()=>run=true;document.querySelector('#run').onpointerup=()=>run=false;document.querySelector('#run').onpointercancel=()=>run=false;
function nearCar(){return player.position.distanceTo(car.position)<3.6}
function interact(){if(!started)return;if(inCar){inCar=false;player.position.x=car.position.x+2;player.position.z=car.position.z;document.querySelector('#enter').classList.remove('hidden');document.querySelector('#drive-controls').classList.add('hidden');message('You step out beside the car.');return}
if(nearCar()){if(!found){found=true;objective.innerHTML='OBJECTIVE<br><strong>Clue discovered</strong>';message('Brake line severed. This was not an ordinary accident. Someone wanted Abraham dead.');hint.textContent='Clue found. The reason is still unknown.';clue.visible=false}else message('The brake line is cut clean through. Someone tampered with the car.');return}
if(player.position.distanceTo(new THREE.Vector3(-5,0,-7))<5)message('A closed garage. Rafi may know more, but he is not here yet.');
else message('Nothing useful here. Keep looking around the street.')}
document.querySelector('#interact').onclick=interact;
document.querySelector('#enter').onclick=()=>{if(nearCar()){inCar=true;document.querySelector('#enter').classList.add('hidden');document.querySelector('#drive-controls').classList.remove('hidden');message('You take the wheel. Drive carefully.')}else message('Move closer to Abraham’s car first.')};
document.querySelector('#exit').onclick=()=>{inCar=false;player.position.x=car.position.x+2;player.position.z=car.position.z;document.querySelector('#enter').classList.remove('hidden');document.querySelector('#drive-controls').classList.add('hidden')};
document.querySelector('#brake').onpointerdown=()=>driveSpeed*=.3;
addEventListener('keydown',e=>{if(e.key==='e')interact();if(e.key==='Shift')run=true});addEventListener('keyup',e=>{if(e.key==='Shift')run=false});
const clock=new THREE.Clock();
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);
if(started){if(inCar){driveSpeed+=(moveY<-.1?.14:moveY>.1?-.19:0)*dt*60;driveSpeed*=.985;car.position.x+=Math.sin(car.rotation.y)*driveSpeed*dt*8;car.position.z+=Math.cos(car.rotation.y)*driveSpeed*dt*8;car.rotation.y-=moveX*dt*driveSpeed*1.2;player.position.copy(car.position)}else{const speed=(run?5.4:3.2)*dt;const forward=new THREE.Vector3(Math.sin(camera.rotation.y),0,Math.cos(camera.rotation.y));const right=new THREE.Vector3(forward.z,0,-forward.x);player.position.addScaledVector(forward,-moveY*speed);player.position.addScaledVector(right,moveX*speed);player.position.x=THREE.MathUtils.clamp(player.position.x,-31,31);player.position.z=THREE.MathUtils.clamp(player.position.z,-33,34);if(Math.abs(moveX)+Math.abs(moveY)>.1)player.rotation.y=Math.atan2(moveX,-moveY)+camera.rotation.y}
}
const target=inCar?car.position:player.position;const desired=new THREE.Vector3(target.x+Math.sin(player.rotation.y)*7,target.y+4.4,target.z+Math.cos(player.rotation.y)*7);camera.position.lerp(desired,.09);camera.lookAt(target.x,target.y+1.0,target.z);
if(started&&!inCar&&nearCar()){hint.textContent=found?'Clue found · Inspect the car again':'Abraham’s damaged car · Tap INSPECT';}else if(started&&!inCar){hint.textContent='Explore the street. Find the damaged car near the garage.'}
clue.position.y=.9+Math.sin(performance.now()*.003)*.13;renderer.render(scene,camera)}
camera.position.set(1,4,14);camera.lookAt(0,0,0);animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
