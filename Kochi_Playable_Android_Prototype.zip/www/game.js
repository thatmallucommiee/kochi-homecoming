import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
// This file is loaded locally in Capacitor. The build pipeline downloads OSM data once and
// packages it in the APK; gameplay itself does not make any network requests.
let offlineKochiData={features:[],attribution:'OpenStreetMap data unavailable in this source-only preview'};
try{const mapResponse=await fetch('./assets/data/kochi-map.json',{cache:'no-store'});if(mapResponse.ok){const candidate=await mapResponse.json();if(Array.isArray(candidate.features)&&candidate.features.length>50)offlineKochiData=candidate;}}catch(err){console.warn('Local Kochi map not packaged; fallback district will be used.',err)}
const host=document.querySelector('#game');
// Prevent Android WebView's native text-copy menu from appearing over the game HUD.
document.addEventListener('contextmenu', event => event.preventDefault());

const scene=new THREE.Scene();scene.background=new THREE.Color(0x11191e);scene.fog=new THREE.FogExp2(0x11191e,.00105);
const camera=new THREE.PerspectiveCamera(58,innerWidth/innerHeight,.1,3600);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;host.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0x9aafc0,0x211a16,1.15));const moon=new THREE.DirectionalLight(0x9eb7ce,1.2);moon.position.set(-15,22,9);moon.castShadow=true;moon.shadow.mapSize.set(1024,1024);scene.add(moon);
const amber=new THREE.PointLight(0xffa15c,23,25,2);amber.position.set(4,4,-13);scene.add(amber);const redLight=new THREE.PointLight(0xf12d23,16,16,2);redLight.position.set(-5,2,-20);scene.add(redLight);
const mat=(c,r=.86,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
function makeTiledTexture(kind){
 const size=1024,c=document.createElement('canvas');c.width=c.height=size;const x=c.getContext('2d');
 if(kind==='asphalt'){
  x.fillStyle='#343a3b';x.fillRect(0,0,size,size);
  for(let i=0;i<36000;i++){const v=30+Math.random()*65,a=.04+Math.random()*.18;x.fillStyle=`rgba(${v},${v+2},${v+3},${a})`;const w=.5+Math.random()*2.4;x.fillRect(Math.random()*size,Math.random()*size,w,w)}
  for(let i=0;i<75;i++){x.strokeStyle=`rgba(8,11,12,${.12+Math.random()*.25})`;x.lineWidth=.6+Math.random()*1.4;x.beginPath();let px=Math.random()*size,py=Math.random()*size;x.moveTo(px,py);for(let j=0;j<4;j++){px+=(Math.random()-.5)*27;py+=(Math.random()-.5)*24;x.lineTo(px,py)}x.stroke()}
  for(let i=0;i<450;i++){x.fillStyle=`rgba(135,137,126,${Math.random()*.07})`;x.fillRect(Math.random()*size,Math.random()*size,1+Math.random()*9,1+Math.random()*2)}
 }else if(kind==='facade'){
  x.fillStyle='#a59c89';x.fillRect(0,0,size,size);
  for(let y=12;y<size;y+=96){for(let xx=12;xx<size;xx+=112){const warm=Math.random()>.53;x.fillStyle=['#23353b','#2d3c40','#394448','#4c5a5e','#554d43'][Math.floor(Math.random()*5)];x.fillRect(xx,y,60,64);x.fillStyle=warm?'#b9a98e':'#c1b9a5';x.fillRect(xx-4,y-4,68,4);x.fillRect(xx-4,y+64,68,5);x.fillRect(xx-4,y,4,64);x.fillRect(xx+60,y,4,64);x.fillStyle='rgba(240,210,160,.12)';x.fillRect(xx+5,y+6,50,3);x.fillStyle='rgba(5,11,14,.2)';x.fillRect(xx+5,y+55,50,6)}}
  for(let i=0;i<4200;i++){x.fillStyle=`rgba(45,36,25,${Math.random()*.065})`;x.fillRect(Math.random()*size,Math.random()*size,1+Math.random()*12,1+Math.random()*26)}
 }else if(kind==='fabric'){x.fillStyle='#b7b4ad';x.fillRect(0,0,size,size);for(let i=0;i<size;i+=4){x.strokeStyle='rgba(25,27,28,.12)';x.lineWidth=1;x.beginPath();x.moveTo(0,i);x.lineTo(size,i);x.stroke();x.strokeStyle='rgba(245,242,233,.10)';x.beginPath();x.moveTo(i,0);x.lineTo(i,size);x.stroke()}for(let i=0;i<11000;i++){const v=35+Math.random()*170;x.fillStyle=`rgba(${v},${v},${v},${Math.random()*.12})`;x.fillRect(Math.random()*size,Math.random()*size,1+Math.random()*2,1+Math.random()*2)}}else{x.fillStyle='#5b4b3a';x.fillRect(0,0,size,size);for(let i=0;i<6500;i++){x.fillStyle=`rgba(${70+Math.random()*90},${58+Math.random()*65},${45+Math.random()*45},.12)`;x.fillRect(Math.random()*size,Math.random()*size,1+Math.random()*4,1+Math.random()*5)}}
 const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(kind==='asphalt'?5:1,kind==='asphalt'?5:1);t.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8);return t
}
const asphaltTexture=makeTiledTexture('asphalt'),facadeTexture=makeTiledTexture('facade'),fabricTexture=makeTiledTexture('fabric');
function clothMaterial(color){return new THREE.MeshStandardMaterial({color,map:fabricTexture,roughness:.94,metalness:0})}
function loadLocalTextureInto(target,path){const image=new Image();image.onload=()=>{target.image=image;target.needsUpdate=true;target.wrapS=target.wrapT=THREE.RepeatWrapping;target.colorSpace=THREE.SRGBColorSpace};image.onerror=()=>console.warn('Local HD texture unavailable; generated offline fallback retained:',path);image.src=new URL(path,import.meta.url).href}
loadLocalTextureInto(asphaltTexture,'./assets/textures/kochi-asphalt-2k.png');loadLocalTextureInto(facadeTexture,'./assets/textures/kochi-plaster-2k.png');
const osmAsphaltMaterial=new THREE.MeshStandardMaterial({map:asphaltTexture,color:0xffffff,roughness:.95,side:THREE.DoubleSide});
const osmFacadeMaterial=new THREE.MeshStandardMaterial({map:facadeTexture,color:0xffffff,roughness:.88});
const GAME_METERS_PER_UNIT=1.2;
const KOCHI_MAP_ANCHOR={lat:9.9817,lng:76.2828,metersPerUnit:GAME_METERS_PER_UNIT};
const M={asphalt:new THREE.MeshStandardMaterial({map:asphaltTexture,color:0xffffff,roughness:.93}),line:mat(0xb5a88e,.65),concrete:mat(0x4b514f),roof:mat(0x252b2c),leaf:mat(0x193b2e),trunk:mat(0x45372b),glass:mat(0x101d24,.15,.3),rubber:mat(0x111315),metal:mat(0x454b4d,.35,.65),rust:mat(0x6a3b2a),skin:mat(0x966849),shirt:clothMaterial(0x7a3028),pants:clothMaterial(0x302c29),lamp:mat(0xffd4a0,.2)};
function mesh(g,m,x=0,y=0,z=0,parent=scene){const o=new THREE.Mesh(g,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o}function box(parent,x,y,z,w,h,d,m){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,parent)}function cyl(parent,x,y,z,r1,r2,h,m,n=10){return mesh(new THREE.CylinderGeometry(r1,r2,h,n),m,x,y,z,parent)}
const legacyDistrict=new THREE.Group();scene.add(legacyDistrict);const osmWorldGroup=new THREE.Group();scene.add(osmWorldGroup);osmWorldGroup.visible=false;
const ground=mesh(new THREE.PlaneGeometry(320,320),mat(0x17221f),0,-.12,0,legacyDistrict);ground.rotation.x=-Math.PI/2;const road=mesh(new THREE.PlaneGeometry(15,170),M.asphalt,0,-.045,-18,legacyDistrict);road.rotation.x=-Math.PI/2;const sheen=mesh(new THREE.PlaneGeometry(14.6,150),new THREE.MeshStandardMaterial({color:0x344149,roughness:.18,metalness:.22,transparent:true,opacity:.28}),0,-.025,-18,legacyDistrict);sheen.rotation.x=-Math.PI/2;
for(let z=-92;z<58;z+=8){box(legacyDistrict,0,.018,z,.12,.008,3.2,M.line);box(legacyDistrict,-7.4,.018,z,.12,.008,3.2,M.line);box(legacyDistrict,7.4,.018,z,.12,.008,3.2,M.line)}for(let z=-80;z<42;z+=13){box(legacyDistrict,-8.5,.08,z,.5,.16,1.1,M.concrete);box(legacyDistrict,8.5,.08,z,.5,.16,1.1,M.concrete)}
// Connected free-roam Kochi street grid: asphalt roads, junctions, sidewalks and mixed-use blocks.
const cityRoadMat=mat(0x252c2e,.62),sidewalkMat=mat(0x575a54,.88),laneMat=mat(0xc4b99c,.8);
for(let c=-125;c<=125;c+=25){
 const vertical=mesh(new THREE.PlaneGeometry(8,310),cityRoadMat,c,-.035,0,legacyDistrict);vertical.rotation.x=-Math.PI/2;
 const horizontal=mesh(new THREE.PlaneGeometry(310,8),cityRoadMat,0,-.034,c,legacyDistrict);horizontal.rotation.x=-Math.PI/2;
 const vline=mesh(new THREE.PlaneGeometry(.08,308),laneMat,c,-.015,0,legacyDistrict);vline.rotation.x=-Math.PI/2;
 const hline=mesh(new THREE.PlaneGeometry(308,.08),laneMat,0,-.014,c,legacyDistrict);hline.rotation.x=-Math.PI/2;
 for(const side of [-1,1]){const sw1=mesh(new THREE.PlaneGeometry(1.2,306),sidewalkMat,c+side*4.7,-.025,0,legacyDistrict);sw1.rotation.x=-Math.PI/2;const sw2=mesh(new THREE.PlaneGeometry(306,1.2),sidewalkMat,0,-.024,c+side*4.7,legacyDistrict);sw2.rotation.x=-Math.PI/2;}
}
// Simple static footprints used to stop Free Roam actors passing through major buildings.
const worldSolidBounds=[];
const buildingCollisionGrid=new Map();const COLLISION_CELL_SIZE=32;
function collisionCellKey(ix,iz){return `${ix},${iz}`}
function rebuildCollisionGrid(){buildingCollisionGrid.clear();for(const b of worldSolidBounds){const minX=Math.floor(b.minX/COLLISION_CELL_SIZE),maxX=Math.floor(b.maxX/COLLISION_CELL_SIZE),minZ=Math.floor(b.minZ/COLLISION_CELL_SIZE),maxZ=Math.floor(b.maxZ/COLLISION_CELL_SIZE);for(let ix=minX;ix<=maxX;ix++)for(let iz=minZ;iz<=maxZ;iz++){const k=collisionCellKey(ix,iz);if(!buildingCollisionGrid.has(k))buildingCollisionGrid.set(k,[]);buildingCollisionGrid.get(k).push(b)}}}
function nearbyCollisionBounds(x,z,rx,rz){const found=[],seen=new Set();const minX=Math.floor((x-rx)/COLLISION_CELL_SIZE),maxX=Math.floor((x+rx)/COLLISION_CELL_SIZE),minZ=Math.floor((z-rz)/COLLISION_CELL_SIZE),maxZ=Math.floor((z+rz)/COLLISION_CELL_SIZE);for(let ix=minX;ix<=maxX;ix++)for(let iz=minZ;iz<=maxZ;iz++)for(const b of buildingCollisionGrid.get(collisionCellKey(ix,iz))||[]){if(!seen.has(b)){seen.add(b);found.push(b)}}return found}
// Extra shops, apartment blocks and homes around the connected roads.
for(const [x,z,w,d,h,col,shop] of [[-42,-43,12,10,8,0x68665d,true],[-12,-43,10,12,6,0x76614f,false],[18,-43,12,10,9,0x5c6865,true],[48,-43,12,12,7,0x80664f,false],[-42,-12,12,12,10,0x626967,false],[-12,-12,10,12,6,0x7c6755,true],[18,-12,12,10,8,0x5f625d,false],[48,-12,12,12,11,0x6a665b,true],[-42,18,12,10,7,0x716052,true],[-12,18,10,12,9,0x596461,false],[18,18,12,10,6,0x806c58,true],[48,18,12,12,9,0x5c6462,false],[-42,48,12,12,8,0x6c5b4b,false],[-12,48,10,10,6,0x756d60,true],[18,48,12,12,10,0x5b6562,false],[48,48,12,10,7,0x80644e,true]])house(x,z,w,d,h,col,shop);
function palm(x,z,h=7){const g=new THREE.Group();g.position.set(x,0,z);legacyDistrict.add(g);cyl(g,0,h/2,0,.15,.3,h,M.trunk,7);for(let i=0;i<7;i++){const a=i*Math.PI*2/7;const f=box(g,Math.cos(a)*1.1,h+.05,Math.sin(a)*1.1,2.8,.08,.35,M.leaf);f.rotation.y=-a;f.rotation.z=Math.cos(a)*-.3}cyl(g,0,h,0,.24,.24,.25,M.leaf,8)}
function house(x,z,w,d,h,color,shop=false){const g=new THREE.Group();g.position.set(x,0,z);legacyDistrict.add(g);box(g,0,h/2,0,w,h,d,mat(color));box(g,0,h+.18,0,w+.3,.35,d+.3,M.roof);for(let f=0;f<Math.max(1,Math.floor(h/2.5));f++)for(let xx=-w/2+1;xx<w/2-.5;xx+=2){box(g,xx,1.35+f*2.4,d/2+.03,.8,1.05,.06,M.glass);box(g,xx,1.9+f*2.4,d/2+.08,.9,.08,.07,M.concrete)}if(shop){box(g,0,1.25,d/2+.08,w*.6,1.45,.08,M.glass);box(g,0,2.12,d/2+.12,w*.72,.24,.1,mat(0x703d2a))}worldSolidBounds.push({minX:x-w/2-.15,maxX:x+w/2+.15,minZ:z-d/2-.15,maxZ:z+d/2+.15})}
// Dense fictionalized Kochi neighbourhood: compact mixed-use plots, shopfronts, apartment
// blocks, roof tanks, balconies, trees and street furniture. Roads remain open between lots.
// A fixed seed keeps the city layout stable between launches and on Android devices.
let citySeed=73129;function cityRand(){citySeed=(citySeed*1664525+1013904223)>>>0;return citySeed/4294967296;}
const existingLots=[[-42,-43],[-12,-43],[18,-43],[48,-43],[-42,-12],[-12,-12],[18,-12],[48,-12],[-42,18],[-12,18],[18,18],[48,18],[-42,48],[-12,48],[18,48],[48,48],[-13,-26],[13,-30],[-15,-8],[15,-4],[-14,14],[15,19]];
const facadePalette=[0x8a7761,0x777d75,0x9a866d,0x686f70,0x9b9a89,0x765c4e,0x5e7471,0xb19a7c,0x74716a];
const shopSignMats=[mat(0x8a3c2d),mat(0x315f5b),mat(0x8a6a2d),mat(0x394d68),mat(0x76506b)];
function addDenseLot(x,z){
 if(existingLots.some(([a,b])=>Math.abs(a-x)<14&&Math.abs(b-z)<14))return;
 if(x>78)return; // retain the port's dedicated warehouse/container silhouette
 const w=6.8+cityRand()*3.2,d=7+cityRand()*3.1,h=3.6+cityRand()*((x< -60)?5.2:8.2);
 const shop=cityRand()>.39,apartment=!shop&&cityRand()>.54;
 const color=facadePalette[Math.floor(cityRand()*facadePalette.length)];
 const g=new THREE.Group();g.position.set(x,0,z);legacyDistrict.add(g);
 const body=box(g,0,h/2,0,w,h,d,mat(color,.9));
 box(g,0,h+.16,0,w+.28,.32,d+.28,M.roof);
 // Front and side windows with concrete lintels; simple meshes keep the scene mobile-friendly.
 const floors=Math.max(1,Math.floor((h-1)/2.35));
 for(let f=0;f<floors;f++){
  const yy=1.15+f*2.35;
  for(let xx=-w/2+1;xx<w/2-.45;xx+=1.75){
   box(g,xx,yy,d/2+.045,.72,.92,.055,M.glass);
   box(g,xx,yy+.49,d/2+.075,.82,.075,.07,M.concrete);
  }
  if(apartment){const balcony=box(g,0,yy-.2,d/2+.24,w*.78,.09,.48,M.metal);box(g,0,yy+.08,d/2+.43,w*.78,.06,.05,M.metal);}
 }
 for(let f=0;f<floors;f++)for(let zz=-d/2+1;zz<d/2-.6;zz+=2.1)box(g,w/2+.035,1.2+f*2.35,zz,.055,.85,.72,M.glass);
 if(shop){
  box(g,0,1.25,d/2+.09,w*.76,1.5,.08,M.glass);
  box(g,0,2.18,d/2+.16,w*.88,.35,.13,shopSignMats[Math.floor(cityRand()*shopSignMats.length)]);
  box(g,0,2.55,d/2+.18,w*.94,.1,.22,M.roof); // projecting shop awning
 }
 // Rooftop water tank and service shed are common silhouettes across the neighbourhood.
 if(cityRand()>.32){const tx=(cityRand()-.5)*w*.48,tz=(cityRand()-.5)*d*.45;box(g,tx,h+.65,tz,.9,1.05,.9,mat(0x454f50));cyl(g,tx,h+1.35,tz,.42,.42,.22,mat(0x59676a),10);}
 if(cityRand()>.58)box(g,(cityRand()-.5)*w*.5,h+.38,(cityRand()-.5)*d*.5,1.1,.42,.65,mat(0x626966));
 worldSolidBounds.push({minX:x-w/2-.18,maxX:x+w/2+.18,minZ:z-d/2-.18,maxZ:z+d/2+.18});
}
for(let x=-112.5;x<=87.5;x+=25)for(let z=-112.5;z<=112.5;z+=25)addDenseLot(x,z);
// Distinct public-facing locations make the neighbourhood read as a town, not identical blocks.
function civicSign(x,z,label,color=0x284c49){
 const canvas=document.createElement('canvas');canvas.width=512;canvas.height=128;const c=canvas.getContext('2d');
 c.fillStyle='#'+color.toString(16).padStart(6,'0');c.fillRect(0,0,512,128);c.strokeStyle='#d7b47b';c.lineWidth=7;c.strokeRect(5,5,502,118);
 c.fillStyle='#fff0d7';c.font='bold 35px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(label,256,64);
 const tex=new THREE.CanvasTexture(canvas);tex.colorSpace=THREE.SRGBColorSpace;
 const board=box(legacyDistrict,x,3.15,z,5.6,1.35,.18,mat(color));const face=mesh(new THREE.PlaneGeometry(5.35,1.05),new THREE.MeshBasicMaterial({map:tex}),x,3.15,z-.105,legacyDistrict);face.rotation.y=Math.PI;
}
// Fictional sign names evoke a busy Kerala city without falsely claiming exact real-world placement.
civicSign(-62.5,-62.5,'CITY MARKET',0x36544c);civicSign(12.5,-87.5,'METRO ACCESS',0x31506a);civicSign(-87.5,12.5,'MEDICAL CENTRE',0x5a3937);civicSign(62.5,37.5,'CINEMA',0x633c35);
// Extra palms and warm streetlights on a deterministic selection of junctions.
for(let x=-100;x<=75;x+=25)for(let z=-100;z<=100;z+=25){
 if(cityRand()>.47){const side=cityRand()>.5?1:-1;palm(x+side*5.5,z+(cityRand()-.5)*5,5.5+cityRand()*2.4);}
 if(cityRand()>.72){cyl(legacyDistrict,x+5.15,2.35,z+5.15,.055,.075,4.7,M.metal,7);box(legacyDistrict,x+5.55,4.7,z+5.15,.7,.08,.09,M.metal);const bulb=new THREE.PointLight(0xffbd79,4.2,8,2);bulb.position.set(x+5.65,4.45,z+5.15);scene.add(bulb);}
}

// Expanded eastern port district: warehouses, stacked containers, quay wall and a gantry silhouette.
for(const [x,z,w,d,h,col] of [[99,-86,19,17,9,0x4b514d],[122,-86,19,17,11,0x5b5b52],[99,-55,19,18,8,0x665747],[122,-55,18,18,10,0x454f50],[99,75,19,17,9,0x58574e],[122,75,19,17,11,0x4e5553]])house(x,z,w,d,h,col,true);
const containerMats=[mat(0x7a3428,.8),mat(0x3d5960,.8),mat(0x6d654d,.8),mat(0x394942,.8)];
for(let row=0;row<3;row++)for(let col=0;col<4;col++){const x=93+col*7.2,z=-20+row*7.3;box(scene,x,1.25,z,6.8,2.5,2.15,containerMats[(row+col)%containerMats.length]);worldSolidBounds.push({minX:x-3.5,maxX:x+3.5,minZ:z-1.2,maxZ:z+1.2});for(let rib=-2.8;rib<=2.8;rib+=.55)box(scene,x+rib,1.25,z+1.09,.045,2.25,.045,M.metal);}
// Dock cranes are static industrial landmarks, not interactive vehicles.
for(const [x,z] of [[113,-8],[133,16]]){box(scene,x,10,z,.7,20,.7,M.metal);box(scene,x+5,19,z,16,.6,.7,M.metal);box(scene,x+11,14,z,.45,10,.45,M.metal);box(scene,x+11,8.7,z,3.3,.28,2.2,mat(0x303638,.45,.65));for(const dx of [-6,6])box(scene,x+dx,16,z,.12,6,.12,M.metal);}
box(scene,119,.35,34,32,.7,3.4,mat(0x454b4d,.42,.5));
house(-13,-26,9,9,6,0x716454);house(13,-30,9,9,8,0x5d6864);house(-15,-8,7,8,4.5,0x8b6c55,true);house(15,-4,8,8,5,0x66685f,true);house(-14,14,8,8,6,0x64584d);house(15,19,9,8,7,0x5d6260);for(const [x,z,h] of [[-11,-34,8],[11,-39,7],[-20,-18,9],[20,-22,8],[-10,3,7],[10,8,8],[-22,20,9],[23,28,8],[-11,-52,8],[11,-55,9]])palm(x,z,h);
function streetLamp(x,z){cyl(scene,x,3.1,z,.08,.11,6.2,M.metal,8);box(scene,x+.6,6.1,z,1.25,.09,.1,M.metal);box(scene,x+1.12,5.95,z,.42,.13,.28,M.lamp);const l=new THREE.PointLight(0xffb86d,18,19,2);l.position.set(x+1,5.7,z);scene.add(l)}streetLamp(-9,-18);streetLamp(9,-42);streetLamp(-9,8);
// Build the nearby 3D district from packaged OpenStreetMap geometry. OSM is fetched during
// APK creation only; no network resources are requested by the installed game.
const offlineRoadSegments=[];
const petSpawnPoints=[];
function geoToGameXY(lon,lat){const lat0=KOCHI_MAP_ANCHOR.lat*Math.PI/180;return {x:(lon-KOCHI_MAP_ANCHOR.lng)*111320*Math.cos(lat0)/GAME_METERS_PER_UNIT,z:-(lat-KOCHI_MAP_ANCHOR.lat)*111320/GAME_METERS_PER_UNIT}}
function gameToGeoXY(x,z){const lat=KOCHI_MAP_ANCHOR.lat-z*GAME_METERS_PER_UNIT/111320;const lng=KOCHI_MAP_ANCHOR.lng+x*GAME_METERS_PER_UNIT/(111320*Math.cos(KOCHI_MAP_ANCHOR.lat*Math.PI/180));return [lng,lat]}
function roadWidthUnits(tags={}){const h=tags.highway||'';const tagged=parseFloat(String(tags.width||'').replace(/[^0-9.]/g,''));if(Number.isFinite(tagged)&&tagged>0)return THREE.MathUtils.clamp(tagged/GAME_METERS_PER_UNIT,.7,18);return ({motorway:13,trunk:12,primary:10.5,secondary:8.5,tertiary:6.8,unclassified:5.5,residential:5.1,living_street:4.5,service:3.5,track:3.2,busway:5,footway:1.35,cycleway:1.6,path:1.2,steps:1.1})[h]||4.8}
function addRoadQuad(pos,uv,a,b,width){const dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz);if(len<.04)return;const px=-dz/len*width/2,pz=dx/len*width/2;const u=len/8;const verts=[[a.x+px,-.065,a.z+pz],[a.x-px,-.065,a.z-pz],[b.x-px,-.065,b.z-pz],[a.x+px,-.065,a.z+pz],[b.x-px,-.065,b.z-pz],[b.x+px,-.065,b.z+pz]];const tex=[[0,0],[0,1],[u,1],[0,0],[u,1],[u,0]];for(let i=0;i<6;i++){pos.push(...verts[i]);uv.push(...tex[i])}}
function stableRand(seed){let s=seed>>>0;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296}}
function featureRect(feature){const coords=feature.coordinates||[];if(coords.length<3)return null;const points=coords.map(p=>geoToGameXY(p[0],p[1]));const xs=points.map(p=>p.x),zs=points.map(p=>p.z);const minX=Math.min(...xs),maxX=Math.max(...xs),minZ=Math.min(...zs),maxZ=Math.max(...zs);if(![minX,maxX,minZ,maxZ].every(Number.isFinite))return null;return {points,minX,maxX,minZ,maxZ,cx:(minX+maxX)/2,cz:(minZ+maxZ)/2,w:maxX-minX,d:maxZ-minZ,tags:feature.tags||{}}}
function buildOfflineKochiDistrict(){
 const features=offlineKochiData.features||[];const roadFeatures=features.filter(f=>f.type==='way'&&f.tags?.highway&&f.coordinates?.length>1);
 if(features.length<100||roadFeatures.length<40){console.warn('Offline Kochi map data missing or incomplete; showing temporary fallback town. Rebuild with the OSM data step before release.');const mapError=document.querySelector('#map-error');if(mapError)mapError.classList.remove('hidden');return false}
 worldSolidBounds.length=0;
 const base=mesh(new THREE.PlaneGeometry(11200,7800),new THREE.MeshStandardMaterial({color:0x344337,roughness:1}),0,-.13,0,osmWorldGroup);base.rotation.x=-Math.PI/2;
 const verts=[],uvs=[],footpathVerts=[],footpathUvs=[],laneVerts=[],laneUvs=[],riverVerts=[],riverUvs=[],railVerts=[],railUvs=[];let segCount=0;
 for(const f of roadFeatures){const coords=f.coordinates.map(p=>geoToGameXY(p[0],p[1]));const width=roadWidthUnits(f.tags);const h=f.tags.highway;const walkway=['footway','path','steps','cycleway','pedestrian'].includes(h);for(let i=1;i<coords.length;i++){const a=coords[i-1],b=coords[i],midX=(a.x+b.x)/2,midZ=(a.z+b.z)/2;if(Math.abs(midX)>5700||Math.abs(midZ)>3950)continue;const arr=walkway?footpathVerts:verts,uv=walkway?footpathUvs:uvs;addRoadQuad(arr,uv,a,b,walkway?Math.max(.35,width):width);if(!walkway&&['primary','secondary','tertiary','residential','unclassified'].includes(h)){const dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz)||1;for(let dist=0;dist<len;dist+=12){const from=dist,to=Math.min(len,dist+4.2);if(to-from<.8)continue;const la={x:a.x+dx*from/len,z:a.z+dz*from/len},lb={x:a.x+dx*to/len,z:a.z+dz*to/len};const oldCount=laneVerts.length;addRoadQuad(laneVerts,laneUvs,la,lb,.07);for(let vi=oldCount;vi<laneVerts.length;vi+=3)laneVerts[vi+1]=-.047;}}offlineRoadSegments.push({a,b,width,tags:f.tags});segCount++;}}
 function roadMesh(positionArray,uvArray,material){if(!positionArray.length)return;const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positionArray,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uvArray,2));g.computeVertexNormals();const m=new THREE.Mesh(g,material);m.receiveShadow=true;osmWorldGroup.add(m)}
 for(const f of features.filter(f=>f.type==='way'&&f.tags?.waterway&&f.coordinates?.length>1)){const pts=f.coordinates.map(p=>geoToGameXY(p[0],p[1]));const width=THREE.MathUtils.clamp((parseFloat(f.tags.width)||(['river','canal'].includes(f.tags.waterway)?7:2.4))/GAME_METERS_PER_UNIT,1.4,16);for(let i=1;i<pts.length;i++)addRoadQuad(riverVerts,riverUvs,pts[i-1],pts[i],width)}
 for(const f of features.filter(f=>f.type==='way'&&f.tags?.railway&&f.coordinates?.length>1)){const pts=f.coordinates.map(p=>geoToGameXY(p[0],p[1]));for(let i=1;i<pts.length;i++)addRoadQuad(railVerts,railUvs,pts[i-1],pts[i],['subway','light_rail','monorail'].includes(f.tags.railway)?2.4:1.45)}
 asphaltTexture.repeat.set(1,1);roadMesh(verts,uvs,osmAsphaltMaterial);roadMesh(footpathVerts,footpathUvs,new THREE.MeshStandardMaterial({color:0x77796f,roughness:1,side:THREE.DoubleSide}));roadMesh(laneVerts,laneUvs,new THREE.MeshStandardMaterial({color:0xd9d2b8,roughness:.82,side:THREE.DoubleSide}));roadMesh(riverVerts,riverUvs,new THREE.MeshStandardMaterial({color:0x376d7b,roughness:.38,metalness:.05,side:THREE.DoubleSide}));roadMesh(railVerts,railUvs,new THREE.MeshStandardMaterial({color:0x7f898a,roughness:.55,metalness:.2,side:THREE.DoubleSide}));
 // Instancing thousands of mapped building shells keeps the scene viable on a mid-range phone.
 const buildingFeatures=features.filter(f=>f.type==='way'&&f.tags?.building&&f.coordinates?.length>=4).map(featureRect).filter(r=>r&&Math.abs(r.cx)<5650&&Math.abs(r.cz)<3900&&r.w>.6&&r.d>.6&&r.w<70&&r.d<70);
 const buildingBuckets=new Map();
 for(const r of buildingFeatures){const ix=Math.floor((r.cx+5650)/700),iz=Math.floor((r.cz+3900)/650),key=`${ix}:${iz}`;if(!buildingBuckets.has(key))buildingBuckets.set(key,[]);buildingBuckets.get(key).push(r)}
 const orderedBuildingBuckets=[...buildingBuckets.entries()].sort((a,b)=>a[0].localeCompare(b[0])).map(([,items])=>items);
 const buildings=[];for(let round=0;buildings.length<14000;round++){let added=false;for(const bucket of orderedBuildingBuckets){if(bucket[round]){buildings.push(bucket[round]);added=true;if(buildings.length>=14000)break}}if(!added)break}
 const buildingMeta=[];
 if(buildings.length){
  const instances=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),osmFacadeMaterial,buildings.length);
  const roofInstances=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshStandardMaterial({color:0x57544d,roughness:.98}),buildings.length);
  instances.castShadow=false;instances.receiveShadow=true;roofInstances.castShadow=false;roofInstances.receiveShadow=true;
  const o=new THREE.Object3D(),rng=stableRand(975310);
  const palette=[0xe2d7c1,0xc9b99e,0xa89b87,0xb5bbb3,0xc5b8a5,0x9faaa6,0xc4a78a,0xbab4aa,0x878e89,0xd0c8b4,0xd6c1a6,0x958a7b];
  const roofPalette=[0x4a4d4b,0x5a554e,0x6b6256,0x3f4648,0x777064];
  for(let i=0;i<buildings.length;i++){
   const r=buildings[i],tags=r.tags||{};const ww=THREE.MathUtils.clamp(r.w,.9,64),dd=THREE.MathUtils.clamp(r.d,.9,64);
   const levelsRaw=parseFloat(tags['building:levels']||tags.levels||'');const levels=Number.isFinite(levelsRaw)&&levelsRaw>0?THREE.MathUtils.clamp(Math.round(levelsRaw),1,18):((r.w+r.d)>22?4:2);
   let height=parseFloat(String(tags.height||'').replace(/[^0-9.]/g,''));if(!Number.isFinite(height)||height<2)height=levels*2.8;
   if(['house','detached','bungalow','residential'].includes(tags.building))height=Math.min(height,12);
   const hh=THREE.MathUtils.clamp(height/GAME_METERS_PER_UNIT,1.7,38);
   o.position.set(r.cx,hh/2,r.cz);o.rotation.set(0,0,0);o.scale.set(ww,hh,dd);o.updateMatrix();instances.setMatrixAt(i,o.matrix);
   instances.setColorAt(i,new THREE.Color(palette[Math.floor(rng()*palette.length)]));
   o.position.set(r.cx,hh+.04,r.cz);o.scale.set(ww+.25,.08,dd+.25);o.updateMatrix();roofInstances.setMatrixAt(i,o.matrix);roofInstances.setColorAt(i,new THREE.Color(roofPalette[Math.floor(rng()*roofPalette.length)]));
   const bounds={minX:r.cx-ww/2-.2,maxX:r.cx+ww/2+.2,minZ:r.cz-dd/2-.2,maxZ:r.cz+dd/2+.2};worldSolidBounds.push(bounds);
   buildingMeta.push({cx:r.cx,cz:r.cz,ww,dd,hh,levels,tags});
  }
  instances.instanceMatrix.needsUpdate=true;if(instances.instanceColor)instances.instanceColor.needsUpdate=true;roofInstances.instanceMatrix.needsUpdate=true;if(roofInstances.instanceColor)roofInstances.instanceColor.needsUpdate=true;osmWorldGroup.add(instances,roofInstances);
  // Real-sized facade windows make the mapped building masses read as buildings instead of plain blocks.
  const windowGeo=new THREE.BoxGeometry(.48,.62,.055),windowMat=new THREE.MeshStandardMaterial({color:0x87989b,roughness:.28,metalness:.12});
  const windowRecords=[];const maxWindows=23000;
  for(let i=0;i<buildingMeta.length&&windowRecords.length<maxWindows;i++){
   const b=buildingMeta[i];if(b.ww<3.0||b.dd<2.8)continue;
   const floors=Math.min(10,Math.max(1,Math.floor((b.hh-.7)/2.15)));const frontCols=Math.min(7,Math.max(1,Math.floor((b.ww-.5)/1.45)));const sideCols=Math.min(5,Math.max(1,Math.floor((b.dd-.5)/1.45)));
   for(let floor=0;floor<floors&&windowRecords.length<maxWindows;floor++){
    const yy=.78+floor*2.05;if(yy>b.hh-.45)break;
    for(let col=0;col<frontCols&&windowRecords.length<maxWindows;col++){
     const xx=frontCols===1?0:((col/(frontCols-1))-.5)*(b.ww-.85);
     for(const side of [-1,1])windowRecords.push({x:b.cx+xx,y:yy,z:b.cz+side*(b.dd/2+.035),rot:0,warm:rng()>.91});
    }
    if(windowRecords.length<maxWindows)for(let col=0;col<sideCols&&windowRecords.length<maxWindows;col++){
     const zz=sideCols===1?0:((col/(sideCols-1))-.5)*(b.dd-.85);
     for(const side of [-1,1])windowRecords.push({x:b.cx+side*(b.ww/2+.035),y:yy,z:b.cz+zz,rot:Math.PI/2,warm:rng()>.91});
    }
   }
  }
  if(windowRecords.length){const windows=new THREE.InstancedMesh(windowGeo,windowMat,windowRecords.length),m=new THREE.Object3D();for(let i=0;i<windowRecords.length;i++){const w=windowRecords[i];m.position.set(w.x,w.y,w.z);m.rotation.set(0,w.rot,0);m.updateMatrix();windows.setMatrixAt(i,m.matrix);windows.setColorAt(i,new THREE.Color(w.warm?0xcaa878:([0x263a42,0x33474f,0x455b60][i%3])))}windows.instanceMatrix.needsUpdate=true;if(windows.instanceColor)windows.instanceColor.needsUpdate=true;osmWorldGroup.add(windows)}
  // Water tanks and small rooftop service boxes break up identical roof silhouettes.
  const tankMeta=buildingMeta.filter((b,i)=>b.ww>5&&b.dd>5&&i%17===0).slice(0,420);
  if(tankMeta.length){const tanks=new THREE.InstancedMesh(new THREE.CylinderGeometry(.38,.4,.7,8),new THREE.MeshStandardMaterial({color:0x777f7c,roughness:.72,metalness:.08}),tankMeta.length),m=new THREE.Object3D();tankMeta.forEach((b,i)=>{m.position.set(b.cx+b.ww*.2,b.hh+.42,b.cz-b.dd*.16);m.rotation.set(0,(i%4)*.35,0);m.updateMatrix();tanks.setMatrixAt(i,m.matrix)});tanks.instanceMatrix.needsUpdate=true;osmWorldGroup.add(tanks)}
 }
 rebuildCollisionGrid();
 // Natural polygons tint the base for parks, tree cover and water. These sit beneath road/building meshes.
 const naturalFills=features.filter(f=>f.type==='way'&&f.coordinates?.length>=4&&(f.tags?.natural==='water'||f.tags?.waterway||['park','garden','recreation_ground','grass','forest','wood','orchard'].includes(f.tags?.landuse)||f.tags?.leisure==='park'));
 const waterMat=new THREE.MeshStandardMaterial({color:0x244b57,roughness:.42,side:THREE.DoubleSide});const parkMat=new THREE.MeshStandardMaterial({color:0x3f5c3e,roughness:1,side:THREE.DoubleSide});
 for(const f of naturalFills.slice(0,800)){const pts=f.coordinates.map(q=>geoToGameXY(q[0],q[1]));if(pts.length<3)continue;const shape=new THREE.Shape();shape.moveTo(pts[0].x,-pts[0].z);for(let i=1;i<pts.length;i++)shape.lineTo(pts[i].x,-pts[i].z);if(pts[0].x!==pts[pts.length-1].x||pts[0].z!==pts[pts.length-1].z)shape.lineTo(pts[0].x,-pts[0].z);const g=new THREE.ShapeGeometry(shape);g.rotateX(-Math.PI/2);const m=new THREE.Mesh(g,(f.tags?.natural==='water'||f.tags?.waterway)?waterMat:parkMat);m.position.y=-.085;m.receiveShadow=true;osmWorldGroup.add(m)}
 // Roadside vegetation uses instancing; tree positions are sampled beside mapped roads and checked against building footprints.
 const treePts=[];for(const seg of offlineRoadSegments){const dx=seg.b.x-seg.a.x,dz=seg.b.z-seg.a.z,len=Math.hypot(dx,dz);if(len<9)continue;const side=((Math.round(seg.a.x*17+seg.a.z*13)%2)===0?1:-1);const nx=-dz/(len||1),nz=dx/(len||1);for(const t of [.32,.72]){if(treePts.length>=900)break;const x=seg.a.x+dx*t+nx*side*(seg.width/2+2.8),z=seg.a.z+dz*t+nz*side*(seg.width/2+2.8);if(Math.abs(x)>5600||Math.abs(z)>3850||worldSolidBounds.some(b=>x>b.minX-1&&x<b.maxX+1&&z>b.minZ-1&&z<b.maxZ+1))continue;if(treePts.some(q=>Math.hypot(q.x-x,q.z-z)<9))continue;treePts.push({x,z,h:4.8+Math.abs(Math.sin(x*1.3+z))*3.4,palm:Math.abs(Math.sin(x*2.3-z))>.6})}}
 const broad=treePts.filter(t=>!t.palm),palms=treePts.filter(t=>t.palm);function instancedTreeParts(list,palmMode){if(!list.length)return;const trunkGeo=new THREE.CylinderGeometry(.12,.21,1,7),trunks=new THREE.InstancedMesh(trunkGeo,M.trunk,list.length),crownGeo=new THREE.SphereGeometry(1,8,6),crowns=new THREE.InstancedMesh(crownGeo,M.leaf,list.length),o=new THREE.Object3D();for(let i=0;i<list.length;i++){const t=list[i];o.position.set(t.x,t.h*.44,t.z);o.scale.set(1,t.h,1);o.rotation.set(0,0,0);o.updateMatrix();trunks.setMatrixAt(i,o.matrix);o.position.set(t.x,t.h*.9,t.z);o.scale.set(palmMode?1.0:1.55,palmMode?.95:1.15,palmMode?1.0:1.55);o.rotation.set(0,0,0);o.updateMatrix();crowns.setMatrixAt(i,o.matrix)}osmWorldGroup.add(trunks,crowns);if(palmMode){const leaves=new THREE.InstancedMesh(new THREE.BoxGeometry(3.4,.07,.35),M.leaf,list.length*7);let idx=0;for(const t of list)for(let j=0;j<7;j++){o.position.set(t.x+Math.sin(j*Math.PI*2/7)*.92,t.h*.91+Math.sin(j*Math.PI*2/7)*.22,t.z+Math.cos(j*Math.PI*2/7)*.92);o.rotation.set(-.18, j*Math.PI*2/7, Math.sin(j*2.2)*.18);o.scale.set(1,1,1);o.updateMatrix();leaves.setMatrixAt(idx++,o.matrix)}osmWorldGroup.add(leaves)}}
 instancedTreeParts(broad,false);instancedTreeParts(palms,true);
 // Mixed low hedges planted only on mapped roadside edges; no emoji/remote assets.
 const hedgePts=[];for(const t of treePts){for(const side of [-1,1]){const x=t.x+side*4,z=t.z+2;if(Math.abs(x)>5550||Math.abs(z)>3800||worldSolidBounds.some(b=>x>b.minX&&x<b.maxX&&z>b.minZ&&z<b.maxZ))continue;if(hedgePts.length<1500)hedgePts.push({x,z})}}
 if(hedgePts.length){const bushes=new THREE.InstancedMesh(new THREE.SphereGeometry(.55,6,4),new THREE.MeshStandardMaterial({color:0x315039,roughness:1}),hedgePts.length),o=new THREE.Object3D();hedgePts.forEach((b,i)=>{o.position.set(b.x,.35,b.z);o.scale.set(.8+((i%3)*.16),.55+((i%4)*.08),.8+((i%2)*.15));o.updateMatrix();bushes.setMatrixAt(i,o.matrix)});osmWorldGroup.add(bushes)}
 // Safe animal spawn points are selected beside real roads, not inside mapped building footprints.
 for(const t of treePts){if(Math.abs(t.x)<5500&&Math.abs(t.z)<3750&&petSpawnPoints.length<90)petSpawnPoints.push({x:t.x+(petSpawnPoints.length%2?2:-2),z:t.z+1.8})}
 console.info(`Offline Kochi district loaded: ${roadFeatures.length} road ways, ${buildings.length} building footprints, ${treePts.length} trees.`);
 return true;
}
const legacyWorldSolidBounds=worldSolidBounds.slice();
const hasOfflineKochiDistrict=buildOfflineKochiDistrict();
const offlineWorldSolidBounds=worldSolidBounds.slice();
worldSolidBounds.splice(0,worldSolidBounds.length,...legacyWorldSolidBounds);
legacyDistrict.visible=true;osmWorldGroup.visible=false;
function nearestMappedRoad(x,z,sideOffset=0,seed=0){
 if(!offlineRoadSegments.length)return null;
 let best=null,bestD=Infinity;
 for(let i=0;i<offlineRoadSegments.length;i++){
  const seg=offlineRoadSegments[i],h=seg.tags?.highway||'';
  if(['footway','path','steps','cycleway','pedestrian'].includes(h))continue;
  const dx=seg.b.x-seg.a.x,dz=seg.b.z-seg.a.z,len=Math.hypot(dx,dz);if(len<6)continue;
  const t=THREE.MathUtils.clamp(((x-seg.a.x)*dx+(z-seg.a.z)*dz)/(len*len),.08,.92);
  const px=seg.a.x+dx*t,pz=seg.a.z+dz*t,d=(x-px)**2+(z-pz)**2;
  if(d<bestD){bestD=d;const nx=-dz/len,nz=dx/len;const sign=((seed+i)%2===0)?1:-1;best={x:px+nx*sign*(seg.width/2+sideOffset),z:pz+nz*sign*(seg.width/2+sideOffset),cx:px,cz:pz,segment:seg,t,normalX:nx*sign,normalZ:nz*sign,length:len,directionX:dx/len,directionZ:dz/len,side:sign};}
 }
 return best;
}
function spawnPointOnMappedRoad(x,z,sideOffset=0,seed=0){
 const q=nearestMappedRoad(x,z,sideOffset,seed);if(!q)return {x,z,yaw:0};
 return {...q,yaw:Math.atan2(-q.directionX,-q.directionZ)};
}
function spawnFreeRoamRoadSpawn(seed,sideOffset=1.45){
 if(!offlineRoadSegments.length)return {x:0,z:0};
 const usable=offlineRoadSegments.filter(seg=>!['footway','path','steps','cycleway','pedestrian'].includes(seg.tags?.highway||'')&&Math.hypot(seg.b.x-seg.a.x,seg.b.z-seg.a.z)>12);
 if(!usable.length)return {x:0,z:0};const seg=usable[(Math.abs(seed*139+71))%usable.length],dx=seg.b.x-seg.a.x,dz=seg.b.z-seg.a.z,len=Math.hypot(dx,dz)||1,t=.16+((seed*0.61803398875)%1)*.68,side=seed%2?1:-1,nx=-dz/len*side,nz=dx/len*side;
 return {x:seg.a.x+dx*t+nx*(seg.width/2+sideOffset),z:seg.a.z+dz*t+nz*(seg.width/2+sideOffset),segment:seg,t,dir:seed%2?1:-1,normX:nx,normZ:nz};
}
function configureMappedTraffic(){
 if(!hasOfflineKochiDistrict)return;
 const routes=offlineRoadSegments.filter(seg=>!['footway','path','steps','cycleway','pedestrian'].includes(seg.tags?.highway||'')&&Math.hypot(seg.b.x-seg.a.x,seg.b.z-seg.a.z)>28);
 if(!routes.length)return;
 trafficCars.forEach((c,i)=>{const seg=routes[(i*37+11)%routes.length],dx=seg.b.x-seg.a.x,dz=seg.b.z-seg.a.z,len=Math.hypot(dx,dz);const t=.18+(i%5)*.15;c.position.set(seg.a.x+dx*t,0,seg.a.z+dz*t);c.userData.route='osm';c.userData.segment=seg;c.userData.progress=t;c.userData.dir=i%2?1:-1;c.userData.speed=1.5+(i%4)*.35;c.rotation.y=Math.atan2(-dx*c.userData.dir,-dz*c.userData.dir);});
}
// Static accident set dressing: damaged sedan, bent rail, skid marks and glass shards.
const wreck=new THREE.Group();wreck.position.set(-1.2,0,-18);wreck.rotation.y=-.34;scene.add(wreck);wreck.visible=false;
box(wreck,0,.57,0,2.05,.58,4.05,M.rust);box(wreck,0,1.05,-.12,1.62,.72,1.85,M.glass);box(wreck,0,1.13,1.18,1.8,.25,1.15,M.metal);box(wreck,0,.94,-1.72,1.8,.2,.55,M.rust);for(const x of [-1.03,1.03])for(const z of [-1.25,1.25]){const wh=cyl(wreck,x,.33,z,.34,.34,.22,M.rubber,14);wh.rotation.z=Math.PI/2;const hub=cyl(wreck,x*1.01,.33,z,.16,.16,.23,M.metal,12);hub.rotation.z=Math.PI/2}const hood=box(wreck,-.24,1.48,-1.15,.9,.12,1.2,M.rust);hood.rotation.z=-.22;hood.rotation.x=.13;const door=box(wreck,1.16,.78,.12,.12,.75,1.3,M.metal);door.rotation.y=.2;door.rotation.z=-.08;
for(let i=0;i<11;i++){const shard=mesh(new THREE.TetrahedronGeometry(.1+Math.random()*.13),new THREE.MeshStandardMaterial({color:0x7f9ca4,metalness:.25,roughness:.12,transparent:true,opacity:.7}),-3+Math.random()*5,.08+Math.random()*.16,-19+Math.random()*4);shard.rotation.set(Math.random(),Math.random(),Math.random())}for(let i=0;i<4;i++){const debris=box(scene,-3.5+Math.random()*5,.09,-22+Math.random()*7,.4+Math.random()*.7,.09,.15+Math.random()*.35,i%2?M.rust:M.metal);debris.rotation.y=Math.random()*2}for(let i=0;i<6;i++){const mark=box(scene,-2.7+i*.32,.012,-10-i*1.1,.09,.008,2.8,mat(0x101518,.95));mark.rotation.y=-.16}for(let i=0;i<4;i++){const post=box(scene,4.8,.45,-18-i*1.1,.12,.9,.12,M.metal);post.rotation.z=i%2?.2:-.12}box(scene,4.8,.08,-20,5,.13,.18,M.metal);
const rainCount=460,rainGeo=new THREE.BufferGeometry(),rainPos=new Float32Array(rainCount*3);for(let i=0;i<rainCount;i++){rainPos[i*3]=(Math.random()-.5)*42;rainPos[i*3+1]=Math.random()*18;rainPos[i*3+2]=-28+Math.random()*48}rainGeo.setAttribute('position',new THREE.BufferAttribute(rainPos,3));const rain=new THREE.Points(rainGeo,new THREE.PointsMaterial({color:0x9fb6c3,size:.045,transparent:true,opacity:.48}));scene.add(rain);
// Static Meshy geometry candidate. This export is NOT a faithful, rigged Abraham character yet.
// Do not invent costume regions with procedural vertex colours; preserve its supplied mesh/materials.
let abraham=null;
new GLTFLoader().load('assets/models/abraham.glb',g=>{
  const root=new THREE.Group();
  root.add(g.scene);
  const b=new THREE.Box3().setFromObject(root);
  const size=b.getSize(new THREE.Vector3());
  const scale=1.68/Math.max(size.y,.01);
  root.scale.setScalar(scale);
  const bb=new THREE.Box3().setFromObject(root);
  root.position.y=-bb.min.y;
  root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});
  // Keep this unverified mesh hidden until a correctly matching, rigged Abraham asset is available.
  root.visible=false;
  scene.add(root);
  abraham=root;
},undefined,()=>console.warn('Abraham GLB failed to load'));
// Simple driver silhouette in the moving car until the static character export is seated/rigged.
const driver=new THREE.Group();cyl(driver,0,.95,-.12,.23,.25,.5,M.shirt,12);mesh(new THREE.SphereGeometry(.18,12,10),M.skin,0,1.34,-.12,driver);mesh(new THREE.SphereGeometry(.19,12,8,0,Math.PI*2,0,Math.PI*.55),M.rubber,0,1.39,-.12,driver);
const player=new THREE.Group();scene.add(player);player.position.set(2,0,-11);
cyl(player,0,1.12,0,.27,.31,.66,M.shirt,12);
cyl(player,0,1.48,0,.09,.11,.16,M.skin,10);
mesh(new THREE.SphereGeometry(.2,18,14),M.skin,0,1.78,0,player);
mesh(new THREE.SphereGeometry(.205,16,10,0,Math.PI*2,0,Math.PI*.58),M.rubber,0,1.83,-.015,player);
const eyeMat=mat(0x171a1a,.48),browMat=mat(0x241a16,.92),shoeMat=mat(0x17191a,.92),collarMat=mat(0x292f32,.96);
const faceNose=mesh(new THREE.SphereGeometry(.038,9,7),M.skin,0,1.75,.19,player);faceNose.scale.set(.72,.78,1.05);
box(player,0,1.705,.193,.125,.035,.026,browMat);
mesh(new THREE.SphereGeometry(.045,8,6),M.rubber,-.153,1.75,.097,player);mesh(new THREE.SphereGeometry(.045,8,6),M.rubber,.153,1.75,.097,player);
// Facial detail and clothing seams improve readability until a truly rigged character asset is supplied.
for(const sx of [-1,1]){mesh(new THREE.SphereGeometry(.022,8,6),eyeMat,sx*.073,1.79,.177,player);box(player,sx*.073,1.83,.176,.07,.018,.026,browMat);mesh(new THREE.SphereGeometry(.043,8,6),M.skin,sx*.206,1.73,0,player);box(player,sx*.13,.13,.035,.18,.12,.28,shoeMat);}
box(player,0,1.45,.095,.32,.08,.09,collarMat);box(player,0,.49,.02,.43,.10,.29,M.pants);
player.scale.setScalar(.88);
// Lightweight procedural rig: pivot the limbs at shoulders/hips for a visible walk cycle.
const walkRig={legs:[],arms:[]};
for(const side of [-1,1]){const hip=new THREE.Group();hip.position.set(side*.13,.79,0);player.add(hip);
  box(hip,0,-.36,0,.15,.72,.18,M.pants);box(hip,0,-.705,.045,.17,.16,.29,shoeMat);walkRig.legs.push(hip);
  const shoulder=new THREE.Group();shoulder.position.set(side*.31,1.38,0);player.add(shoulder);
  const sleeve=box(shoulder,0,-.16,0,.155,.31,.17,M.shirt);const forearm=box(shoulder,0,-.405,.005,.115,.23,.13,M.skin);forearm.position.y=-.405;const arm=shoulder;arm.rotation.z=side*-.08;walkRig.arms.push(arm);
}
player.visible=false;let walkCycle=0;
let mode='title',startedAt=0,crashAt=0,found=false,steer=0,braking=false,toastTimer=0;let chaseShown=false,rafiHealth=100,customerHealth=100,fightCooldown=0,blockHeld=false,dodgeTime=0,customerAttackTimer=2.2,rafiFightStarted=false;const fade=document.querySelector('#fade'),caption=document.querySelector('#caption'),hint=document.querySelector('#hint'),controls=document.querySelector('#controls'),objective=document.querySelector('#objective-text'),phase=document.querySelector('#phase-label');
function say(t,ms=2800){caption.textContent=t;caption.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>caption.classList.add('hidden'),ms)}function fadeTo(v){fade.style.opacity=String(v)}function setObjective(t,p='PROLOGUE'){objective.textContent=t;phase.textContent=p}function hold(id,fn){const b=document.querySelector(id);b.addEventListener('pointerdown',e=>{e.preventDefault();fn(true)});for(const ev of ['pointerup','pointercancel','pointerleave'])b.addEventListener(ev,()=>fn(false))}

// Sandbox weapon system. Story missions remain unarmed; weapons are available only in Free Roam on foot.
const weaponCatalog={
 unarmed:{label:'UNARMED',damage:0,range:0,rate:.25,magSize:0},
 pistol:{label:'PISTOL',damage:34,range:62,rate:.32,magSize:12},
 smg:{label:'SMG',damage:17,range:48,rate:.105,magSize:30},
 shotgun:{label:'SHOTGUN',damage:72,range:22,rate:.78,magSize:6}
};
const weaponAmmo={pistol:{mag:12,reserve:48},smg:{mag:30,reserve:120},shotgun:{mag:6,reserve:24}};
let selectedWeapon='pistol',weaponCooldown=0,fireHeld=false,lastWeaponAlert=0,weaponWheelReturnMode='freeRoam';
const weaponModels={};
function buildWeaponModel(kind){
 const g=new THREE.Group(),steel=mat(0x25292b,.34,.72),dark=mat(0x111416,.6,.15),grip=mat(0x312b25,.8),brass=mat(0x9f7542,.45,.55);
 if(kind==='pistol'){
  box(g,0,.015,0,.13,.12,.36,steel);box(g,0,.035,-.205,.06,.065,.19,dark);box(g,0,-.075,.075,.09,.18,.11,grip);box(g,0,-.05,.12,.07,.06,.035,brass);
 }else if(kind==='smg'){
  box(g,0,.015,0,.16,.15,.46,steel);box(g,0,.025,-.34,.055,.06,.32,dark);box(g,0,-.12,.05,.095,.21,.13,dark);box(g,0,.015,.29,.13,.12,.19,grip);box(g,0,-.1,-.015,.07,.14,.10,steel);
 }else if(kind==='shotgun'){
  box(g,0,.015,0,.13,.13,.48,grip);box(g,0,.03,-.40,.055,.06,.48,steel);box(g,0,-.055,-.1,.09,.08,.34,dark);box(g,0,-.11,.18,.08,.19,.14,grip);
 }
 g.position.set(.34,1.31,.19);g.rotation.y=Math.PI;g.visible=false;player.add(g);return g;
}
for(const name of ['pistol','smg','shotgun'])weaponModels[name]=buildWeaponModel(name);
const weaponRaycaster=new THREE.Raycaster();weaponRaycaster.far=80;
function weaponModeActive(){return freeRoamActive&&freeRoamOnFoot&&mode==='freeRoam'}
function syncWeaponHud(){
 const hud=document.querySelector('#weapon-status'),controlsEl=document.querySelector('#weapon-controls'),reticle=document.querySelector('#aim-reticle');
 const active=weaponModeActive();
 controlsEl?.classList.toggle('hidden',!active);hud?.classList.toggle('hidden',!active);reticle?.classList.toggle('hidden',!active||selectedWeapon==='unarmed');
 for(const [name,model] of Object.entries(weaponModels))model.visible=active&&selectedWeapon===name;
 document.querySelector('#weapon-name').textContent=weaponCatalog[selectedWeapon].label;
 const ammo=weaponAmmo[selectedWeapon];document.querySelector('#weapon-ammo').textContent=ammo?`${ammo.mag} / ${ammo.reserve}`:'—';
 document.querySelector('#weapon-wheel-selected').textContent=weaponCatalog[selectedWeapon].label;
 document.querySelectorAll('.weapon-slot').forEach(b=>{const name=b.dataset.weapon,rounds=weaponAmmo[name];b.classList.toggle('selected',name===selectedWeapon);const sm=b.querySelector('small');if(sm)sm.textContent=rounds?`${rounds.mag} / ${rounds.reserve}`:name==='unarmed'?'Hands only':'—'});
}
function chooseWeapon(name){if(!(name in weaponCatalog))return;selectedWeapon=name;syncWeaponHud();closeWeaponWheel()}
function openWeaponWheel(){if(!weaponModeActive())return;weaponWheelReturnMode=mode;mode='weaponWheel';fireHeld=false;document.querySelector('#weapon-wheel').classList.remove('hidden');document.querySelector('#weapon-wheel').setAttribute('aria-hidden','false');syncWeaponHud()}
function closeWeaponWheel(){const wheel=document.querySelector('#weapon-wheel');if(!wheel.classList.contains('hidden')){wheel.classList.add('hidden');wheel.setAttribute('aria-hidden','true');if(mode==='weaponWheel')mode=weaponWheelReturnMode||'freeRoam'}syncWeaponHud()}
function reloadWeapon(){if(!weaponModeActive())return;const ammo=weaponAmmo[selectedWeapon],def=weaponCatalog[selectedWeapon];if(!ammo||!def.magSize){say('No magazine to reload.',850);return}if(ammo.mag>=def.magSize){say('Magazine already full.',850);return}if(ammo.reserve<=0){say('No reserve ammunition.',950);return}const need=def.magSize-ammo.mag,take=Math.min(need,ammo.reserve);ammo.mag+=take;ammo.reserve-=take;syncWeaponHud();window.KochiAudio?.playImpactSfx?.('reload');say(`${def.label} reloaded.`,750);}
function alertPoliceForWeapon(){const now=performance.now();if(now-lastWeaponAlert>2200){wantedLevel=Math.min(5,wantedLevel+1);policeHeat=Math.max(policeHeat,26);lastWeaponAlert=now;document.querySelector('#wanted-level').textContent='★'.repeat(wantedLevel)+'☆'.repeat(5-wantedLevel)}}
function shootWeapon(){
 if(!weaponModeActive()||selectedWeapon==='unarmed'||weaponCooldown>0)return;
 const def=weaponCatalog[selectedWeapon],ammo=weaponAmmo[selectedWeapon];if(!ammo)return;
 if(ammo.mag<=0){weaponCooldown=.32;say('MAGAZINE EMPTY · RELOAD',850);return}
 ammo.mag--;weaponCooldown=def.rate;syncWeaponHud();window.KochiAudio?.playWeaponSfx?.(selectedWeapon);alertPoliceForWeapon();
 // Third-person cameras look back at Vivek; aiming directly from the camera centre can send
 // shots through his body and into the ground. Aim a little above screen-centre, then cast from
 // the actual muzzle toward that point so the projectile travels outward from the player.
 player.rotation.y=cameraYaw+Math.PI;player.updateMatrixWorld(true);
 const targets=freeRoamNPCs.filter(n=>n.group.visible&&n.group.userData.weaponHealth>0).map(n=>n.group);
 const aimRay=new THREE.Raycaster();aimRay.setFromCamera(new THREE.Vector2(0,.08),camera);aimRay.near=0;aimRay.far=def.range;
 const cameraHits=targets.length?aimRay.intersectObjects(targets,true):[];
 const muzzle=player.localToWorld(new THREE.Vector3(.34,1.34,.48));
 const aimPoint=cameraHits.length?cameraHits[0].point.clone():aimRay.ray.origin.clone().addScaledVector(aimRay.ray.direction,def.range);
 const shotDirection=aimPoint.clone().sub(muzzle).normalize();
 weaponRaycaster.ray.origin.copy(muzzle);weaponRaycaster.ray.direction.copy(shotDirection);weaponRaycaster.near=0;weaponRaycaster.far=def.range;
 const hits=targets.length?weaponRaycaster.intersectObjects(targets,true):[];
 let impact=null,targetNpc=null;
 if(hits.length&&hits[0].distance<=def.range){impact=hits[0].point.clone();let node=hits[0].object;while(node&&node!==scene){targetNpc=freeRoamNPCs.find(n=>n.group===node)||targetNpc;if(targetNpc)break;node=node.parent}}
 const end=impact||muzzle.clone().addScaledVector(shotDirection,def.range);
 const tracer=new THREE.Line(new THREE.BufferGeometry().setFromPoints([muzzle,end]),new THREE.LineBasicMaterial({color:selectedWeapon==='shotgun'?0xffcf8c:0xf2d5a5,transparent:true,opacity:.9}));scene.add(tracer);setTimeout(()=>{scene.remove(tracer);tracer.geometry.dispose();tracer.material.dispose()},75);
 if(targetNpc){
  window.KochiAudio?.playImpactSfx?.('hit');
  targetNpc.group.userData.weaponHealth=(targetNpc.group.userData.weaponHealth??100)-def.damage;
  targetNpc.group.rotation.z=.12;
  for(const limb of targetNpc.legs)limb.rotation.x=.45;
  say(targetNpc.group.userData.weaponHealth<=0?'CIVILIAN DOWN · POLICE ALERT':'HIT CONFIRMED',650);
  if(targetNpc.group.userData.weaponHealth<=0){targetNpc.group.visible=false;wantedLevel=Math.min(5,wantedLevel+2);policeHeat=Math.max(policeHeat,34);document.querySelector('#wanted-level').textContent='★'.repeat(wantedLevel)+'☆'.repeat(5-wantedLevel)}
 }
}
function tickWeapons(dt){if(!weaponModeActive()){fireHeld=false;return}weaponCooldown=Math.max(0,weaponCooldown-dt);if(fireHeld&&selectedWeapon!=='unarmed'&&weaponCooldown<=0)shootWeapon()}
hold('#fire',v=>{fireHeld=v;if(v&&selectedWeapon!=='unarmed'&&weaponCatalog[selectedWeapon].rate>.25)shootWeapon()});
document.querySelector('#weapon-select').addEventListener('click',openWeaponWheel);
document.querySelector('#weapon-wheel-close').addEventListener('click',closeWeaponWheel);
document.querySelectorAll('.weapon-slot').forEach(b=>b.addEventListener('click',()=>chooseWeapon(b.dataset.weapon)));
document.querySelector('#reload').addEventListener('click',reloadWeapon);
document.querySelector('#holster').addEventListener('click',()=>chooseWeapon('unarmed'));
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(mode==='weaponWheel'&&k==='escape'){closeWeaponWheel();return}if(mode==='map'&&(k==='escape'||k==='m')){closeWorldMap();return}if(k==='m'&&['freeRoam','missionWalk','missionDrive','rafi','aftermath','drive','failure'].includes(mode)){openWorldMap();return}if(k==='r'&&weaponModeActive())reloadWeapon();if(weaponModeActive()&&['1','2','3','4'].includes(k))chooseWeapon(({1:'pistol',2:'smg',3:'shotgun',4:'unarmed'})[k]);if(k==='f'&&weaponModeActive())fireHeld=true});
addEventListener('keyup',e=>{if(e.key.toLowerCase()==='f')fireHeld=false});

hold('#left',v=>{steer=v?-1:0});hold('#right',v=>{steer=v?1:0});hold('#brake',v=>{braking=v});let throttle=false,reverseHeld=false;hold('#throttle',v=>{throttle=v});hold('#reverse',v=>{reverseHeld=v});const walk={up:false,down:false,left:false,right:false};hold('#up',v=>walk.up=v);hold('#down',v=>walk.down=v);hold('#walk-left',v=>walk.left=v);hold('#walk-right',v=>walk.right=v);
document.querySelector('#begin').onclick=()=>{document.querySelector('#title-card').classList.add('hidden');document.body.classList.add('cinema');controls.classList.remove('hidden');document.querySelector('#drive-controls').classList.remove('hidden');document.querySelector('#walk-controls').classList.add('hidden');hint.classList.remove('hidden');mode='drive';startedAt=performance.now();chaseElapsed=0;chaseShown=false;pursuer.visible=false;driveCar.position.set(0,.02,10);driveCar.rotation.y=0;carSpeed=0;carYaw=0;setObjective('Keep the car on the road');say('KOCHI OUTSKIRTS · LATE NIGHT',2600)};
document.querySelector('#inspect').onclick=()=>{if(mode==='rafiDone'){mode='rafiEnd';document.querySelector('#fight-status').classList.add('hidden');document.querySelector('#walk-controls').classList.add('hidden');controls.classList.add('hidden');hint.classList.add('hidden');syncWeaponHud();document.body.classList.remove('cinema');document.querySelector('#end-card h2').textContent='RAFI’S DAY';document.querySelector('#end-card p').textContent='A broken-down car. A bad-tempered customer. Rafi gets back to work.';document.querySelector('#continue').textContent='RETURN TO THE WRECK';document.querySelector('#play-rafi').textContent='REPLAY RAFI’S DAY';document.querySelector('#end-card').classList.remove('hidden');return}if(mode!=='aftermath')return;const d=player.position.distanceTo(new THREE.Vector3(-1.2,0,-18));if(d<7){if(!found){found=true;setObjective('Clue found · cause unknown','THE MORNING AFTER');say('The car is wrecked. The cause is not clear from here.',4000)}else say('The wreck offers no easy answers.',3000)}else say('Move closer to the wreck first.',1800)};
document.querySelector('#continue').onclick=()=>{document.querySelector('#end-card').classList.add('hidden');mode='aftermath';player.visible=true;player.position.set(2,0,-11);camera.position.set(2,4,-3);setObjective('Inspect the wreck','THE MORNING AFTER');hint.textContent='Move around the roadside and inspect the wreck.';hint.classList.remove('hidden');controls.classList.remove('hidden');document.querySelector('#drive-controls').classList.add('hidden');document.querySelector('#walk-controls').classList.remove('hidden');document.querySelectorAll('.combat').forEach(b=>b.classList.add('hidden'));document.querySelector('#inspect').classList.remove('hidden');document.querySelector('#inspect').textContent='INSPECT WRECK';document.querySelector('#fight-status').classList.add('hidden')};
document.querySelector('#play-rafi').onclick=()=>{document.querySelector('#end-card').classList.add('hidden');document.body.classList.add('cinema');mode='rafi';player.visible=true;player.position.set(41,0,1);player.rotation.y=Math.PI/2;customer.position.set(52,0,-1);customer.visible=true;driveCar.visible=false;wreck.visible=false;pursuer.visible=false;rafiHealth=100;customerHealth=100;fightCooldown=0;dodgeTime=0;customerAttackTimer=2.2;rafiFightStarted=true;walkCycle=0;cameraYaw=0;cameraPitch=.16;cameraDistance=6;document.querySelector('#drive-controls').classList.add('hidden');document.querySelector('#walk-controls').classList.remove('hidden');document.querySelector('#inspect').classList.add('hidden');document.querySelectorAll('.combat').forEach(b=>b.classList.remove('hidden'));document.querySelector('#fight-status').classList.remove('hidden');controls.classList.remove('hidden');hint.textContent='Rafi’s Day: move with the left pad. PUNCH to counter, BLOCK to reduce damage, DODGE to evade. Drag the scene to rotate the camera.';hint.classList.remove('hidden');setObjective('Handle the aggressive customer','RAFI’S DAY');say('“You think you can talk to me like that?”',2600);updateFightStatus()};
function updateFightStatus(){document.querySelector('#rafi-health').textContent='RAFI '+Math.max(0,Math.round(rafiHealth))+'%';document.querySelector('#customer-status').textContent='CUSTOMER '+Math.max(0,Math.round(customerHealth))+'%'}
function fightAction(action){if(mode!=='rafi'||customerHealth<=0||rafiHealth<=0)return;if(action==='block'){blockHeld=true;playerCombatPose={type:'block',time:0,duration:0.01};return}if(fightCooldown>0)return;if(action==='dodge'){dodgeTime=.65;player.position.x+=Math.cos(player.rotation.y)*1.0;player.position.z-=Math.sin(player.rotation.y)*1.0;playerCombatPose={type:'dodge',time:0,duration:.55};fightCooldown=.55;say('Rafi slips away from the swing.',900);return}if(action==='punch'){const target=customer.getWorldPosition(new THREE.Vector3());const d=player.position.distanceTo(target);player.rotation.y=Math.atan2(target.x-player.position.x,target.z-player.position.z);playerCombatPose={type:'punch',time:0,duration:.52};if(d<2.25){window.KochiAudio?.playImpactSfx?.('punch');customerHealth=Math.max(0,customerHealth-17);customerCombatPose={type:customerHealth<=0?'knockdown':'hit',time:0,duration:customerHealth<=0?1.1:.5};customer.rotation.y=Math.atan2(player.position.x-target.x,player.position.z-target.z);say(customerHealth<=0?'The customer backs off.':'Rafi lands a quick counter.',900)}else say('Move closer before punching.',900);fightCooldown=.52;updateFightStatus();if(customerHealth<=0){mode='rafiDone';setObjective('Return to the repair job','RAFI’S DAY');say('The customer backs off. Rafi returns to work.',2200);document.querySelectorAll('.combat').forEach(b=>b.classList.add('hidden'));document.querySelector('#inspect').classList.remove('hidden');hint.textContent='The confrontation is over. Tap REPAIR JOB to finish Rafi’s introduction.';document.querySelector('#inspect').textContent='REPAIR JOB'}return}}
let playerCombatPose={type:'idle',time:0,duration:0},customerCombatPose={type:'idle',time:0,duration:0};
function setPose(which,type,duration){if(which==='player')playerCombatPose={type,time:0,duration};else customerCombatPose={type,time:0,duration};}
function updateCombatPoses(dt){
  const p=playerCombatPose;p.time+=dt;
  // These are articulated pivot animations for the current procedural mesh rig, not imported skeletal clips.
  let pFade=p.duration>0?Math.max(0,1-p.time/p.duration):0;
  for(const a of walkRig.arms){a.rotation.x=THREE.MathUtils.damp(a.rotation.x,0,12,dt);a.rotation.z=THREE.MathUtils.damp(a.rotation.z,0,12,dt)}
  if(p.type==='punch'&&pFade>0){const t=p.time/p.duration;const lead=walkRig.arms[1];lead.rotation.x=t<.24?THREE.MathUtils.smoothstep(t,0,.24)*.62:t<.53?THREE.MathUtils.lerp(.62,1.38,THREE.MathUtils.smoothstep(t,.24,.53)):THREE.MathUtils.lerp(1.38,0,THREE.MathUtils.smoothstep(t,.53,1));lead.rotation.z=-.1;walkRig.arms[0].rotation.x=.58*pFade;player.rotation.z=THREE.MathUtils.damp(player.rotation.z,Math.sin(t*Math.PI)*-.045,14,dt)}
  else if(p.type==='block'&&blockHeld){walkRig.arms[0].rotation.x=.78;walkRig.arms[1].rotation.x=.86;walkRig.arms[0].rotation.z=-.25;walkRig.arms[1].rotation.z=.25}
  else if(p.type==='dodge'&&pFade>0){const t=p.time/p.duration;player.rotation.z=THREE.MathUtils.damp(player.rotation.z,Math.sin(t*Math.PI)*.13,12,dt);walkRig.legs[0].rotation.x=THREE.MathUtils.damp(walkRig.legs[0].rotation.x,-.32*pFade,8,dt);walkRig.legs[1].rotation.x=THREE.MathUtils.damp(walkRig.legs[1].rotation.x,.22*pFade,8,dt)}
  else if(p.type==='hit'&&pFade>0){player.rotation.z=THREE.MathUtils.damp(player.rotation.z,-.16*pFade,10,dt);walkRig.arms[0].rotation.x=-.45*pFade;walkRig.arms[1].rotation.x=-.32*pFade}
  else {player.rotation.z=THREE.MathUtils.damp(player.rotation.z,0,10,dt);if(p.duration>0&&p.time>=p.duration)playerCombatPose={type:'idle',time:0,duration:0}}
  if(p.type==='block'&&blockHeld){playerCombatPose.time=0;playerCombatPose.duration=0.01}else if(p.type==='block'&&!blockHeld){playerCombatPose={type:'idle',time:0,duration:0}}
  const e=customerCombatPose;e.time+=dt;const ef=e.duration>0?Math.max(0,1-e.time/e.duration):0;
  for(const a of enemyArms){a.rotation.x=THREE.MathUtils.damp(a.rotation.x,0,10,dt);a.rotation.z=THREE.MathUtils.damp(a.rotation.z,0,10,dt)}
  if(e.type==='attack'&&ef>0){const t=e.time/e.duration;enemyArms[0].rotation.x=.12+Math.sin(Math.min(1,t*1.8)*Math.PI)*1.05;enemyArms[1].rotation.x=.35}
  else if(e.type==='hit'&&ef>0){enemyArms[0].rotation.x=-.72*ef;enemyArms[1].rotation.x=.48*ef;customer.rotation.z=THREE.MathUtils.damp(customer.rotation.z,.12*ef,9,dt);if(e.time>=e.duration){customerCombatPose={type:'idle',time:0,duration:0};customer.rotation.z=0}}
  else if(e.type==='knockdown'&&e.time<e.duration){customer.rotation.z=THREE.MathUtils.damp(customer.rotation.z,-.9,5,dt);customer.position.y=THREE.MathUtils.damp(customer.position.y,.12,5,dt)}
  else if(e.type==='knockdown'&&e.time>=e.duration){customerCombatPose={type:'down',time:0,duration:0};}
  else if(e.type==='down'){customer.rotation.z=THREE.MathUtils.damp(customer.rotation.z,-.9,5,dt);customer.position.y=THREE.MathUtils.damp(customer.position.y,.12,5,dt)}
  else if(e.type==='attack'&&e.time>=e.duration){customerCombatPose={type:'idle',time:0,duration:0}}
}
document.querySelector('#punch').onclick=()=>fightAction('punch');document.querySelector('#block').addEventListener('pointerdown',e=>{e.preventDefault();fightAction('block')});for(const ev of ['pointerup','pointercancel','pointerleave'])document.querySelector('#block').addEventListener(ev,()=>{blockHeld=false;if(playerCombatPose.type==='block')playerCombatPose={type:'idle',time:0,duration:0}});document.querySelector('#dodge').onclick=()=>fightAction('dodge');
const keys={};addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key==='ArrowLeft')steer=-1;if(e.key==='ArrowRight')steer=1;if(e.key===' '&&mode==='drive')braking=true;if(e.key.toLowerCase()==='e')document.querySelector('#inspect').click();if(e.key.toLowerCase()==='j')fightAction('punch');if(e.key.toLowerCase()==='k')fightAction('block');if(e.key.toLowerCase()==='l')fightAction('dodge')});addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;if(e.key==='ArrowLeft'&&steer===-1)steer=0;if(e.key==='ArrowRight'&&steer===1)steer=0;if(e.key===' ')braking=false;if(e.key.toLowerCase()==='k')blockHeld=false});
// Drag to orbit the camera. Controls/cards are excluded so button presses never rotate the view.
let cameraYaw=0,cameraPitch=.22,cameraDistance=8,dragging=false,lastX=0,lastY=0;
renderer.domElement.addEventListener('pointerdown',e=>{if(e.target.closest('button')||mode==='title'||mode==='end')return;dragging=true;lastX=e.clientX;lastY=e.clientY;renderer.domElement.setPointerCapture?.(e.pointerId)});
renderer.domElement.addEventListener('pointermove',e=>{if(!dragging)return;const dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;cameraYaw-=dx*.008;cameraPitch=THREE.MathUtils.clamp(cameraPitch+dy*.006,-.15,.8)});
for(const ev of ['pointerup','pointercancel','pointerleave'])renderer.domElement.addEventListener(ev,()=>dragging=false);
function followCamera(target,dist=cameraDistance){const horizontal=Math.cos(cameraPitch)*dist;const desired=new THREE.Vector3(target.x+Math.sin(cameraYaw)*horizontal,target.y+2.1+Math.sin(cameraPitch)*dist,target.z+Math.cos(cameraYaw)*horizontal);camera.position.lerp(desired,.16);camera.lookAt(target.x,target.y+1,target.z)}
const clock=new THREE.Clock();let carYaw=0,carSpeed=0;const driveCar=new THREE.Group();driveCar.position.set(0,.02,10);scene.add(driveCar);box(driveCar,0,.58,0,1.95,.58,3.8,M.rust);box(driveCar,0,1.03,-.18,1.58,.62,1.85,M.glass);for(const x of [-.98,.98])for(const z of [-1.18,1.18]){const wh=cyl(driveCar,x,.32,z,.31,.31,.2,M.rubber,12);wh.rotation.z=Math.PI/2}driveCar.add(driver);for(const x of [-.56,.56]){mesh(new THREE.BoxGeometry(.36,.14,.08),new THREE.MeshBasicMaterial({color:0xffe0ac}),x,.7,-1.92,driveCar);const beam=new THREE.SpotLight(0xffd6a0,8,23,.36,.55,1.4);beam.position.set(x,.7,-1.85);beam.target.position.set(x,0,-18);driveCar.add(beam,beam.target)}
// Unidentified vehicle: a distant, deliberately anonymous presence during the prologue.
const pursuer=new THREE.Group();scene.add(pursuer);box(pursuer,0,.55,0,1.85,.55,3.6,mat(0x171a1c,.42));box(pursuer,0,.98,-.12,1.45,.52,1.55,M.glass);for(const x of [-.5,.5]){mesh(new THREE.BoxGeometry(.32,.12,.07),new THREE.MeshBasicMaterial({color:0xffe2b7}),x,.68,-1.82,pursuer)}pursuer.visible=false;let chaseElapsed=0;
// A compact garage set for Rafi's separate playable introduction.
const garage=new THREE.Group();garage.position.set(45,0,0);scene.add(garage);box(garage,0,-.1,0,30,.2,24,mat(0x353a38));box(garage,0,4,-10,30,8,.45,mat(0x3b3933));box(garage,-14,2,-2,.45,4,16,mat(0x3b3933));box(garage,14,2,-2,.45,4,16,mat(0x3b3933));box(garage,0,7,-2,30,.3,16,mat(0x282d2c));for(let x=-10;x<=10;x+=5){const lamp=mesh(new THREE.BoxGeometry(2,.08,.35),M.lamp,x,6.55,-3,garage);const glow=new THREE.PointLight(0xffbd7a,7,12,2);glow.position.set(x,6,-3);garage.add(glow)}box(garage,-8,.7,-3,3,1.2,1.5,M.metal);box(garage,-8,1.35,-3,3,.15,1.5,M.rust);for(let x=-11;x<-4;x+=1.2)cyl(garage,x,.8,-6,.07,.07,1.6,M.metal,8);
const customer=new THREE.Group();garage.add(customer);cyl(customer,0,1.05,0,.28,.3,.7,mat(0x4a5660),12);mesh(new THREE.SphereGeometry(.2,12,10),M.skin,0,1.62,0,customer);mesh(new THREE.SphereGeometry(.205,12,8,0,Math.PI*2,0,Math.PI*.55),M.rubber,0,1.68,0,customer);const enemyArms=[];for(const side of [-1,1]){const armPivot=new THREE.Group();armPivot.position.set(side*.3,1.32,0);customer.add(armPivot);box(armPivot,0,-.28,0,.14,.56,.14,M.skin);enemyArms.push(armPivot)}customer.position.set(7,0,-1);customer.visible=false;
function crash(){mode='crash';pursuer.visible=false;crashAt=performance.now();setObjective('');say('THE BRAKES ARE NOT RESPONDING',1900);driveCar.visible=false;fadeTo(1);setTimeout(()=>{wreck.visible=true;if(abraham)abraham.visible=false},600);setTimeout(()=>{fadeTo(0);document.body.classList.remove('cinema');document.querySelector('#end-card').classList.remove('hidden');controls.classList.add('hidden');hint.classList.add('hidden');say('RAIN. SILENCE. DISTANT TRAFFIC.',2800);mode='end'},1600)}
function animate(){requestAnimationFrame(animate);try{const dt=Math.min(clock.getDelta(),.04),now=performance.now();if(mode==='freeRoam'){updateFreeRoam(dt);
 }else if(mode==='drive'){
  const inputThrottle=throttle||keys.w||keys.arrowup;
  const inputReverse=reverseHeld||keys.x;
  const inputBrake=braking||keys.s||keys.arrowdown;
  // Brake slows the car; REVERSE first slows forward motion, then moves backward.
  if(inputThrottle&&!inputReverse)carSpeed=Math.min(carSpeed+dt*5.2,13);
  else if(inputReverse){if(carSpeed>0)carSpeed=Math.max(0,carSpeed-dt*8.5);else carSpeed=Math.max(-4.5,carSpeed-dt*3.0)}
  else if(!inputBrake)carSpeed=carSpeed>0?Math.max(0,carSpeed-dt*1.05):Math.min(0,carSpeed+dt*1.05);
  if(inputBrake)carSpeed=carSpeed>0?Math.max(0,carSpeed-dt*8.5):Math.min(0,carSpeed+dt*8.5);
  const steerStrength=.12+Math.min(Math.abs(carSpeed)/10,1)*.46;
  if(Math.abs(carSpeed)>.35)carYaw-=steer*dt*steerStrength*Math.sign(carSpeed);
  driveCar.position.x-=Math.sin(carYaw)*carSpeed*dt;
  driveCar.position.z-=Math.cos(carYaw)*carSpeed*dt;
  driveCar.rotation.y=carYaw;
  followCamera(new THREE.Vector3(driveCar.position.x,driveCar.position.y,driveCar.position.z-1.2),firstPersonView?.7:cameraDistance+2);
  // The unknown car appears after the opening stretch and follows at a distance. No identity or motive is shown.
  chaseElapsed=now-startedAt;
  if(chaseElapsed>1800){chaseShown=true;pursuer.visible=(Math.floor(chaseElapsed/850)%4!==2);const behind=new THREE.Vector3(driveCar.position.x+Math.sin(carYaw)*9,0,driveCar.position.z+Math.cos(carYaw)*11);pursuer.position.lerp(behind,.055);pursuer.rotation.y=carYaw;if(chaseElapsed>3600&&chaseElapsed<7600&&Math.floor(chaseElapsed/1300)%2===0){setObjective('Lose the vehicle behind you');}else if(chaseElapsed<9000)setObjective('Keep driving · unknown vehicle following');if(chaseElapsed>6000&&chaseElapsed<7800&&Math.floor(chaseElapsed/700)%2===0)say('Headlights fill the rear window.',1100)}
  // Brake failure remains a separate event. The chase does not prove sabotage.
  if(now-startedAt>9500){say('The brake pedal drops to the floor.',2400);mode='failure';crashAt=now;}
  if(Math.abs(driveCar.position.x)>6.6){driveCar.position.x=THREE.MathUtils.clamp(driveCar.position.x,-6.6,6.6);carSpeed*=.72;steer=0}
}else if(mode==='failure'){
  carSpeed=Math.min(15,carSpeed+dt*1.2);carYaw-=steer*dt*.68;
  driveCar.position.x-=Math.sin(carYaw)*carSpeed*dt;driveCar.position.z-=Math.cos(carYaw)*carSpeed*dt;driveCar.rotation.y=carYaw;
  followCamera(new THREE.Vector3(driveCar.position.x,driveCar.position.y,driveCar.position.z-1),cameraDistance+1);
  if(now-crashAt>3200)crash();
}else if(mode==='rafi'||mode==='rafiDone'){
  const f=(walk.up||keys.w||keys.arrowup?1:0)-(walk.down||keys.s||keys.arrowdown?1:0);const side=(walk.right||keys.d||keys.arrowright?1:0)-(walk.left||keys.a||keys.arrowleft?1:0);const move=new THREE.Vector3(side,0,-f);let moving=false;if(move.lengthSq()>0){moving=true;move.normalize();player.position.addScaledVector(move,dt*2.7);player.rotation.y=Math.atan2(move.x,move.z)}player.position.x=THREE.MathUtils.clamp(player.position.x,37,55);player.position.z=THREE.MathUtils.clamp(player.position.z,-7,7);if(moving){walkCycle+=dt*8;const swing=Math.sin(walkCycle)*.48;walkRig.legs[0].rotation.x=swing;walkRig.legs[1].rotation.x=-swing;walkRig.arms[0].rotation.x=-swing*.6;walkRig.arms[1].rotation.x=swing*.6}else{for(const limb of [...walkRig.legs,...walkRig.arms])limb.rotation.x=THREE.MathUtils.damp(limb.rotation.x,0,9,dt)}
  if(mode==='rafi'){fightCooldown=Math.max(0,fightCooldown-dt);dodgeTime=Math.max(0,dodgeTime-dt);customerAttackTimer-=dt;const targetPos=customer.getWorldPosition(new THREE.Vector3());const delta=new THREE.Vector3(player.position.x-targetPos.x,0,player.position.z-targetPos.z);const dist=delta.length();if(dist>1.65){delta.normalize();const nextWorld=targetPos.clone().addScaledVector(delta,dt*.8);customer.position.copy(nextWorld);customer.rotation.y=Math.atan2(-delta.x,-delta.z)}if(customerAttackTimer<=0&&dist<2.7&&customerCombatPose.type!=='attack'){customerCombatPose={type:'attack',time:0,duration:.68,hitApplied:false};customerAttackTimer=2.1}if(customerCombatPose.type==='attack'&&customerCombatPose.time>=.32&&!customerCombatPose.hitApplied){customerCombatPose.hitApplied=true;const nowPos=customer.getWorldPosition(new THREE.Vector3());const hitDist=player.position.distanceTo(nowPos);if(hitDist<2.9){if(dodgeTime<=0){rafiHealth=Math.max(0,rafiHealth-(blockHeld?4:12));playerCombatPose={type:'hit',time:0,duration:.5};say(blockHeld?'Rafi absorbs part of the hit.':'The customer lands a hit.',800)}else say('Rafi dodges the swing.',800);updateFightStatus();if(rafiHealth<=0){rafiHealth=35;const resetWorld=new THREE.Vector3(player.position.x+2.4,0,player.position.z);customer.position.copy(resetWorld);say('Rafi regains his footing, badly winded. Keep your distance and counter.',1800);updateFightStatus()}}}if(blockHeld)customerAttackTimer=Math.min(customerAttackTimer,1.2)}
  updateCombatPoses(dt);followCamera(new THREE.Vector3(player.position.x,player.position.y,player.position.z),cameraDistance);
}else if(mode==='aftermath'){
  const f=(walk.up||keys.w||keys.arrowup?1:0)-(walk.down||keys.s||keys.arrowdown?1:0);
  const s=(walk.right||keys.d||keys.arrowright?1:0)-(walk.left||keys.a||keys.arrowleft?1:0);
  const move=new THREE.Vector3(s,0,-f);let moving=false;
  if(move.lengthSq()>0){moving=true;move.normalize();move.applyAxisAngle(new THREE.Vector3(0,1,0),cameraYaw);player.position.addScaledVector(move,dt*3.1);player.rotation.y=Math.atan2(move.x,move.z)}
  // Animate the placeholder's arms and legs while moving; ease back to idle when stopped.
  if(moving){walkCycle+=dt*9;const swing=Math.sin(walkCycle)*.62;walkRig.legs[0].rotation.x=swing;walkRig.legs[1].rotation.x=-swing;walkRig.arms[0].rotation.x=-swing*.72;walkRig.arms[1].rotation.x=swing*.72;player.position.y=Math.abs(Math.sin(walkCycle*2))*.035}
  else{walkCycle=0;player.position.y=THREE.MathUtils.damp(player.position.y,0,10,dt);for(const limb of [...walkRig.legs,...walkRig.arms]){limb.rotation.x=THREE.MathUtils.damp(limb.rotation.x,0,10,dt)}}
  player.position.x=THREE.MathUtils.clamp(player.position.x,-7,7);player.position.z=THREE.MathUtils.clamp(player.position.z,-37,5);
  followCamera(new THREE.Vector3(player.position.x,player.position.y,player.position.z),cameraDistance);
}const p=rainGeo.attributes.position;for(let i=0;i<rainCount;i++){p.array[i*3+1]-=dt*11;if(p.array[i*3+1]<0){p.array[i*3+1]=16+Math.random()*2;p.array[i*3]=camera.position.x+(Math.random()-.5)*38;p.array[i*3+2]=camera.position.z+(Math.random()-.5)*42}}p.needsUpdate=true;amber.intensity=23+Math.sin(now*.002)*2;redLight.intensity=16+Math.sin(now*.006)*7;window.KochiAudio?.updateWorldAudio?.({driving:((mode==='freeRoam'&&!freeRoamOnFoot)||['drive','failure','missionDrive'].includes(mode))&&driveCar.visible,speed:Math.abs(carSpeed)*GAME_METERS_PER_UNIT*3.6,accelerating:throttle||reverseHeld,ambient:freeRoamActive&&!['paused','map','phone'].includes(mode)});renderer.render(scene,camera)}catch(err){console.error('Gameplay frame update failed:',err);if(!window.__kochiFrameErrorShown){window.__kochiFrameErrorShown=true;const cap=document.querySelector('#caption');if(cap){cap.textContent='GAME LOOP WARNING · A gameplay update failed. Return to the menu and reload.';cap.classList.remove('hidden')}}try{renderer.render(scene,camera)}catch(renderErr){console.error('Renderer recovery failed:',renderErr)}}cameraYaw=0;cameraPitch=.22;camera.position.set(0,4,20);camera.lookAt(0,0,0);animate();addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});

/* -------------------------------------------------------------------------
   KOCHI: HOMECOMING — ACT I CAMPAIGN LAYER
   Adds a selectable, story-driven sequence for all 13 Act I scenes plus one
   optional roadside-assistance activity. Story mysteries stay unresolved.
--------------------------------------------------------------------------- */
const missionBoard=document.querySelector('#mission-board');
const missionList=document.querySelector('#mission-list');
const dialoguePanel=document.querySelector('#dialogue-panel');
const dialogueSpeaker=document.querySelector('#dialogue-speaker');
const dialogueLine=document.querySelector('#dialogue-line');
const dialogueNext=document.querySelector('#dialogue-next');
let currentMissionId=0,missionStage=0,missionStartedAt=0,missionDriveStart=0;
let cashBalance=2500,pausedMode=null;
let dialogueLines=[],dialogueIndex=0,dialogueReturnMode='missionWalk',dialogueControlsHidden=true,dialogueDone=null;
let walkBounds={minX:-7,maxX:7,minZ:-37,maxZ:5};
const completedMissions=new Set();
let warehouseCarArrived=false,unknownCarDeparting=false,shakeUntil=0,warehouseCutscene=false;

const missionData=[
 {id:1,title:'The Accident',chapter:'PROLOGUE',year:'2026 · NIGHT',character:'ABRAHAM',type:'DRIVING / CHASE',summary:'On a rain-soaked road outside Kochi, Abraham notices an unidentified vehicle following him. His brakes fail at a bend; the pursuer’s purpose remains unknown.',objective:'Keep driving through the rain. Survive the chase.',story:'Tutorial drive → several anonymous vehicles follow at a distance → the brake pedal fails → Abraham crashes and dies. The chase is not proof of sabotage.'},
 {id:2,title:'The Call',chapter:'CHAPTER 1 · HOMECOMING',year:'2026 · EARLY MORNING',character:'VIVEK',type:'STORY / INTERACTION',summary:'At his residence outside Kochi, Vivek receives a call from a family member: his father Abraham is dead.',objective:'Answer the phone.',story:'The call delivers the news. Vivek must pack and return to Kochi; this mission establishes the loss without revealing what happened.'},
 {id:3,title:'Back to Kochi',chapter:'CHAPTER 1 · HOMECOMING',year:'2026 · DAY',character:'VIVEK',type:'EXPLORATION / NPC',summary:'Vivek returns to the family home. Kochi goes on around him while the house feels changed.',objective:'Speak to the relative waiting at home.',story:'A relative says: “They said it was an accident.” Vivek enters the house and begins confronting his father’s absence.'},
 {id:4,title:'A House Full of Silence',chapter:'CHAPTER 1 · HOMECOMING',year:'2026 · LATE AFTERNOON',character:'VIVEK',type:'INVESTIGATION',summary:'In Abraham’s room, Vivek finds photos, papers and car keys.',objective:'Examine the room, papers and keys; speak to the relative.',story:'The relative says the wrecked car has been released and Vivek can take it to a mechanic tomorrow. Nothing here explains the death.'},
 {id:5,title:'Rafi’s Day',chapter:'CHAPTER 2 · ANOTHER SIDE OF THE CITY',year:'2026 · MORNING',character:'RAFI',type:'MECHANIC TASK / FIGHT / NPC',summary:'Rafi deals with a customer whose car has broken down. A repair diagnosis turns into a brief, grounded fight.',objective:'Inspect the broken-down vehicle, handle the aggressive customer, then return to the repair job.',story:'Rafi’s practical nature comes through in the confrontation: “That’s why you brought it to one.” Later: “I’ll change what needs changing. Not everything that can be changed.” The customer is not established as part of a larger conspiracy.'},
 {id:6,title:'The Car',chapter:'CHAPTER 2 · ANOTHER SIDE OF THE CITY',year:'2026 · DAY',character:'VIVEK',type:'VEHICLE INVESTIGATION / NPC',summary:'Vivek brings Abraham’s damaged car to Rafi. The brake line’s condition concerns Rafi, but he cannot prove it was deliberate.',objective:'Inspect the damaged car and ask Rafi how he knew Abraham.',story:'Rafi knew Abraham as a recurring customer, but never knew everything about his life. The inspection raises a question, not a conclusion.'},
 {id:7,title:'The First Time',chapter:'CHAPTER 3 · BEFORE VIVEK',year:'2015 · NIGHT',character:'RAFI',type:'FLASHBACK / MECHANIC TASK',summary:'Rafi, around 21, meets Abraham for the first time at a small repair workplace on a rainy night.',objective:'Inspect and repair Abraham’s car; speak to Abraham before he leaves.',story:'Their first interaction is ordinary: a customer brings a car in, Rafi diagnoses and repairs it, Abraham pays and leaves. They are not yet close.'},
 {id:8,title:'What Rafi Remembers',chapter:'CHAPTER 3 · BEFORE VIVEK',year:'2026 · DAY',character:'VIVEK',type:'DIALOGUE / INVESTIGATION',summary:'Back at the garage, Vivek asks what Rafi remembers about his father and the damaged car.',objective:'Talk to Rafi and review the inspection finding.',story:'Rafi says Abraham was a regular customer, but he never learned everything about him. Something about the car damage is not right, but intent remains unproven.'},
 {id:9,title:'The Date',chapter:'CHAPTER 4 · THE PAST DOES NOT STAY BURIED',year:'2026 · EVENING',character:'VIVEK',type:'EVIDENCE / EXPLORATION',summary:'Vivek searches Abraham’s papers and finds a photograph dated 2004.',objective:'Search the papers and examine the photograph.',story:'The photograph shows Abraham beside an Ambassador outside an industrial building. It provides a year and a lead, but neither Vivek nor Rafi can identify the exact location.'},
 {id:10,title:'The Warehouse',chapter:'CHAPTER 4 · THE PAST DOES NOT STAY BURIED',year:'2004 · AROUND 2 A.M.',character:'ABRAHAM',type:'FLASHBACK DRIVE / STEALTH APPROACH / CUTSCENE',summary:'Abraham drives an old white Ambassador to an isolated warehouse carrying a small black bag. Another car is waiting.',objective:'Drive to the warehouse, take the bag to the waiting figure.',story:'An unidentified person asks: “Did you open it?” Abraham answers: “No. I brought what you asked for.” A sudden noise and gunshots cut the scene to black. Identities, bag contents and outcome remain unknown.'},
 {id:11,title:'The Photograph',chapter:'CHAPTER 5 · CONNECTING THE PIECES',year:'2026 · EVENING',character:'VIVEK',type:'EVIDENCE / NPC DIALOGUE',summary:'Vivek shows Rafi the photograph. Neither can place the industrial building precisely.',objective:'Show Rafi the photograph and agree on the next steps.',story:'They agree to start with evidence. Rafi continues checking the car while Vivek searches Abraham’s papers. The player knows the 2004 warehouse scene; the characters do not.'},
 {id:12,title:'The Old Road',chapter:'CHAPTER 5 · CONNECTING THE PIECES',year:'2026 · NEXT DAY',character:'VIVEK',type:'EXPLORATION / NPC / UNKNOWN VEHICLE',summary:'Vivek and Rafi investigate an industrial area and enter a possible warehouse.',objective:'Inspect the marked patch of floor, then leave with Rafi.',story:'The floor looks as if something was moved recently, but it cannot establish who, when or what. A distant engine starts and headlights sweep the wall; an unknown vehicle leaves. Rafi advises against confrontation. This is not confirmed as the 2004 warehouse.'},
 {id:13,title:'The First Question',chapter:'CHAPTER 5 · ACT I FINALE',year:'2026 · NIGHT',character:'VIVEK',type:'EVIDENCE / DIALOGUE / FINALE',summary:'At Rafi’s garage, the car, photograph and inspection notes sit together on the workbench.',objective:'Review the evidence and ask Rafi the first question.',story:'Vivek asks what if Abraham’s death was not an accident. Rafi answers that they must find who knew enough to make it happen. The image returns to Abraham’s photograph. Act I ends with the questions open.'},
 {id:14,title:'Roadside Assistance',chapter:'OPTIONAL SIDE MISSION',year:'2026 · DAY',character:'VIVEK',type:'NPC / SIDE ACTIVITY',summary:'After the crash, roadside traffic and bystanders continue around the wreck. A stranded driver needs help moving a vehicle safely.',objective:'Talk to the stranded driver and help with the car.',story:'A small optional NPC encounter to make the roadside feel inhabited. It does not introduce a culprit or connect the driver to Abraham’s death.'}
];

// Modular low-poly locations; they are real interactive prototype spaces, not final photogrammetry.
function makePerson(name,shirtHex=0x59646b,parent=scene,x=0,z=0,scale=.94){
 const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(scale);parent.add(g);
 const shirt=clothMaterial(shirtHex),pants=M.pants;
 const torso=cyl(g,0,1.08,0,.255,.315,.72,shirt,14);torso.scale.set(1,1,.92);
 cyl(g,0,.47,0,.225,.255,.16,pants,10);
 // Neck, head, ears, eyes, nose, hairline and collar are kept proportional to a 1.7–1.85 m person.
 cyl(g,0,1.48,0,.09,.105,.16,M.skin,10);
 const head=mesh(new THREE.SphereGeometry(.195,18,14),M.skin,0,1.68,0,g);
 const hair=mesh(new THREE.SphereGeometry(.204,16,12,0,Math.PI*2,0,Math.PI*.60),M.rubber,0,1.73,-.012,g);
 const eye=mat(0x1a1715,.42),brow=mat(0x251d18,.9),earMat=M.skin,shoe=mat(0x17191b,.92);
 for(const side of [-1,1]){
  mesh(new THREE.SphereGeometry(.039,8,6),earMat,side*.195,1.67,0,g);
  mesh(new THREE.SphereGeometry(.022,8,6),eye,side*.067,1.69,.177,g);box(g,side*.067,1.725,.172,.065,.015,.024,brow);
 }
 mesh(new THREE.SphereGeometry(.032,8,6),M.skin,0,1.657,.188,g);
 if(/VIVEK|RAFI|ABRAHAM|CUSTOMER/i.test(name))box(g,0,1.625,.181,.12,.028,.025,mat(0x2a201b,.96));
 box(g,0,1.42,.10,.25,.07,.08,shirt);
 const arms=[],legs=[];
 for(const side of [-1,1]){
  const a=new THREE.Group();a.position.set(side*.30,1.36,0);g.add(a);box(a,0,-.16,0,.15,.32,.16,shirt);box(a,0,-.405,.005,.115,.22,.13,M.skin);arms.push(a);
  const l=new THREE.Group();l.position.set(side*.13,.78,0);g.add(l);box(l,0,-.36,0,.15,.72,.18,pants);box(l,0,-.72,.045,.17,.14,.28,shoe);legs.push(l);
 }
 // Simple pockets and seam lines add cloth structure even when no external textures are available.
 box(g,-.105,1.17,.272,.09,.12,.014,mat(shirtHex*.72,.98));box(g,.105,1.17,.272,.09,.12,.014,mat(shirtHex*.72,.98));
 return {name,group:g,torso,head,hair,arms,legs,walkClock:Math.random()*5,origin:new THREE.Vector3(x,0,z),speed:0};
}
function makeMarker(parent,x,z){const ring=mesh(new THREE.TorusGeometry(.52,.055,6,20),new THREE.MeshBasicMaterial({color:0xd9b37c}),x,.09,z,parent);ring.rotation.x=-Math.PI/2;return ring}
function makeCar(parent,x,z,color=0x42484a){const g=new THREE.Group();g.position.set(x,0,z);parent.add(g);box(g,0,.54,0,1.95,.55,3.8,mat(color,.48,.15));box(g,0,.99,-.18,1.58,.55,1.82,M.glass);box(g,0,.9,1.4,1.7,.25,.65,mat(color));for(const sx of [-.99,.99])for(const sz of [-1.17,1.17]){const wh=cyl(g,sx,.3,sz,.29,.29,.2,M.rubber,12);wh.rotation.z=Math.PI/2;const hub=cyl(g,sx*1.01,.3,sz,.13,.13,.21,M.metal,10);hub.rotation.z=Math.PI/2}for(const sx of [-.58,.58])box(g,sx,.63,-1.93,.3,.12,.07,M.lamp);return g}

// Refresh collision buckets after every static landmark and container collider has been registered.
rebuildCollisionGrid();
// Ambient traffic loops on the grid and pedestrians walk short sidewalk routes in free roam.
const trafficCars=[];
for(let i=0;i<14;i++){const c=makeCar(scene,[-125,-100,-75,-50,-25,0,25,50,75,100,125,-25,75,0][i],[-120,-90,-60,-30,0,30,60,90,120,-110,-80,50,-15,110][i],[0x485052,0x5b4337,0x313b43,0x6a6a61,0x394b45,0x6a3c32,0x55575c,0x777066,0x49545a,0x6b5043,0x5a655d,0x34454b,0x61554b,0x495b57][i]);c.userData.route=i%2===0?'vertical':'horizontal';c.userData.dir=i%3===0?-1:1;c.userData.lane=(i%2===0?c.position.x:c.position.z);c.userData.speed=2.1+(i%4)*.45;c.userData.offset=i%2===0?c.position.z:c.position.x;c.visible=false;trafficCars.push(c)}
configureMappedTraffic();
const policeCars=[makeCar(scene,-80,80,0x1c2731),makeCar(scene,80,80,0x1c2731)];policeCars.forEach((c,i)=>{c.visible=false;c.userData.siren=i%2===0?0xff3434:0x4c8dff;box(c,0,1.34,-.1,.55,.12,.5,mat(c.userData.siren,.3,.1));});
const freeRoamNPCs=[];
function makeFreeRoamNPC(x,z,color,i){const spawn=hasOfflineKochiDistrict?spawnFreeRoamRoadSpawn(i,1.45):{x,z};const n=makePerson('CITIZEN',color,scene,spawn.x,spawn.z,.91+(i%3)*.025);n.group.visible=false;n.userData={x:spawn.x,z:spawn.z,phase:i*.8,axis:i%2?'x':'z',range:2.5+(i%3),segment:spawn.segment||null,progress:spawn.t??.5,dir:spawn.dir??(i%2?1:-1),side:spawn.side||1,normX:spawn.normX??spawn.normalX??0,normZ:spawn.normZ??spawn.normalZ??0,speed:1.05+(i%4)*.15};freeRoamNPCs.push(n)}
[[-108,-101,0x59675d],[-88,-61,0x7b604f],[-68,-91,0x475e65],[-38,-31,0x7c6b57],[-8,-59,0x555c60],[22,-31,0x79614f],[53,-61,0x4d6862],[81,-2,0x6b6258],[108,31,0x6b4e43],[-111,-2,0x52636d],[-90,91,0x786a5b],[60,60,0x5e665e],[-24,110,0x62615a],[34,108,0x685a4e],[96,108,0x56675e],[-118,45,0x746758],[-21,-11,0x7e6b58],[25,-9,0x53635f],[29,17,0x73604e],[-28,15,0x4c6068],[-79,65,0x4a6260],[130,-45,0x82644f],[210,75,0x525c65],[-230,120,0x786b58],[300,-210,0x3f625d],[-380,180,0x6d6053],[450,260,0x555e64],[-510,-200,0x786b58],[620,-150,0x4c5f5c],[-690,260,0x75624f],[810,110,0x53635f],[-870,-320,0x746758],[950,380,0x7e6b58],[1000,-520,0x53635f],[-1040,560,0x73604e],[280,700,0x4c6068],[-330,-780,0x746758],[540,-850,0x7e6b58],[-710,900,0x53635f],[900,780,0x73604e]].forEach((v,i)=>makeFreeRoamNPC(v[0],v[1],v[2],i));
for(let i=40;i<62;i++){const a=i*2.39996,r=800+(i%5)*420;makeFreeRoamNPC(Math.cos(a)*r,Math.sin(a)*r,[0x59675d,0x7b604f,0x475e65,0x7c6b57,0x79614f,0x4d6862][i%6],i)}
// Offline roadside animals: lightweight low-poly dogs and cats with animated legs/tails.
const ambientPets=[];
function makeAmbientPet(type,x,z,i){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);const dog=type==='DOG';const coat=mat(dog?[0x8b6645,0x4b4137,0xb8a07c,0x383231][i%4]:[0x5b5148,0xa69a83,0x303033,0x8a775f][i%4],.92),lightCoat=mat(dog?0xc8b18a:0xd0c3aa,.92),nose=mat(0x171716,.5),eye=mat(0x0a0c0c,.35);
 const body=mesh(new THREE.SphereGeometry(dog?.31:.22,10,7),coat,0,dog?.43:.28,0,g);body.scale.set(dog?1.55:1.2,dog?.9:.85,dog?.8:1.05);
 mesh(new THREE.SphereGeometry(dog?.20:.15,10,8),coat,0,dog?.52:.37,dog?-.30:-.19,g);
 mesh(new THREE.SphereGeometry(.055,8,6),nose,0,dog?.50:.35,dog?-.45:-.31,g);
 for(const sx of [-1,1]){mesh(new THREE.SphereGeometry(.025,7,6),eye,sx*.07,dog?.57:.405,dog?-.39:-.27,g);if(!dog){const ear=mesh(new THREE.ConeGeometry(.075,.18,5),coat,sx*.11,.53,-.17,g);ear.rotation.z=sx*-.12}else{const ear=mesh(new THREE.SphereGeometry(.07,7,5),coat,sx*.12,.66,-.24,g);ear.scale.set(.8,1.25,.55)}}
 const legs=[];for(const sx of [-1,1])for(const sz of [-1,1]){const leg=box(g,sx*(dog?.25:.14),dog?.20:.13,sz*(dog?.19:.13),dog?.10:.07,dog?.35:.24,dog?.10:.07,coat);legs.push(leg)}
 const tail=mesh(new THREE.CylinderGeometry(.035,.06,dog?.38:.25,6),coat,dog?.30:.45,.20,g);tail.rotation.z=-.75;
 if(!dog)mesh(new THREE.SphereGeometry(.09,7,5),lightCoat,0,.27,.16,g);
 g.scale.setScalar(dog?.85:.70);g.visible=false;
 const q=nearestMappedRoad(x,z,3.0,i+13);const home=q?{x:q.x,z:q.z}:{x,z};g.position.set(home.x,0,home.z);
 ambientPets.push({group:g,type,legs,tail,home:{...home},phase:i*.92,dir:(i%2?1:-1),radius:1.6+(i%3)*.45,speed:dog?.36:.23,seed:i});
}
const fallbackPetPlaces=[[-18,-36],[18,-36],[-22,-8],[22,8],[-5,34],[28,24],[-35,18],[34,-18],[-46,45],[45,46],[-55,-12],[55,12]];
for(let i=0;i<24;i++){const p=hasOfflineKochiDistrict&&petSpawnPoints.length?petSpawnPoints[(i*7)%petSpawnPoints.length]:{x:fallbackPetPlaces[i%fallbackPetPlaces.length][0],z:fallbackPetPlaces[i%fallbackPetPlaces.length][1]};makeAmbientPet(i%4===0?'CAT':'DOG',p.x,p.z,i)}

let freeRoamActive=false,freeRoamOnFoot=false,sideJobType='',sideJobStage=0,sideJobTarget=null,sideJobStart=null,wantedLevel=0,collisionCooldown=0,policeHeat=0;
function setWorldLayerForMode(useMapped){
 const mapped=Boolean(useMapped&&hasOfflineKochiDistrict);
 osmWorldGroup.visible=mapped; legacyDistrict.visible=!mapped;
 worldSolidBounds.splice(0,worldSolidBounds.length,...(mapped?offlineWorldSolidBounds:legacyWorldSolidBounds));
 rebuildCollisionGrid();
 if(mapped){
  garage.visible=false; flashbackSet.visible=false; homeSet.visible=false; warehouseSet.visible=false; industrialSet.visible=false;
  evidenceCar.visible=false; oldAmbassador.visible=false; brokenCustomerCar.visible=false; wreck.visible=false;
  assistanceCar.visible=false; strandedDriver.group.visible=false; bystanders.forEach(n=>n.group.visible=false);
 }
}

function clearHeldControls(){steer=0;throttle=false;reverseHeld=false;braking=false;sprintHeld=false;fireHeld=false;blockHeld=false;for(const k of Object.keys(walk||{}))walk[k]=false;for(const k of Object.keys(keys||{}))keys[k]=false;}
let vehicleTransition=false;
function freeRoamCollisionAt(x,z,rx,rz){if(![x,z,rx,rz].every(Number.isFinite))return true;const pool=buildingCollisionGrid.size?nearbyCollisionBounds(x,z,rx,rz):worldSolidBounds;return pool.some(b=>x+rx>b.minX&&x-rx<b.maxX&&z+rz>b.minZ&&z-rz<b.maxZ)}
function resolveFreeRoamCollision(position,previous,rx,rz){
 if(!position||!previous||![position.x,position.z,previous.x,previous.z].every(Number.isFinite)){if(position&&previous)position.copy(previous);return true}
 if(!freeRoamCollisionAt(position.x,position.z,rx,rz))return false;
 const nextX=position.x,nextZ=position.z;
 position.x=nextX;position.z=previous.z;if(!freeRoamCollisionAt(position.x,position.z,rx,rz))return true;
 position.x=previous.x;position.z=nextZ;if(!freeRoamCollisionAt(position.x,position.z,rx,rz))return true;
 position.x=previous.x;position.z=previous.z;return true;
}
function findVehicleExitPosition(){
 const x=driveCar.position.x,z=driveCar.position.z,yaw=Number.isFinite(carYaw)?carYaw:driveCar.rotation.y;
 const sideX=Math.cos(yaw),sideZ=-Math.sin(yaw),frontX=-Math.sin(yaw),frontZ=-Math.cos(yaw);
 const candidates=[];
 for(const distance of [2.6,3.3,4.1,5.0,6.0,7.0]){candidates.push([x+sideX*distance,z+sideZ*distance],[x-sideX*distance,z-sideZ*distance],[x+frontX*distance,z+frontZ*distance],[x-frontX*distance,z-frontZ*distance]);}
 for(const [cx,cz] of candidates){if(Math.abs(cx)>5580||Math.abs(cz)>3850)continue;if(!freeRoamCollisionAt(cx,cz,.45,.45))return new THREE.Vector3(cx,0,cz)}
 // Last-resort fallback is a walkable point on the nearby carriageway, not an unchecked position.
 for(let ring=1;ring<=8;ring++)for(let i=0;i<16;i++){const a=i*Math.PI/8,cx=x+Math.cos(a)*ring*1.5,cz=z+Math.sin(a)*ring*1.5;if(!freeRoamCollisionAt(cx,cz,.45,.45))return new THREE.Vector3(cx,0,cz)}
 return null;
}
function showGameLoading(label='LOADING KOCHI'){
 const screen=document.querySelector('#loading-screen');if(!screen)return;const title=screen.querySelector('[data-loading-title]');if(title)title.textContent=String(label).toUpperCase();screen.classList.remove('hidden');screen.setAttribute('aria-hidden','false');
 clearTimeout(showGameLoading.timer);showGameLoading.timer=setTimeout(()=>{screen.classList.add('hidden');screen.setAttribute('aria-hidden','true')},950);
}
function startFreeRoam(){
 showGameLoading('KOCHI · FREE ROAM');closeWeaponWheel();document.querySelector('#world-map-overlay').classList.add('hidden');
 window.KochiAudio?.setMenuActive(false);document.body.classList.remove('menu-state');document.querySelector('#title-card').classList.add('hidden');document.querySelector('#end-card').classList.add('hidden');missionBoard.classList.add('hidden');document.body.classList.remove('cinema');resetEnvironment();freeRoamActive=true;freeRoamOnFoot=false;setWorldLayerForMode(true);wantedLevel=0;collisionCooldown=0;policeHeat=0;document.querySelector('#wanted-level').textContent='';policeCars.forEach(c=>c.visible=false);mode='freeRoam';currentMissionId=0;missionStage=0;carSpeed=0;carYaw=0;steer=0;throttle=false;reverseHeld=false;braking=false;driveCar.visible=true;const freeRoamSpawn=hasOfflineKochiDistrict?spawnPointOnMappedRoad(0,0,0,7):{x:0,z:0,yaw:0};driveCar.position.set(freeRoamSpawn.x,.02,freeRoamSpawn.z);carYaw=freeRoamSpawn.yaw||0;driveCar.rotation.y=carYaw;player.visible=false;trafficCars.forEach(c=>c.visible=true);freeRoamNPCs.forEach(n=>{n.group.visible=true;n.group.userData.weaponHealth=100;n.group.rotation.set(0,0,0);for(const limb of n.legs)limb.rotation.x=0});pursuer.visible=false;pursuer2.visible=false;pursuer3.visible=false;ambientPets?.forEach(p=>p.group.visible=true);setAtmosphere('clear');applyTimeOfDay(freeRoamClockMinutes/60);showDrive();document.querySelector('#vehicle-toggle').classList.remove('hidden');document.querySelector('#vehicle-toggle').textContent='EXIT VEHICLE';document.querySelector('#vehicle-enter').classList.add('hidden');document.querySelector('#side-job').classList.remove('hidden');document.querySelector('#side-job').textContent='SIDE JOBS';hint.textContent='FREE ROAM · Drive anywhere around the mapped Kochi streets. Tap EXIT VEHICLE to walk, ENTER VEHICLE to drive. SIDE JOBS offers optional activities.';hint.classList.remove('hidden');setObjective('Explore Kochi freely','FREE ROAM');cameraYaw=0;cameraPitch=.18;cameraDistance=8;followCamera(driveCar.position,10);syncWeaponHud();say('KOCHI · FREE ROAM UNLOCKED',2500);
}
function updateAmbientWorld(dt){if(!freeRoamActive)return;collisionCooldown=Math.max(0,collisionCooldown-dt);for(const c of trafficCars){if(c.userData.route==='osm'&&c.userData.segment){const seg=c.userData.segment,dx=seg.b.x-seg.a.x,dz=seg.b.z-seg.a.z,len=Math.hypot(dx,dz)||1;c.userData.progress+=c.userData.dir*c.userData.speed*dt/len;if(c.userData.progress>.9){c.userData.progress=.9;c.userData.dir=-1}else if(c.userData.progress<.1){c.userData.progress=.1;c.userData.dir=1}const t=c.userData.progress;c.position.set(seg.a.x+dx*t,0,seg.a.z+dz*t);c.rotation.y=Math.atan2(-dx*c.userData.dir,-dz*c.userData.dir);}else if(c.userData.route==='vertical'){c.position.z-=c.userData.dir*c.userData.speed*dt;if(c.position.z<-1190)c.position.z=1190;if(c.position.z>1190)c.position.z=-1190;c.rotation.y=c.userData.dir>0?0:Math.PI;}else{c.position.x+=c.userData.dir*c.userData.speed*dt;if(c.position.x<-1190)c.position.x=1190;if(c.position.x>1190)c.position.x=-1190;c.rotation.y=c.userData.dir>0?-Math.PI/2:Math.PI/2;}}
 const driven=freeRoamOnFoot?player.position:driveCar.position;if(!freeRoamOnFoot&&Math.abs(carSpeed)>4&&collisionCooldown<=0){const hit=trafficCars.find(c=>c.position.distanceTo(driveCar.position)<2.5);const pedestrian=freeRoamNPCs.find(n=>n.group.position.distanceTo(driveCar.position)<1.8);if(hit||pedestrian){wantedLevel=Math.min(5,wantedLevel+1);collisionCooldown=4;policeHeat=22;document.querySelector('#wanted-level').textContent='★'.repeat(wantedLevel)+'☆'.repeat(5-wantedLevel);policeCars.forEach(c=>c.visible=true);say('TRAFFIC COLLISION REPORTED · POLICE ALERT',2200)}}
 for(const n of freeRoamNPCs){n.walkClock+=dt*.65;const u=n.userData;if(u.segment){const seg=u.segment,dx=seg.b.x-seg.a.x,dz=seg.b.z-seg.a.z,len=Math.hypot(dx,dz)||1;u.progress+=u.dir*u.speed*dt/len;if(u.progress>.88){u.progress=.88;u.dir=-1}else if(u.progress<.12){u.progress=.12;u.dir=1}const t=u.progress;n.group.position.x=seg.a.x+dx*t+u.normX*(seg.width/2+1.45);n.group.position.z=seg.a.z+dz*t+u.normZ*(seg.width/2+1.45);n.group.rotation.y=Math.atan2(dx*u.dir,dz*u.dir);}else{const axis=u.axis==='x'?'x':'z';n.group.position[axis]=u[axis]+Math.sin(n.walkClock+u.phase)*u.range}n.legs[0].rotation.x=Math.sin(n.walkClock*3)*.18;n.legs[1].rotation.x=-n.legs[0].rotation.x;n.arms[0].rotation.x=-n.legs[0].rotation.x*.45;n.arms[1].rotation.x=-n.legs[1].rotation.x*.45;}
 for(const p of ambientPets){if(!p.group.visible)continue;p.phase+=dt*p.speed*2;const dx=Math.sin(p.phase*.72)*p.radius,dz=Math.cos(p.phase*.53)*p.radius*.55;p.group.position.x=p.home.x+dx;p.group.position.z=p.home.z+dz;p.legs.forEach((leg,j)=>{leg.rotation.x=Math.sin(p.phase*4+(j%2)*Math.PI)*.22});p.tail.rotation.z=-.68+Math.sin(p.phase*2.7)*.2;p.group.rotation.y=Math.atan2(-Math.cos(p.phase*.72)*p.radius,-Math.cos(p.phase*.53)*p.radius*.4);}
 if(wantedLevel>0){policeHeat=Math.max(0,policeHeat-dt);for(let i=0;i<policeCars.length;i++){const c=policeCars[i];const dx=driven.x-c.position.x,dz=driven.z-c.position.z,dist=Math.hypot(dx,dz)||1;c.position.x+=(dx/dist)*dt*(3+wantedLevel*.45);c.position.z+=(dz/dist)*dt*(3+wantedLevel*.45);c.rotation.y=Math.atan2(-dx,-dz);if(dist<4&&!freeRoamOnFoot){carSpeed*=.965}}if(policeHeat<=0&&wantedLevel>0){wantedLevel=Math.max(0,wantedLevel-1);policeHeat=15;document.querySelector('#wanted-level').textContent='★'.repeat(wantedLevel)+'☆'.repeat(5-wantedLevel);if(!wantedLevel){policeCars.forEach(c=>c.visible=false);document.querySelector('#wanted-level').textContent='';say('POLICE SEARCH CALMED DOWN',1800)}}}
}
function updateFreeRoam(dt){
 if(!freeRoamOnFoot){const forward=throttle||keys.w||keys.arrowup,reverse=reverseHeld||keys.x,brake=braking||keys.s||keys.arrowdown;const maxForward=17,maxReverse=5.2;
  if(forward&&!reverse)carSpeed=Math.min(maxForward,carSpeed+dt*6.4);else if(reverse){if(carSpeed>0)carSpeed=Math.max(0,carSpeed-dt*10);else carSpeed=Math.max(-maxReverse,carSpeed-dt*4.4)}else if(brake)carSpeed=carSpeed>0?Math.max(0,carSpeed-dt*12):Math.min(0,carSpeed+dt*10);else carSpeed=THREE.MathUtils.damp(carSpeed,0,1.1,dt);
  const speedFactor=Math.min(Math.abs(carSpeed)/12,1);const sens=window.KochiAudio?.getSettings?.().sensitivity??.85;if(Math.abs(carSpeed)>.25)carYaw-=steer*dt*(.09+speedFactor*.31)*sens*Math.sign(carSpeed);
  const previousCarPosition=driveCar.position.clone();
  driveCar.position.x-=Math.sin(carYaw)*carSpeed*dt;driveCar.position.z-=Math.cos(carYaw)*carSpeed*dt;
  if(resolveFreeRoamCollision(driveCar.position,previousCarPosition,1.25,2.05)){carSpeed=0;}
  // A closed, bounded city district with soft boundary response instead of teleporting the car sideways.
  if(Math.abs(driveCar.position.x)>5580){driveCar.position.x=THREE.MathUtils.clamp(driveCar.position.x,-5580,5580);carSpeed*=.35}
  if(Math.abs(driveCar.position.z)>3850){driveCar.position.z=THREE.MathUtils.clamp(driveCar.position.z,-3850,3850);carSpeed*=.35}
  driveCar.rotation.y=carYaw;followCamera(new THREE.Vector3(driveCar.position.x,0,driveCar.position.z-1.2),cameraDistance+2);
 }else{const previousPlayerPosition=player.position.clone();const f=(walk.up||keys.w||keys.arrowup?1:0)-(walk.down||keys.s||keys.arrowdown?1:0),s=(walk.right||keys.d||keys.arrowright?1:0)-(walk.left||keys.a||keys.arrowleft?1:0);const move=new THREE.Vector3(s,0,-f);if(move.lengthSq()){move.normalize().applyAxisAngle(new THREE.Vector3(0,1,0),cameraYaw);player.position.addScaledVector(move,dt*(sprintHeld?4.0:2.1));player.rotation.y=Math.atan2(move.x,move.z);walkCycle+=dt*8;walkRig.legs[0].rotation.x=Math.sin(walkCycle)*.48;walkRig.legs[1].rotation.x=-walkRig.legs[0].rotation.x;walkRig.arms[0].rotation.x=-walkRig.legs[0].rotation.x*.6;walkRig.arms[1].rotation.x=-walkRig.legs[1].rotation.x*.6}else{for(const limb of [...walkRig.legs,...walkRig.arms])limb.rotation.x=THREE.MathUtils.damp(limb.rotation.x,0,8,dt)}player.position.x=THREE.MathUtils.clamp(player.position.x,-5580,5580);player.position.z=THREE.MathUtils.clamp(player.position.z,-3850,3850);resolveFreeRoamCollision(player.position,previousPlayerPosition,.45,.45);followCamera(player.position,cameraDistance)}
 updateAmbientWorld(dt);tickWeapons(dt);updateFreeRoamDaylight(dt);syncWorldMap();if(freeRoamOnFoot&&((walk.up||walk.down||walk.left||walk.right||keys.w||keys.a||keys.s||keys.d||keys.arrowup||keys.arrowdown||keys.arrowleft||keys.arrowright)))window.KochiAudio?.playFootstepIfDue?.(sprintHeld);
 if(sideJobType&&sideJobTarget){const pos=freeRoamOnFoot?player.position:driveCar.position;if(pos.distanceTo(sideJobTarget)<7){if(sideJobType==='courier'){finishSideJob(450)}else if(sideJobType==='taxi'&&sideJobStage===0){sideJobStage=1;sideJobTarget=new THREE.Vector3(55,0,55);setObjective('Drive passenger to the destination','TAXI FARE');say('PASSENGER PICKED UP · FOLLOW THE MARKER',2000)}else if(sideJobType==='taxi'){finishSideJob(600)}else if(sideJobType==='sprint'){sideJobStage++;if(sideJobStage>=3)finishSideJob(750);else{sideJobTarget=[new THREE.Vector3(50,0,50),new THREE.Vector3(-50,0,25),new THREE.Vector3(0,0,-50)][sideJobStage];setObjective(`Reach sprint checkpoint ${sideJobStage+1} of 3`,'STREET SPRINT');say(`CHECKPOINT ${sideJobStage} / 3`,1300)}}}}
}
function toggleFreeRoamVehicle(){
 if(!freeRoamActive||vehicleTransition)return;
 vehicleTransition=true;
 try{clearHeldControls();
  if(!freeRoamOnFoot){
   const safeExit=findVehicleExitPosition();
   if(!safeExit||!Number.isFinite(safeExit.x)||!Number.isFinite(safeExit.z)){say('NO SAFE SPACE TO EXIT · Move the vehicle forward.',1800);return}
   // Commit the state change only after a valid, collision-free exit point exists.
   player.position.set(safeExit.x,0,safeExit.z);player.rotation.y=Number.isFinite(carYaw)?carYaw+Math.PI:driveCar.rotation.y+Math.PI;
   freeRoamOnFoot=true;player.visible=true;carSpeed=0;driveCar.visible=true;mode='freeRoam';
   firstPersonView=false;cameraDistance=8;cameraPitch=.18;cameraYaw=carYaw;
   document.querySelector('#vehicle-toggle').classList.add('hidden');document.querySelector('#vehicle-enter').classList.remove('hidden');
   document.querySelector('#drive-controls').classList.add('hidden');document.querySelector('#walk-controls').classList.remove('hidden');document.querySelector('#inspect').classList.add('hidden');
   hint.textContent='ON FOOT · D-pad to move, hold SPRINT to run. Approach the parked car and tap ENTER VEHICLE.';setObjective('Explore the streets','FREE ROAM');syncWeaponHud();refreshVehicleDiagnostics();followCamera(player.position,cameraDistance);
  }else{
   if(player.position.distanceTo(driveCar.position)>5){say('MOVE CLOSER TO YOUR PARKED CAR FIRST.',1500);return}
   const lastCarPos=driveCar.position.clone();
   if(![lastCarPos.x,lastCarPos.z].every(Number.isFinite)){say('VEHICLE STATE INVALID · Return to the menu and reload.',1900);return}
   freeRoamOnFoot=false;player.visible=false;driveCar.visible=true;carYaw=Number.isFinite(driveCar.rotation.y)?driveCar.rotation.y:carYaw;carSpeed=0;mode='freeRoam';
   document.querySelector('#vehicle-enter').classList.add('hidden');document.querySelector('#vehicle-toggle').classList.remove('hidden');document.querySelector('#drive-controls').classList.remove('hidden');document.querySelector('#walk-controls').classList.add('hidden');
   hint.textContent='DRIVING · Steer, accelerate, brake or reverse. EXIT VEHICLE places you safely beside the car.';setObjective('Explore Kochi freely','FREE ROAM');syncWeaponHud();refreshVehicleDiagnostics();followCamera(driveCar.position,cameraDistance+2);
  }
 }catch(err){console.error('Safe vehicle transition failed:',err);say('VEHICLE TRANSITION FAILED · Controls were reset safely.',2000);}
 finally{vehicleTransition=false;}
}
function openSideJobs(){if(!freeRoamActive)return;mode='sideJobMenu';controls.classList.add('hidden');hint.classList.add('hidden');document.querySelector('#side-job-panel').classList.remove('hidden');syncWeaponHud();}
function startSideJob(type){document.querySelector('#side-job-panel').classList.add('hidden');mode='freeRoam';sideJobType=type;sideJobStage=0;sideJobStart=performance.now();
 if(type==='courier'){sideJobTarget=new THREE.Vector3(60,0,-60);setObjective('Deliver the parcel to the marked drop point','COURIER JOB');say('COURIER JOB STARTED · FOLLOW THE GOLD MARKER',2300)}
 if(type==='taxi'){sideJobTarget=new THREE.Vector3(-60,0,60);setObjective('Pick up the waiting passenger','TAXI FARE');say('TAXI FARE · PICK UP THE PASSENGER',2300)}
 if(type==='sprint'){sideJobTarget=new THREE.Vector3(50,0,50);sideJobStage=0;setObjective('Reach sprint checkpoint 1 of 3','STREET SPRINT');say('STREET SPRINT · HIT ALL THREE CHECKPOINTS',2300)}
 controls.classList.remove('hidden');if(freeRoamOnFoot){document.querySelector('#walk-controls').classList.remove('hidden');document.querySelector('#drive-controls').classList.add('hidden')}else{document.querySelector('#drive-controls').classList.remove('hidden');document.querySelector('#walk-controls').classList.add('hidden')}hint.classList.remove('hidden');}
function finishSideJob(reward){cashBalance+=reward;document.querySelector('#cash-value').textContent=cashBalance.toLocaleString('en-IN');say(`SIDE JOB COMPLETE  +₹${reward}`,2800);sideJobType='';sideJobTarget=null;sideJobStage=0;setObjective('Explore Kochi freely','FREE ROAM')}
// Home / family house: an open-roof walkable layout with a living room and Abraham’s room.
const homeSet=new THREE.Group();homeSet.position.set(80,0,0);scene.add(homeSet);homeSet.visible=false;
box(homeSet,0,-.12,0,18,.24,16,mat(0x50473d));box(homeSet,0,2.2,-8,18,4.4,.3,mat(0x6b5a49));box(homeSet,-9,2.2,0,.3,4.4,16,mat(0x6b5a49));box(homeSet,9,2.2,0,.3,4.4,16,mat(0x6b5a49));box(homeSet,-2,1.35,-1.2,3.2,1.1,1.25,mat(0x5b3027));box(homeSet,-2,2.0,-1.2,3.4,.16,1.35,mat(0x66402e));box(homeSet,-2,.72,1.2,3.4,.65,1.5,mat(0x43372e));box(homeSet,-2,1.1,1.2,3.4,.14,1.5,mat(0x60432e));box(homeSet,4,.24,-2,4.5,.4,3.2,mat(0x5f4b38));box(homeSet,4,.48,-2,4.7,.14,3.35,mat(0x765943));box(homeSet,5,1.2,-3,.07,1.2,1.1,mat(0x8a6b4e));box(homeSet,5,1.2,-3.08,.05,.85,.75,mat(0x3a2b20));
const homePhone=makeMarker(homeSet,-3,2.1),homeBagMarker=makeMarker(homeSet,-5,3.2),homePhoto=makeMarker(homeSet,5,-2.8),homePapers=makeMarker(homeSet,3.2,-.8),homeKeys=makeMarker(homeSet,4.7,.25);
box(homeSet,-5,.33,3.2,.75,.45,.55,mat(0x292d30));box(homeSet,-5,.57,3.2,.68,.05,.48,mat(0x44494a));
box(homeSet,-3,.36,2.1,.62,.07,.38,mat(0x171a1b));box(homeSet,5,1.55,-3.02,1.15,1.05,.08,mat(0x45382d));box(homeSet,5,1.55,-2.96,.92,.8,.025,mat(0x8e765d));box(homeSet,3.2,.57,-.8,1.15,.035,.8,mat(0xd3c6ac));box(homeSet,3.2,.60,-.8,.08,.012,.62,mat(0x746a5a));const keyRing=mesh(new THREE.TorusGeometry(.12,.035,6,12),mat(0xd2aa51,.3,.6),4.7,.22,.25,homeSet);keyRing.rotation.x=Math.PI/2;box(homeSet,4.85,.23,.25,.28,.045,.07,mat(0xb48b38,.3,.65));
const homeRelative=makePerson('RELATIVE',0x76685c,homeSet,2.8,3.1,.98);const homeExtra=makePerson('NEIGHBOUR',0x3a6263,homeSet,-6,4,.95);const homeExtra2=makePerson('PASSERBY',0x8b795d,homeSet,7,4,.94);homeExtra.group.visible=false;homeExtra2.group.visible=false;

// A smaller, older-looking repair shed used for the 2015 flashback.
const flashbackSet=new THREE.Group();flashbackSet.position.set(45,0,0);scene.add(flashbackSet);flashbackSet.visible=false;box(flashbackSet,0,-.1,0,20,.2,18,mat(0x3b3933));box(flashbackSet,0,3.3,-8,20,6.6,.35,mat(0x514336));box(flashbackSet,-10,2,-1,.3,4,14,mat(0x514336));box(flashbackSet,10,2,-1,.3,4,14,mat(0x514336));box(flashbackSet,0,6.7,-1,20,.3,14,mat(0x352e27));box(flashbackSet,-5,.7,-3,3,1.25,1.4,mat(0x4b5354));for(let x=-8;x<=8;x+=4){const lamp=mesh(new THREE.BoxGeometry(1.25,.08,.25),M.lamp,x,5.7,-2,flashbackSet);const glow=new THREE.PointLight(0xffb77a,4,9,2);glow.position.set(x,5.1,-2);flashbackSet.add(glow)}
// Small garage props and target positions for the car investigation and evidence table.
const brokenCustomerCar=makeCar(garage,2.5,.4,0x4a5053);brokenCustomerCar.visible=false;
const evidenceCar=makeCar(scene,49,-2,0x633c2d);evidenceCar.visible=false;box(evidenceCar,0,1.22,-1.15,.8,.1,1.1,M.rust).rotation.z=-.18;
const oldAmbassador=makeCar(scene,49,-1,0xd9d4c5);oldAmbassador.visible=false;
const garageRafi=makePerson('RAFI',0x253e56,scene,43,1,.98);garageRafi.group.visible=false;
const abrahamNPC=makePerson('ABRAHAM',0x8b2f27,scene,51,1,1.08);abrahamNPC.group.visible=false;
const garageTable=new THREE.Group();scene.add(garageTable);garageTable.position.set(46,0,-4);garageTable.visible=false;box(garageTable,0,.72,0,3.7,.14,1.5,mat(0x62472f));for(const sx of [-1.55,1.55])for(const sz of [-.5,.5])box(garageTable,sx,.35,sz,.12,.72,.12,M.trunk);box(garageTable,-.3,.83,-.03,.85,.04,.58,mat(0x322c28));box(garageTable,.65,.84,.05,.65,.03,.44,mat(0xd0bfa3));box(garageTable,-.3,.87,0,.53,.02,.36,mat(0x80715f));box(garageTable,.65,.88,.05,.38,.02,.26,mat(0x372b22));makeMarker(garageTable,-.3,0); // table-local marker indicates evidence

// Warehouse approach (2004 flashback) and a distinct unidentified waiting figure.
const warehouseSet=new THREE.Group();scene.add(warehouseSet);warehouseSet.visible=false;
box(warehouseSet,19,-.1,-55,28,.2,24,mat(0x333635));box(warehouseSet,19,4,-67,28,8,.35,mat(0x343735));box(warehouseSet,5,4,-55,.35,8,24,mat(0x343735));box(warehouseSet,33,4,-55,.35,8,24,mat(0x343735));box(warehouseSet,19,8,-55,28,.35,24,mat(0x252a29));box(warehouseSet,19,2.6,-42,.3,5.2,12,mat(0x343735));box(warehouseSet,19,2.6,-48,8,.14,.25,M.metal);for(let x=9;x<30;x+=4)box(warehouseSet,x,.14,-69,.13,.28,.13,M.rust);
const bag=new THREE.Group();warehouseSet.add(bag);bag.position.set(15,.2,-53);box(bag,0,.25,0,.62,.45,.4,mat(0x131716));box(bag,0,.49,-.02,.38,.12,.24,mat(0x242826));bag.visible=true;const bagMarker=makeMarker(warehouseSet,15,-53);
const warehouseFigure=makePerson('UNIDENTIFIED PERSON',0x202526,warehouseSet,18,-51,1.03);const waitingCar=makeCar(warehouseSet,25,-51,0x16191b);
// Evidence/old-road scene: possible industrial building; no confirmation it is the 2004 site.
const industrialSet=new THREE.Group();industrialSet.position.set(120,0,0);scene.add(industrialSet);industrialSet.visible=false;
box(industrialSet,10,-.12,-2,66,.24,30,mat(0x343a39));box(industrialSet,24,4,-10,22,8,.35,mat(0x3b403e));box(industrialSet,35,4,-2,.35,8,16,mat(0x3b403e));box(industrialSet,13,4,-2,.35,8,16,mat(0x3b403e));box(industrialSet,24,8,-2,22,.35,16,mat(0x2e3331));box(industrialSet,24,1.8,-1.7,6.5,3.6,.2,mat(0x202524));box(industrialSet,4,.02,3,12,.04,1,mat(0x756c5e));
const floorPatch=makeMarker(industrialSet,24,-.2);box(industrialSet,24,.025,-.2,2.3,.02,1.15,mat(0x242a29));box(industrialSet,24.1,.04,-.16,1.45,.015,.44,mat(0x55534b));const industrialRafi=makePerson('RAFI',0x253e56,industrialSet,13,2,.98);const departureCar=makeCar(industrialSet,34,-7,0x171b1d);departureCar.visible=false;
const roadsideSet=new THREE.Group();scene.add(roadsideSet);const assistanceCar=makeCar(roadsideSet,-5,-8,0x555e60);assistanceCar.visible=false;
const strandedDriver=makePerson('STRANDED DRIVER',0x77705e,roadsideSet,-7,-6,.98);strandedDriver.group.visible=false;
const bystanders=[makePerson('BYSTANDER',0x4f6560,scene,-5, -15,.95),makePerson('BYSTANDER',0x71604d,scene,3,-12,.95),makePerson('BYSTANDER',0x45525e,scene,5,-23,.95)];bystanders.forEach(n=>n.group.visible=false);

// The title-screen chase becomes a convoy of three anonymous silhouettes, without names or faction hints.
const pursuer2=pursuer.clone(true),pursuer3=pursuer.clone(true);scene.add(pursuer2,pursuer3);pursuer2.visible=false;pursuer3.visible=false;
// The customer was originally nested under the garage group while combat used world coordinates.
// Keep him in world space so movement, collision distances and camera tracking agree.
garage.remove(customer);scene.add(customer);customer.position.set(52,0,-1);

function worldTarget(x,z){return new THREE.Vector3(x,0,z)}
function within(x,z,range=4){return Math.hypot(player.position.x-x,player.position.z-z)<=range}
function setPlayerLook(role){
 const colors={VIVEK:0x282f33,RAFI:0x253e56,ABRAHAM:0x8b2f27};
 if(player.children[0]?.material)player.children[0].material=mat(colors[role]??0x282f33);
 for(const limb of walkRig.legs)if(limb.children[0])limb.children[0].material=M.pants;
}
function resetEnvironment(){
 homeSet.visible=false;warehouseSet.visible=false;industrialSet.visible=false;garage.visible=true;flashbackSet.visible=false;
 evidenceCar.visible=false;oldAmbassador.visible=false;brokenCustomerCar.visible=false;garageRafi.group.visible=false;abrahamNPC.group.visible=false;garageTable.visible=false;
 homeExtra.group.visible=false;homeExtra2.group.visible=false;homeRelative.group.visible=false;warehouseFigure.group.visible=false;bag.visible=false;bagMarker.visible=false;waitingCar.visible=false;
 industrialRafi.group.visible=false;floorPatch.visible=false;departureCar.visible=false;assistanceCar.visible=false;strandedDriver.group.visible=false;bystanders.forEach(n=>n.group.visible=false);
 customer.visible=false;pursuer.visible=false;pursuer2.visible=false;pursuer3.visible=false;driveCar.visible=false;wreck.visible=false;player.visible=false;
}
function setAtmosphere(kind){
 const hemi=scene.children.find(o=>o.isHemisphereLight);if(hemi)hemi.intensity=kind==='garage'?1.8:kind==='home'?1.6:1.22;
 moon.intensity=kind==='home'?1.35:kind==='garage'?1.3:1.2;
 const color=kind==='home'?0x302c27:kind==='garage'?0x1b2428:kind==='industrial'?0x242b2d:0x11191e;
 scene.background=new THREE.Color(color);scene.fog=new THREE.FogExp2(color,kind==='home'?.006:kind==='garage'?.007:kind==='industrial'?.008:kind==='rain'?.0019:.00085);
 rain.visible=(kind==='rain');
}
let freeRoamClockMinutes=8*60+15,dayClockUiTimer=0;
function interpolateHex(a,b,t){const ca=new THREE.Color(a),cb=new THREE.Color(b);return ca.lerp(cb,THREE.MathUtils.clamp(t,0,1))}
const timePalette=[
 {h:0,bg:0x0c1520,key:0x60728b,hemi:.36,dir:.38},
 {h:5,bg:0x1b2934,key:0x7f8d9b,hemi:.48,dir:.55},
 {h:7,bg:0x82959c,key:0xe4a56e,hemi:.86,dir:1.10},
 {h:11,bg:0x88a9bb,key:0xffe6c2,hemi:1.28,dir:1.48},
 {h:15,bg:0x9bb2bd,key:0xffe0b7,hemi:1.20,dir:1.40},
 {h:18,bg:0xc17d5e,key:0xe79662,hemi:.80,dir:.92},
 {h:20,bg:0x252f3b,key:0xa97b6a,hemi:.50,dir:.58},
 {h:24,bg:0x0c1520,key:0x60728b,hemi:.36,dir:.38}
];
function applyTimeOfDay(hour){let h=((hour%24)+24)%24;let i=0;while(i<timePalette.length-2&&h>timePalette[i+1].h)i++;const a=timePalette[i],b=timePalette[i+1],t=(h-a.h)/(b.h-a.h);const bg=interpolateHex(a.bg,b.bg,t),key=interpolateHex(a.key,b.key,t);scene.background.copy(bg);scene.fog.color.copy(bg);const hemi=scene.children.find(o=>o.isHemisphereLight);if(hemi)hemi.intensity=THREE.MathUtils.lerp(a.hemi,b.hemi,t);moon.color.copy(key);moon.intensity=THREE.MathUtils.lerp(a.dir,b.dir,t);scene.fog.density=THREE.MathUtils.lerp(.00155,.00065,Math.sin(Math.PI*THREE.MathUtils.clamp((h-5.8)/14,0,1)));return h}
function setMissionTimeOfDay(id){const hour=({1:1,2:5.8,3:9.2,4:16.7,5:9.5,6:11.3,7:21.2,8:14.4,9:18.5,10:2,11:19,12:10.1,13:21,14:12})[id]??12;applyTimeOfDay(hour);}
function updateFreeRoamDaylight(dt){if(!freeRoamActive||mode!=='freeRoam')return;freeRoamClockMinutes=(freeRoamClockMinutes+dt*.5)%1440;applyTimeOfDay(freeRoamClockMinutes/60);dayClockUiTimer-=dt;if(dayClockUiTimer<=0){dayClockUiTimer=.8;const h=Math.floor(freeRoamClockMinutes/60),m=Math.floor(freeRoamClockMinutes%60);const label=document.querySelector('#minimap-label');if(label)label.textContent=`KOCHI · ${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')} · OFFLINE`}}
function showWalk(label,bounds){
 controls.classList.remove('hidden');document.querySelector('#drive-controls').classList.add('hidden');document.querySelector('#walk-controls').classList.remove('hidden');
 document.querySelector('#inspect').classList.remove('hidden');document.querySelector('#inspect').textContent=label;
 document.querySelectorAll('.combat').forEach(b=>b.classList.add('hidden'));document.querySelector('#fight-status').classList.add('hidden');hint.classList.remove('hidden');
 walkBounds=bounds??{minX:-7,maxX:7,minZ:-37,maxZ:5};
}
function showDrive(){controls.classList.remove('hidden');document.querySelector('#drive-controls').classList.remove('hidden');document.querySelector('#walk-controls').classList.add('hidden');document.querySelector('#fight-status').classList.add('hidden');hint.classList.remove('hidden')}
function buildMissionBoard(){
 missionList.innerHTML='';
 for(const m of missionData){const button=document.createElement('button');button.className='mission-card'+(completedMissions.has(m.id)?' completed':'');button.type='button';button.dataset.mission=String(m.id);
  button.innerHTML=`<span class="mission-number">${m.id===14?'SIDE':String(m.id).padStart(2,'0')} · ${m.year}</span><strong>${m.title}</strong><span class="mission-summary">${m.summary}</span><span class="mission-type">${m.character} · ${m.type}</span>`;
  button.addEventListener('click',()=>startMission(m.id));missionList.appendChild(button)}
}
function openMissionBoard(){
 document.querySelector('#title-card').classList.add('hidden');document.querySelector('#end-card').classList.add('hidden');controls.classList.add('hidden');hint.classList.add('hidden');dialoguePanel.classList.add('hidden');missionBoard.classList.remove('hidden');mode='menu';document.body.classList.remove('cinema');buildMissionBoard();setObjective('Choose a mission','ACT I · MISSION SELECT');
}
function closeMissionBoard(){missionBoard.classList.add('hidden');if(currentMissionId){document.querySelector('#end-card').classList.remove('hidden');mode='end'}else{document.querySelector('#title-card').classList.remove('hidden');mode='title'}}
function showDialogue(lines,done){
 dialogueLines=lines.map(v=>Array.isArray(v)?{speaker:v[0],line:v[1]}:v);dialogueIndex=0;dialogueDone=done??null;dialogueReturnMode=mode;dialogueControlsHidden=controls.classList.contains('hidden');controls.classList.add('hidden');hint.classList.add('hidden');mode='dialogue';dialoguePanel.classList.remove('hidden');renderDialogueLine();
}
function renderDialogueLine(){const line=dialogueLines[dialogueIndex];if(!line)return;dialogueSpeaker.textContent=line.speaker;dialogueLine.textContent=line.line;dialogueNext.textContent=dialogueIndex>=dialogueLines.length-1?'CONTINUE':'NEXT';}
dialogueNext.onclick=()=>{dialogueIndex++;if(dialogueIndex<dialogueLines.length){renderDialogueLine();return}dialoguePanel.classList.add('hidden');mode=dialogueReturnMode;if(!dialogueControlsHidden){controls.classList.remove('hidden');if(hint.textContent)hint.classList.remove('hidden')}else controls.classList.add('hidden');const cb=dialogueDone;dialogueDone=null;if(cb)cb()};
function completeMission(id,customTitle,customText){
 const firstCompletion=!completedMissions.has(id);completedMissions.add(id);if(firstCompletion){const reward=({1:0,2:100,3:150,4:200,5:450,6:250,7:200,8:180,9:200,10:0,11:250,12:350,13:500,14:300})[id]??100;cashBalance+=reward;document.querySelector('#cash-value').textContent=cashBalance.toLocaleString('en-IN');say(reward?`MISSION COMPLETE  +₹${reward.toLocaleString('en-IN')}`:'MISSION COMPLETE',2300)}document.querySelector('#mission-progress').textContent=`ACT I · ${[...completedMissions].filter(n=>n>=1&&n<=13).length}/13`;currentMissionId=id;mode='end';document.body.classList.remove('cinema');missionBoard.classList.add('hidden');dialoguePanel.classList.add('hidden');controls.classList.add('hidden');hint.classList.add('hidden');document.querySelector('#fight-status').classList.add('hidden');
 const m=missionData.find(x=>x.id===id);persistGameSave({status:'complete',missionId:id,nextMissionId:id<13?id+1:id,cash:cashBalance,completed:[...completedMissions]});document.querySelector('#end-card h2').textContent=customTitle??m.title.toUpperCase();document.querySelector('#end-card p').textContent=customText??('MISSION COMPLETE — '+m.story);
 document.querySelector('#continue').textContent=id>=13?'RETURN TO MISSION SELECT':'CONTINUE ACT I';document.querySelector('#play-rafi').textContent='MISSION SELECT';document.querySelector('#play-assist').textContent=id===14?'REPLAY ROADSIDE ASSISTANCE':'ROADSIDE ASSISTANCE';document.querySelector('#end-card').classList.remove('hidden');setObjective('Mission complete',m.chapter);
}
function togglePause(){
 if(mode==='paused'){mode=pausedMode||'missionWalk';pausedMode=null;document.querySelector('#pause-menu').classList.add('hidden');if(!controls.classList.contains('hidden'))hint.classList.remove('hidden');syncWeaponHud();return}
 if(['title','menu','end','crash','blackout','sideJobMenu','weaponWheel','map'].includes(mode)||!document.querySelector('#dialogue-panel').classList.contains('hidden'))return;
 clearHeldControls();pausedMode=mode;mode='paused';document.querySelector('#pause-mission').textContent=missionData.find(m=>m.id===currentMissionId)?.title||'Act I';document.querySelector('#pause-menu').classList.remove('hidden');controls.classList.add('hidden');hint.classList.add('hidden');syncWeaponHud();
}
// Offline map renderer. All roads/buildings shown here come from packaged OSM geometry.
// It uses Canvas so there are no tile/CDN requests and no blank map in airplane mode.
let mapOpen=false,mapReturnMode=null,mapFollow=true,lastWorldMapSync=0,mapZoom=16.0,mapBearing=0,mapCenter=[KOCHI_MAP_ANCHOR.lng,KOCHI_MAP_ANCHOR.lat],mapPointer=null;
function getMapPose(){const activeMode=mode==='map'?mapReturnMode:mode==='paused'?pausedMode:mode==='phone'?phoneReturnMode:mode;const inVehicle=activeMode==='missionDrive'||activeMode==='drive'||activeMode==='failure'||(activeMode==='freeRoam'&&!freeRoamOnFoot);const pos=inVehicle?driveCar.position:player.position;const yaw=inVehicle?carYaw:player.rotation.y;return {position:pos,heading:Number.isFinite(yaw)?yaw:0}}
function gamePositionToGeo(pos){return gameToGeoXY(pos.x,pos.z)}
function setMapFollow(value){mapFollow=!!value;const b=document.querySelector('#map-follow');if(b)b.textContent=`FOLLOW ${mapFollow?'ON':'OFF'}`;if(mapFollow){const pose=getMapPose();mapCenter=gamePositionToGeo(pose.position);mapBearing=-pose.heading*180/Math.PI}drawMapViews()}
function featureColor(tags){if(tags?.natural==='water'||tags?.waterway||tags?.water)return '#78a9b0';if(['park','garden','recreation_ground','grass','forest','wood','orchard'].includes(tags?.landuse)||tags?.leisure==='park'||tags?.natural==='wood')return '#a8bc99';if(tags?.landuse==='industrial')return '#d0c5b6';return '#ddd6c6'}
function projectMapPoint(coord,center,pxPerMeter,bearing,w,h){const lat0=center[1]*Math.PI/180;const east=(coord[0]-center[0])*111320*Math.cos(lat0),north=(coord[1]-center[1])*111320;const angle=-bearing*Math.PI/180;const sx=Math.cos(angle)*east+Math.sin(angle)*north;const sy=-Math.sin(angle)*east+Math.cos(angle)*(-north);return [w/2+sx*pxPerMeter,h/2+sy*pxPerMeter]}
function drawOfflineMap(canvas,full){if(!canvas)return;const cssW=Math.max(1,canvas.clientWidth),cssH=Math.max(1,canvas.clientHeight),dpr=Math.min(window.devicePixelRatio||1,1.5);if(canvas.width!==Math.round(cssW*dpr)||canvas.height!==Math.round(cssH*dpr)){canvas.width=Math.round(cssW*dpr);canvas.height=Math.round(cssH*dpr)}const c=canvas.getContext('2d');if(!c)return;c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,cssW,cssH);c.fillStyle='#d8d1bd';c.fillRect(0,0,cssW,cssH);
 const pose=getMapPose();if(full&&mapFollow){mapCenter=gamePositionToGeo(pose.position);mapBearing=-pose.heading*180/Math.PI}const center=full?mapCenter:gamePositionToGeo(pose.position),bearing=full?mapBearing:-pose.heading*180/Math.PI,pxPerMeter=full?(0.17*Math.pow(2,mapZoom-15)):.105;const feats=offlineKochiData.features||[];
 // landuse/water polygons first
 for(const f of feats){if(f.type!=='way'||!f.coordinates||f.coordinates.length<4)continue;const t=f.tags||{};const fill=t.natural==='water'||(t.water&&!t.waterway)||['park','garden','recreation_ground','grass','forest','wood','orchard'].includes(t.landuse)||t.leisure==='park';if(!fill)continue;c.beginPath();let started=false;for(const p of f.coordinates){const q=projectMapPoint(p,center,pxPerMeter,bearing,cssW,cssH);if(!started){c.moveTo(q[0],q[1]);started=true}else c.lineTo(q[0],q[1])}c.closePath();c.fillStyle=featureColor(t);c.fill()}
 // Waterways are strokes; closing a river polyline into a filled polygon distorts Kochi's backwaters.
 c.strokeStyle='#79acb6';c.lineCap='round';c.lineJoin='round';for(const f of feats){if(f.type!=='way'||!f.tags?.waterway||!f.coordinates||f.coordinates.length<2)continue;c.beginPath();f.coordinates.forEach((p,i)=>{const q=projectMapPoint(p,center,pxPerMeter,bearing,cssW,cssH);if(i)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1])});c.lineWidth=Math.max(.7,(parseFloat(f.tags.width)||(['river','canal'].includes(f.tags.waterway)?7:2))*pxPerMeter);c.stroke()}
 // building footprints at street-map scale
 if(full||pxPerMeter>.085){c.fillStyle='#b9b09f';c.strokeStyle='#cfc5b4';c.lineWidth=.45;for(const f of feats){if(f.type!=='way'||!f.tags?.building||!f.coordinates||f.coordinates.length<4)continue;c.beginPath();f.coordinates.forEach((p,i)=>{const q=projectMapPoint(p,center,pxPerMeter,bearing,cssW,cssH);if(i)c.lineTo(q[0],q[1]);else c.moveTo(q[0],q[1])});c.closePath();c.fill();if(full)c.stroke()}}
 // roads are rendered by road class, from the packaged road vectors
 const roadStyles=[['motorway|trunk|primary','#f7f0df',4.8],['secondary|tertiary','#f7f0df',3.2],['residential|unclassified|living_street|service','#fffaf0',1.7],['footway|path|steps|cycleway','#a7a08f',.7]];
 for(const [klass,color,width] of roadStyles){c.strokeStyle=color;c.lineCap='round';c.lineJoin='round';c.lineWidth=Math.max(full?width*pxPerMeter*5.5:width*pxPerMeter*5.5,.55);for(const f of feats){if(f.type!=='way'||!f.tags?.highway||!f.coordinates||!new RegExp(`^(?:${klass})$`).test(f.tags.highway))continue;c.beginPath();let start=false;for(const p of f.coordinates){const q=projectMapPoint(p,center,pxPerMeter,bearing,cssW,cssH);if(!start){c.moveTo(q[0],q[1]);start=true}else c.lineTo(q[0],q[1])}c.stroke()}}
 if(full){c.font='10px Arial';c.textAlign='center';c.textBaseline='middle';for(const f of feats){const t=f.tags||{},name=t.name||t['name:en'];if(!name||!f.coordinates||!['node','way'].includes(f.type))continue;if(!(t.amenity||t.shop||t.tourism||t.highway==='bus_stop'||t.railway==='station'||t.place))continue;const p=f.coordinates.length>1?f.coordinates[Math.floor(f.coordinates.length/2)]:f.coordinates[0],q=projectMapPoint(p,center,pxPerMeter,bearing,cssW,cssH);if(q[0]<30||q[0]>cssW-30||q[1]<26||q[1]>cssH-24)continue;c.fillStyle='#273238dd';c.fillRect(q[0]-Math.min(100,name.length*3.1)-4,q[1]-7,Math.min(200,name.length*6.2)+8,14);c.fillStyle='#fff5dc';c.fillText(name.slice(0,32),q[0],q[1],200)}}
 // player marker and current side-job destination
 const playerGeo=gamePositionToGeo(pose.position),playerPoint=projectMapPoint(playerGeo,center,pxPerMeter,bearing,cssW,cssH);if(full){c.beginPath();c.arc(playerPoint[0],playerPoint[1],8,0,Math.PI*2);c.fillStyle='#a63c31';c.fill();c.strokeStyle='#fff4d9';c.lineWidth=2;c.stroke();const a=(pose.heading+bearing/180*Math.PI);c.beginPath();c.moveTo(playerPoint[0],playerPoint[1]);c.lineTo(playerPoint[0]+Math.sin(a)*17,playerPoint[1]+Math.cos(a)*17);c.strokeStyle='#f7d28c';c.lineWidth=3;c.stroke()}else{c.save();c.translate(playerPoint[0],playerPoint[1]);c.rotate(0);c.beginPath();c.moveTo(0,-7);c.lineTo(5,5);c.lineTo(0,2);c.lineTo(-5,5);c.closePath();c.fillStyle='#b23d32';c.fill();c.strokeStyle='#fff2d8';c.lineWidth=1.4;c.stroke();c.restore()}
 if(sideJobTarget&&freeRoamActive){const targetGeo=gamePositionToGeo(sideJobTarget),q=projectMapPoint(targetGeo,center,pxPerMeter,bearing,cssW,cssH);c.save();c.translate(q[0],q[1]);c.rotate(Math.PI/4);c.fillStyle='#e6ae58';c.fillRect(-5,-5,10,10);c.strokeStyle='#20190e';c.lineWidth=1.5;c.strokeRect(-5,-5,10,10);c.restore()}
 if(!feats.length){c.fillStyle='#bdb5a5';for(let x=18;x<cssW;x+=60){c.fillRect(x,0,1,cssH)}for(let y=18;y<cssH;y+=55){c.fillRect(0,y,cssW,1)}c.fillStyle='#273238';c.font='bold 10px Arial';c.fillText('MAP DATA NOT PACKAGED',cssW/2,cssH/2)}
 if(full){c.fillStyle='#101719d9';c.fillRect(8,8,170,26);c.fillStyle='#f4dfba';c.font='bold 10px Arial';c.textAlign='left';c.fillText('KOCHI · OFFLINE STREET DATA',16,25);c.fillStyle='#111a1caa';c.fillRect(8,cssH-24,210,16);c.fillStyle='#f5eedc';c.font='9px Arial';c.fillText('© OpenStreetMap contributors · ODbL 1.0',14,cssH-13)}else{const label=document.querySelector('#minimap-label');if(label)label.textContent=feats.length?'KOCHI · OFFLINE MAP':'KOCHI · LOCAL MAP'}
}
function drawMapViews(){drawOfflineMap(document.querySelector('#world-map-canvas'),true);drawOfflineMap(document.querySelector('#minimap'),false)}
function syncWorldMap(force=false){const now=performance.now();if(!force&&now-lastWorldMapSync<240)return;lastWorldMapSync=now;if(mapOpen)drawOfflineMap(document.querySelector('#world-map-canvas'),true);drawOfflineMap(document.querySelector('#minimap'),false)}
function openWorldMap(){if(['title','end','crash','blackout','menu','dialogue','sideJobMenu'].includes(mode)||mapOpen)return;clearHeldControls();mapReturnMode=mode;mapOpen=true;mode='map';fireHeld=false;document.querySelector('#world-map-overlay').classList.remove('hidden');document.querySelector('#world-map-overlay').setAttribute('aria-hidden','false');setMapFollow(true);requestAnimationFrame(()=>drawMapViews())}
function closeWorldMap(){if(!mapOpen)return;mapOpen=false;document.querySelector('#world-map-overlay').classList.add('hidden');document.querySelector('#world-map-overlay').setAttribute('aria-hidden','true');mode=mapReturnMode||'freeRoam';mapReturnMode=null;syncWeaponHud()}
const worldMapCanvas=document.querySelector('#world-map-canvas');let mapPointerState=null;
worldMapCanvas?.addEventListener('pointerdown',e=>{e.preventDefault();setMapFollow(false);mapPointerState={x:e.clientX,y:e.clientY};worldMapCanvas.setPointerCapture?.(e.pointerId)});
worldMapCanvas?.addEventListener('pointermove',e=>{if(!mapPointerState)return;const dx=e.clientX-mapPointerState.x,dy=e.clientY-mapPointerState.y;mapPointerState={x:e.clientX,y:e.clientY};const canvasWidth=Math.max(1,worldMapCanvas.clientWidth),ppm=.17*Math.pow(2,mapZoom-15),angle=mapBearing*Math.PI/180;const sx=-dx/ppm,sy=-dy/ppm;const east=Math.cos(angle)*sx-Math.sin(angle)*sy,north=Math.sin(angle)*sx+Math.cos(angle)*sy;mapCenter[0]+=east/(111320*Math.cos(mapCenter[1]*Math.PI/180));mapCenter[1]+=north/111320;drawOfflineMap(worldMapCanvas,true)});
worldMapCanvas?.addEventListener('pointerup',()=>{mapPointerState=null});worldMapCanvas?.addEventListener('pointercancel',()=>{mapPointerState=null});worldMapCanvas?.addEventListener('wheel',e=>{e.preventDefault();mapZoom=THREE.MathUtils.clamp(mapZoom+(e.deltaY<0?.5:-.5),13,18.5);drawOfflineMap(worldMapCanvas,true)},{passive:false});
worldMapCanvas?.addEventListener('touchmove',e=>{if(e.touches.length===2){e.preventDefault();const t1=e.touches[0],t2=e.touches[1];if(worldMapCanvas._pinchDistance){const next=Math.hypot(t1.clientX-t2.clientX,t1.clientY-t2.clientY);if(Math.abs(next-worldMapCanvas._pinchDistance)>12){mapZoom=THREE.MathUtils.clamp(mapZoom+(next>worldMapCanvas._pinchDistance?.15:-.15),13,18.5);worldMapCanvas._pinchDistance=next;drawOfflineMap(worldMapCanvas,true)}}else worldMapCanvas._pinchDistance=Math.hypot(t1.clientX-t2.clientX,t1.clientY-t2.clientY)}},{passive:false});worldMapCanvas?.addEventListener('touchend',()=>{worldMapCanvas._pinchDistance=0});
document.querySelector('#map-open').addEventListener('click',openWorldMap);document.querySelector('#map-close').addEventListener('click',closeWorldMap);document.querySelector('#map-follow').addEventListener('click',()=>setMapFollow(!mapFollow));document.querySelector('#map-zoom-in')?.addEventListener('click',()=>{mapZoom=THREE.MathUtils.clamp(mapZoom+.6,13,18.5);drawOfflineMap(worldMapCanvas,true)});document.querySelector('#map-zoom-out')?.addEventListener('click',()=>{mapZoom=THREE.MathUtils.clamp(mapZoom-.6,13,18.5);drawOfflineMap(worldMapCanvas,true)});document.querySelector('#map-rotate')?.addEventListener('click',()=>{setMapFollow(false);mapBearing=(mapBearing+45)%360;drawOfflineMap(worldMapCanvas,true)});
function drawMiniMap(){const wrap=document.querySelector('#minimap-wrap');if(!wrap)return;const show=freeRoamActive&&['freeRoam','map','weaponWheel','paused','phone'].includes(mode);wrap.classList.toggle('map-hidden',!show||['title','end','crash','blackout','menu','dialogue','sideJobMenu','rafiEnd'].includes(mode));if(show)syncWorldMap(false)}

function startMission(id){
 closeWeaponWheel();document.querySelector('#world-map-overlay').classList.add('hidden');freeRoamActive=false;freeRoamOnFoot=false;setWorldLayerForMode(false);syncWeaponHud();
 window.KochiAudio?.setMenuActive(false);document.body.classList.remove('menu-state');
 const m=missionData.find(x=>x.id===id);if(!m)return;showGameLoading(m.chapter||m.title);document.querySelector('#phone-shell')?.classList.add('hidden');document.querySelector('#vehicle-diagnostics')?.classList.add('hidden');freeRoamActive=false;freeRoamOnFoot=false;wantedLevel=0;policeHeat=0;document.querySelector('#wanted-level').textContent='';policeCars.forEach(c=>c.visible=false);trafficCars.forEach(c=>c.visible=false);freeRoamNPCs.forEach(n=>n.group.visible=false);document.querySelector('#vehicle-toggle').classList.add('hidden');document.querySelector('#vehicle-enter').classList.add('hidden');document.querySelector('#side-job').classList.add('hidden');currentMissionId=id;missionStage=0;persistGameSave({status:'in-progress',missionId:id,nextMissionId:id,cash:cashBalance,completed:[...completedMissions]});missionStartedAt=performance.now();missionDriveStart=missionStartedAt;warehouseCarArrived=false;unknownCarDeparting=false;warehouseCutscene=false;
 missionBoard.classList.add('hidden');document.querySelector('#pause-menu').classList.add('hidden');pausedMode=null;document.querySelector('#title-card').classList.add('hidden');document.querySelector('#end-card').classList.add('hidden');dialoguePanel.classList.add('hidden');document.body.classList.add('cinema');resetEnvironment();setObjective(m.objective,m.chapter);setAtmosphere(id===7||id===10||id===1?'rain':id===5||[6,8,11,13].includes(id)?'garage':id===2||id===3||id===4||id===9?'home':id===12?'industrial':'rain');setMissionTimeOfDay(id);
 cameraYaw=0;cameraPitch=.18;cameraDistance=7;carSpeed=0;carYaw=0;steer=0;throttle=false;reverseHeld=false;braking=false;walk.up=walk.down=walk.left=walk.right=false;walkCycle=0;found=false;player.rotation.set(0,0,0);setPlayerLook(m.character);player.visible=true;driveCar.visible=false;
 if(id===1){
   driveCar.children[0].material=M.rust;mode='drive';player.visible=false;driveCar.visible=true;driveCar.position.set(0,.02,10);driveCar.rotation.y=0;startedAt=performance.now();chaseElapsed=0;chaseShown=false;pursuer.visible=true;pursuer2.visible=true;pursuer3.visible=true;pursuer.position.set(0,0,25);pursuer2.position.set(2.5,0,33);pursuer3.position.set(-2.5,0,40);showDrive();hint.textContent='Steer through the rain. ACCELERATE to move, BRAKE to slow down, REVERSE to back up. Three anonymous cars appear behind you; their purpose is unknown.';say('KOCHI OUTSKIRTS · 2026 · HEAVY RAIN',2800);return;
 }
 if(id===10){
   player.visible=false;mode='missionDrive';warehouseSet.visible=true;waitingCar.visible=true;warehouseFigure.group.visible=true;bag.visible=true;bagMarker.visible=true;driveCar.visible=true;driveCar.position.set(0,.02,27);driveCar.rotation.y=0;driveCar.children[0].material=mat(0xe0d8c6,.65);showDrive();hint.textContent='2004 · Drive the old white Ambassador along the isolated road. The small black bag and the waiting figure are ahead.';setObjective('Drive to the isolated warehouse','2004 · 2 A.M.');say('AN OLD WHITE AMBASSADOR · APPROXIMATELY 2 A.M.',2800);return;
 }
 if(id===14){
   mode='missionWalk';setAtmosphere('home');wreck.visible=true;player.position.set(2,0,-29);player.visible=true;assistanceCar.visible=true;strandedDriver.group.visible=true;bystanders.forEach(n=>n.group.visible=true);showWalk('TALK TO DRIVER',{minX:-12,maxX:10,minZ:-37,maxZ:4});hint.textContent='Roadside assistance: talk to the stranded driver, then help move the car safely off the road.';setObjective('Talk to the stranded driver','OPTIONAL SIDE MISSION');return;
 }
 if([2,3,4,9].includes(id)){
   mode='missionWalk';homeSet.visible=true;homeRelative.group.visible=true;homeExtra.group.visible=id===3;homeExtra2.group.visible=id===3;homePhone.visible=id===2;homeBagMarker.visible=id===2;homePhoto.visible=[4,9].includes(id);homePapers.visible=[4,9].includes(id);homeKeys.visible=id===4;homeRelative.group.position.set(2.8,0,3.1);
   player.position.set(id===2?77: id===3?74:80,0,id===3?5:2);showWalk(id===2?'ANSWER THE CALL':id===3?'TALK TO RELATIVE':'INTERACT',{minX:72,maxX:88,minZ:-6,maxZ:7});hint.textContent='Move with the D-pad. Approach the marked object or person and tap the interaction button.';
   if(id===2)setObjective('Answer the phone','THE CALL');if(id===3)setObjective('Speak to the relative','BACK TO KOCHI');if(id===4)setObjective('Search Abraham’s room','A HOUSE FULL OF SILENCE');if(id===9)setObjective('Search the papers','THE DATE');return;
 }
 if([5,6,7,8,11,13].includes(id)){
   mode='missionWalk';
   garage.visible=true;flashbackSet.visible=id===7;garage.visible=id!==7;
   if(id===5){player.position.set(42,0,1);customer.position.set(52,0,-1);customer.visible=true;brokenCustomerCar.visible=true;garageRafi.group.visible=false;showWalk('INSPECT VEHICLE',{minX:37,maxX:55,minZ:-8,maxZ:8});hint.textContent='Rafi’s Day: inspect the customer’s broken-down car first. The customer may not take the diagnosis well.';setObjective('Diagnose the broken-down car','RAFI’S DAY');return}
   player.position.set(id===7?43:id===6?42:id===8?42:id===11?42:42,0,id===7?1:2);evidenceCar.visible=[6,8,11,13].includes(id);oldAmbassador.visible=id===7;garageTable.visible=[11,13].includes(id);garageRafi.group.visible=[6,8,11,13].includes(id);abrahamNPC.group.visible=id===7;brokenCustomerCar.visible=false;customer.visible=false;
   showWalk(id===6?'INSPECT DAMAGED CAR':id===7?'INSPECT VEHICLE':id===8?'TALK TO RAFI':id===11?'SHOW PHOTOGRAPH':'REVIEW EVIDENCE',{minX:37,maxX:56,minZ:-9,maxZ:9});hint.textContent='Explore the garage. Approach the car, person or workbench for the next story interaction.';
   if(id===6)setObjective('Inspect the brake line','THE CAR');if(id===7)setObjective('Inspect Abraham’s car','2015 · THE FIRST TIME');if(id===8)setObjective('Ask Rafi what he remembers','WHAT RAFI REMEMBERS');if(id===11)setObjective('Show Rafi the photograph','THE PHOTOGRAPH');if(id===13)setObjective('Review the evidence on the workbench','THE FIRST QUESTION');return;
 }
 if(id===12){mode='missionWalk';industrialSet.visible=true;industrialRafi.group.visible=true;floorPatch.visible=true;player.position.set(121,0,2);showWalk('INSPECT FLOOR',{minX:115,maxX:151,minZ:-18,maxZ:8});hint.textContent='Search the possible warehouse with Rafi. The building’s identity is not confirmed.';setObjective('Find evidence inside the possible warehouse','THE OLD ROAD');return}
}

// Keep the three chase vehicles visually separate and anonymous.
function updatePursuitCars(){if(currentMissionId!==1||!(mode==='drive'||mode==='failure')){pursuer2.visible=false;pursuer3.visible=false;return}pursuer2.visible=pursuer.visible;pursuer3.visible=pursuer.visible;const x=driveCar.position.x+Math.sin(carYaw)*9;const z=driveCar.position.z+Math.cos(carYaw)*11;pursuer2.position.lerp(new THREE.Vector3(x+2.7,0,z+7),.045);pursuer3.position.lerp(new THREE.Vector3(x-2.7,0,z+14),.04);pursuer2.rotation.y=carYaw;pursuer3.rotation.y=carYaw}
function updateMissionWalking(dt){
 const f=(walk.up||keys.w||keys.arrowup?1:0)-(walk.down||keys.s||keys.arrowdown?1:0),s=(walk.right||keys.d||keys.arrowright?1:0)-(walk.left||keys.a||keys.arrowleft?1:0);
 const move=new THREE.Vector3(s,0,-f);let moving=false;if(move.lengthSq()>0){moving=true;move.normalize();move.applyAxisAngle(new THREE.Vector3(0,1,0),cameraYaw);player.position.addScaledVector(move,dt*3.05);player.rotation.y=Math.atan2(move.x,move.z)}
 player.position.x=THREE.MathUtils.clamp(player.position.x,walkBounds.minX,walkBounds.maxX);player.position.z=THREE.MathUtils.clamp(player.position.z,walkBounds.minZ,walkBounds.maxZ);
 if(moving){walkCycle+=dt*8.5;const swing=Math.sin(walkCycle)*.52;walkRig.legs[0].rotation.x=swing;walkRig.legs[1].rotation.x=-swing;walkRig.arms[0].rotation.x=-swing*.65;walkRig.arms[1].rotation.x=swing*.65;player.position.y=Math.abs(Math.sin(walkCycle*2))*.025}else{player.position.y=THREE.MathUtils.damp(player.position.y,0,9,dt);for(const limb of [...walkRig.legs,...walkRig.arms])limb.rotation.x=THREE.MathUtils.damp(limb.rotation.x,0,9,dt)}
 followCamera(new THREE.Vector3(player.position.x,player.position.y,player.position.z),cameraDistance);
}
function updateMissionDrive(dt,now){
 const inputThrottle=throttle||keys.w||keys.arrowup,inputReverse=reverseHeld||keys.x,inputBrake=braking||keys.s||keys.arrowdown;
 if(inputThrottle&&!inputReverse)carSpeed=Math.min(carSpeed+dt*5.2,12);else if(inputReverse){if(carSpeed>0)carSpeed=Math.max(0,carSpeed-dt*8);else carSpeed=Math.max(-4,carSpeed-dt*3)}else if(inputBrake)carSpeed=carSpeed>0?Math.max(0,carSpeed-dt*8):Math.min(0,carSpeed+dt*8);else carSpeed=carSpeed>0?Math.max(0,carSpeed-dt*.7):Math.min(0,carSpeed+dt*.7);
 if(Math.abs(carSpeed)>.3){const sens=window.KochiAudio?.getSettings?.().sensitivity??.85;carYaw-=steer*dt*(.09+Math.min(Math.abs(carSpeed)/12,1)*.31)*sens*Math.sign(carSpeed);}driveCar.position.x-=Math.sin(carYaw)*carSpeed*dt;driveCar.position.z-=Math.cos(carYaw)*carSpeed*dt;driveCar.rotation.y=carYaw;followCamera(new THREE.Vector3(driveCar.position.x,0,driveCar.position.z-1),cameraDistance+2);
 if(currentMissionId===5&&missionStage===3&&(driveCar.position.z<1||now-missionDriveStart>14000)){
  driveCar.visible=false;showWalk('REPAIR JOB',{minX:37,maxX:55,minZ:-8,maxZ:8});mode='rafiDone';completeMission(5,'RAFI’S DAY','Rafi diagnoses the breakdown, handles the aggressive customer, moves the car into the bay, repairs it and completes a short test drive. The confrontation is local and is not connected to Abraham’s death.');return;
 }
 if(currentMissionId===10&&!warehouseCarArrived&&(driveCar.position.z<-30||now-missionDriveStart>8500)){
  warehouseCarArrived=true;driveCar.visible=false;player.visible=true;mode='missionWalk';player.position.set(3,0,-35);cameraYaw=0;cameraPitch=.2;showWalk('PICK UP THE BAG',{minX:0,maxX:34,minZ:-69,maxZ:-30});setObjective('Approach the small black bag','THE WAREHOUSE · 2004');hint.textContent='Leave the Ambassador and approach the black bag inside the isolated warehouse. The waiting figure’s identity is unknown.';say('THE ENGINE IDLES OUTSIDE. ANOTHER CAR IS WAITING.',2500);
 }
}
function updateMissionWorld(dt,now){
 if(mode==='missionWalk'){updateMissionWalking(dt)}
 if(mode==='missionDrive')updateMissionDrive(dt,now);
 if(currentMissionId===12&&unknownCarDeparting&&departureCar.visible){departureCar.position.x+=dt*3.8;if(departureCar.position.x>47){departureCar.visible=false;unknownCarDeparting=false}}
 if(currentMissionId===12&&mode==='missionWalk'&&player.position.distanceTo(new THREE.Vector3(144,0,-7))<9&&departureCar.visible&&!unknownCarDeparting){/* Headlights become visible only after the floor is inspected. */}
 if(currentMissionId===10&&warehouseCutscene&&now<shakeUntil){camera.position.x+=(Math.random()-.5)*.09;camera.position.y+=(Math.random()-.5)*.08}
 updatePursuitCars();
}
let campaignLast=performance.now();
function campaignLoop(){requestAnimationFrame(campaignLoop);const now=performance.now(),dt=Math.min((now-campaignLast)/1000,.04);campaignLast=now;if(mode!=='paused')updateMissionWorld(dt,now);drawMiniMap();
 // Subtle patrol movement gives the roadside a little life; characters are still simple prototype NPCs.
 if([1,14].includes(currentMissionId)&&['drive','failure','missionWalk'].includes(mode)){for(let i=0;i<bystanders.length;i++){const n=bystanders[i];if(n.group.visible&&i===1){n.walkClock+=dt*1.2;n.group.position.x=n.origin.x+Math.sin(n.walkClock)*.55;n.legs[0].rotation.x=Math.sin(n.walkClock*3)*.18;n.legs[1].rotation.x=-n.legs[0].rotation.x}}}
}
campaignLoop();

function interactMission(){
 if(mode==='rafiDone'&&currentMissionId===5){
  if(missionStage===1){if(Math.hypot(player.position.x-47.5,player.position.z-.4)>5){say('Return to the customer’s car first.',1600);return}showDialogue([['RAFI','Let’s move it into the bay and finish the diagnosis.']],()=>{brokenCustomerCar.position.set(4.5,-3.5);missionStage=2;setObjective('Repair the diagnosed fault','RAFI’S DAY');document.querySelector('#inspect').textContent='REPAIR CAR';customer.visible=false});return}
  if(missionStage===2){if(Math.hypot(player.position.x-49.5,player.position.z+3.5)>5){say('Move over to the car in the repair bay.',1600);return}showDialogue([['NARRATION','Rafi completes the repair and checks the vehicle.'],['RAFI','Now we test it before handing it back.']],()=>{missionStage=3;setObjective('Test the repaired car','RAFI’S DAY');document.querySelector('#inspect').textContent='START TEST DRIVE'});return}
  if(missionStage===3){mode='missionDrive';missionDriveStart=performance.now();driveCar.visible=true;driveCar.position.set(48,0,9);driveCar.rotation.y=0;carSpeed=0;carYaw=0;setAtmosphere('garage');showDrive();hint.textContent='Short test drive: ACCELERATE through the garage approach, then BRAKE. REVERSE remains available.';setObjective('Drive forward to test the repair','RAFI’S DAY');return}
 }
 if(mode==='aftermath'&&currentMissionId===0){say('The wreck offers no easy answers.',1800);return}
 if(mode!=='missionWalk'&&mode!=='rafiDone'){say('There is nothing to interact with right now.',1300);return}
 const id=currentMissionId;
 if(id===2){if(missionStage===0){if(!within(77,2.1,4)){say('Move closer to the ringing phone.',1500);return}showDialogue([['FAMILY MEMBER','Vivek… it’s your father. There’s been an accident.'],['VIVEK','What? Where is he?'],['FAMILY MEMBER','He’s gone, Vivek. I’m sorry.']],()=>{missionStage=1;setObjective('Pack to return to Kochi','THE CALL');document.querySelector('#inspect').textContent='PACK BAG'});return}if(!within(75,3.2,4)){say('Pack your bag before leaving.',1500);return}showDialogue([['NARRATION','Vivek packs his things and prepares to return to Kochi. The call has given him no details beyond the death.']],()=>completeMission(2));return}
 if(id===3){if(!within(82.8,3.1,5)){say('Go inside and speak to the relative.',1500);return}showDialogue([['RELATIVE','They said it was an accident.'],['VIVEK','They said?'],['NARRATION','The city outside carries on. Vivek enters Abraham’s room.']],()=>completeMission(3));return}
 if(id===4){if(missionStage===0){if(!within(85,-2.8,4)){say('Look around Abraham’s room first.',1500);return}showDialogue([['NARRATION','Family photographs and old papers fill the room. The house is full of familiar things that explain very little.']],()=>{missionStage=1;setObjective('Examine the old papers','A HOUSE FULL OF SILENCE');document.querySelector('#inspect').textContent='EXAMINE PAPERS'});return}
  if(missionStage===1){if(!within(83.2,-.8,4)){say('Move closer to the papers.',1500);return}showDialogue([['NARRATION','The papers do not explain the crash. A ring of car keys rests nearby.']],()=>{missionStage=2;setObjective('Take the car keys','A HOUSE FULL OF SILENCE');document.querySelector('#inspect').textContent='TAKE CAR KEYS'});return}
  if(missionStage===2){if(!within(84.7,.25,4)){say('The keys are beside the other belongings.',1500);return}showDialogue([['VIVEK','The car…'],['RELATIVE','The wrecked car has been released. Take it to a mechanic tomorrow.'],['NARRATION','Vivek pockets the keys. No explanation for the accident has emerged.']],()=>completeMission(4));return}}
 if(id===5){if(missionStage===0){if(!within(47.5,-1.1,4.8)){say('Inspect the broken-down customer car first.',1500);return}showDialogue([['CUSTOMER','What is taking so long? I need this car fixed.'],['RAFI','That’s why you brought it to one.'],['CUSTOMER','Don’t get clever with me.'],['RAFI','I’ll change what needs changing. Not everything that can be changed.'],['NARRATION','The customer steps toward Rafi. A practical argument becomes physical.']],()=>{missionStage=1;mode='rafi';customer.visible=true;customer.position.set(51.5,0,-1);player.position.set(47,0,0);customer.rotation.set(0,0,0);customer.position.y=0;customerCombatPose={type:'idle',time:0,duration:0};playerCombatPose={type:'idle',time:0,duration:0};customerHealth=100;rafiHealth=100;fightCooldown=0;customerAttackTimer=2;dodgeTime=0;setPlayerLook('RAFI');showWalk('PUNCH',{minX:37,maxX:55,minZ:-8,maxZ:8});document.querySelectorAll('.combat').forEach(b=>b.classList.remove('hidden'));document.querySelector('#inspect').classList.add('hidden');document.querySelector('#fight-status').classList.remove('hidden');hint.textContent='Keep close enough to counter. PUNCH attacks, hold BLOCK to reduce damage, DODGE to evade. No weapons.';setObjective('Defend yourself from the aggressive customer','RAFI’S DAY');updateFightStatus()});return}say('Use PUNCH, BLOCK and DODGE to end the confrontation.',1600);return}
 if(id===6){if(missionStage===0){if(!within(49,-2,5)){say('Move to Abraham’s damaged car.',1500);return}showDialogue([['RAFI','This damage concerns me. I want to inspect the brake line.'],['RAFI','Its condition looks wrong, but that does not prove anyone did this deliberately.'],['VIVEK','Then find out why they’re so certain.']],()=>{missionStage=1;setObjective('Ask Rafi how he knew Abraham','THE CAR');document.querySelector('#inspect').textContent='TALK TO RAFI'});return}if(!within(43,1,5)){say('Rafi is by the garage work area.',1500);return}showDialogue([['VIVEK','How did you know my father?'],['RAFI','He was a regular customer. I knew the cars he brought in. I never knew everything about his life.']],()=>completeMission(6));return}
 if(id===7){if(missionStage===0){if(!within(49,-1,5)){say('Move closer to the old car.',1500);return}showDialogue([['RAFI · 2015','The engine is misfiring. I’ll check the ignition and fuel delivery first.'],['NARRATION','Rafi diagnoses the car and completes a straightforward repair.']],()=>{missionStage=1;setObjective('Speak to Abraham before he leaves','2015 · THE FIRST TIME');document.querySelector('#inspect').textContent='TALK TO ABRAHAM'});return}if(!within(51,1,5)){say('Abraham is waiting beside the car.',1500);return}showDialogue([['ABRAHAM','How much?'],['RAFI · 2015','That’s the repair. Nothing more.'],['NARRATION','Abraham pays and leaves. They are not yet close.']],()=>completeMission(7));return}
 if(id===8){if(missionStage===0){if(!within(43,1,5)){say('Find Rafi near the garage workbench.',1500);return}showDialogue([['VIVEK','What do you remember about him?'],['RAFI','He came here often. I knew him as a customer, but I never knew everything he did.']],()=>{missionStage=1;setObjective('Review the damaged car again','WHAT RAFI REMEMBERS');document.querySelector('#inspect').textContent='REVIEW CAR'});return}if(!within(49,-2,5)){say('Go back to the damaged car.',1500);return}showDialogue([['RAFI','Something about this damage is not right. But I can’t say it was deliberate.']],()=>completeMission(8));return}
 if(id===9){if(missionStage===0){if(!within(83.2,-.8,4)){say('Search the papers in Abraham’s room.',1500);return}showDialogue([['NARRATION','Among the papers is an old photograph. A date is written on it: 2004.']],()=>{missionStage=1;setObjective('Examine the photograph','THE DATE');document.querySelector('#inspect').textContent='EXAMINE PHOTO'});return}if(!within(85,-2.8,4)){say('Look at the photograph on the room’s table.',1500);return}showDialogue([['VIVEK','An Ambassador. An industrial building.'],['NARRATION','The photograph identifies a year, not a location. Neither Vivek nor Rafi can place the building yet.']],()=>completeMission(9));return}
 if(id===10){if(missionStage===0){if(!within(15,-53,4.5)){say('Move inside the warehouse toward the small black bag.',1500);return}bag.visible=false;bagMarker.visible=false;missionStage=1;setObjective('Approach the waiting figure','THE WAREHOUSE · 2004');document.querySelector('#inspect').textContent='APPROACH FIGURE';say('The bag stays closed. You carry it to the waiting person.',2000);return}if(!within(18,-51,5)){say('Approach the person beside the waiting car.',1500);return}showDialogue([['UNIDENTIFIED PERSON','Did you open it?'],['ABRAHAM','No. I brought what you asked for.'],['NARRATION','A sudden noise. Gunshots. The scene breaks apart.']],()=>{warehouseCutscene=true;shakeUntil=performance.now()+1100;controls.classList.add('hidden');hint.classList.add('hidden');fadeTo(1);mode='blackout';setTimeout(()=>{warehouseCutscene=false;fadeTo(0);completeMission(10,'THE WAREHOUSE','Gunshots cut the 2004 scene to black. The person’s identity, the bag’s contents and the outcome are unknown.')},1450)});return}
 if(id===11){if(missionStage===0){if(!within(46,-4,5.5)){say('Bring the photograph to Rafi’s workbench.',1500);return}showDialogue([['VIVEK','The photograph is dated 2004. Do you recognise the building?'],['RAFI','No. I can’t place it exactly. We should start with what we can verify.'],['VIVEK','You check the car. I’ll go through the papers.']],()=>{missionStage=1;setObjective('Review the inspection notes','THE PHOTOGRAPH');document.querySelector('#inspect').textContent='REVIEW NOTES'});return}if(!within(46,-4,5.5)){say('Review the inspection notes on the workbench.',1500);return}showDialogue([['RAFI','I’ll finish checking the car. Don’t assume the photograph tells us more than it does.']],()=>completeMission(11));return}
 if(id===12){if(missionStage===0){if(!within(144,-.2,5)){say('Search the possible warehouse floor.',1500);return}showDialogue([['NARRATION','A patch of floor looks as though something was moved recently. It cannot tell you who moved it, when, or what was there.'],['SFX','A distant engine starts. Headlights sweep across the warehouse wall.']],()=>{missionStage=1;departureCar.visible=true;unknownCarDeparting=true;setObjective('Leave the area with Rafi','THE OLD ROAD');document.querySelector('#inspect').textContent='TALK TO RAFI';say('An unknown vehicle pulls away. No identity is visible.',2300)});return}if(!within(133,2,8)){say('Rafi is waiting near the warehouse entrance.',1500);return}showDialogue([['RAFI','We should leave. We don’t know who that was, and we’re not confronting them.']],()=>completeMission(12));return}
 if(id===13){if(missionStage===0){if(!within(46,-4,5.5)){say('Go to the workbench with the car, photograph and notes.',1500);return}showDialogue([['NARRATION','The damaged car. The 2004 photograph. Rafi’s inspection notes. The evidence does not yet make a complete answer.']],()=>{missionStage=1;setObjective('Ask Rafi the first question','THE FIRST QUESTION');document.querySelector('#inspect').textContent='TALK TO RAFI'});return}if(!within(43,1,5)){say('Rafi is beside the workbench.',1500);return}showDialogue([['VIVEK','And if it wasn’t an accident?'],['RAFI','Then we find who knew enough to make it happen.'],['NARRATION','The image holds on Abraham’s photograph. The cause of his death, the warehouse identities, and the black bag remain unresolved.']],()=>completeMission(13,'THE FIRST QUESTION','ACT I COMPLETE. The questions are open: the accident, the 2004 warehouse, the black bag and the people who were there remain unidentified.'));return}
 if(id===14){if(missionStage===0){if(!within(-7,-6,4.5)){say('Move closer to the stranded driver.',1500);return}showDialogue([['STRANDED DRIVER','My car stopped on me. Could you help me move it out of the road?'],['VIVEK','Let’s get it safely off the lane.']],()=>{missionStage=1;setObjective('Help move the stranded car','ROADSIDE ASSISTANCE');document.querySelector('#inspect').textContent='HELP DRIVER'});return}if(!within(-5,-8,5)){say('Move to the stranded car.',1500);return}showDialogue([['NARRATION','Together, you get the car clear of the road. The traffic can pass safely again.'],['STRANDED DRIVER','Thanks. Drive carefully.']],()=>completeMission(14,'ROADSIDE ASSISTANCE','Side activity completed. The encounter is unrelated to the unresolved circumstances of Abraham’s death.'));return}
 say('No interaction available here.',1400);
}

// Replace the early one-scene buttons with the campaign flow.
document.querySelector('#begin').onclick=()=>startMission(1);
document.querySelector('#free-roam-start').onclick=startFreeRoam;
document.querySelector('#vehicle-toggle').onclick=toggleFreeRoamVehicle;
document.querySelector('#vehicle-enter').onclick=toggleFreeRoamVehicle;
document.querySelector('#side-job').onclick=openSideJobs;
document.querySelector('#job-courier').onclick=()=>startSideJob('courier');document.querySelector('#job-taxi').onclick=()=>startSideJob('taxi');document.querySelector('#job-sprint').onclick=()=>startSideJob('sprint');document.querySelector('#job-cancel').onclick=()=>{document.querySelector('#side-job-panel').classList.add('hidden');mode='freeRoam';controls.classList.remove('hidden');hint.classList.remove('hidden');syncWeaponHud()};
document.querySelector('#open-missions').onclick=openMissionBoard;
document.querySelector('#close-missions').onclick=closeMissionBoard;
document.querySelector('#continue').onclick=()=>{if(currentMissionId>0&&currentMissionId<13)startMission(currentMissionId+1);else openMissionBoard()};
document.querySelector('#play-rafi').onclick=openMissionBoard;
document.querySelector('#play-assist').onclick=()=>startMission(14);
document.querySelector('#inspect').onclick=interactMission;
document.querySelector('#pause-button').onclick=togglePause;document.querySelector('#resume-game').onclick=togglePause;document.querySelector('#restart-mission').onclick=()=>{document.querySelector('#pause-menu').classList.add('hidden');const id=currentMissionId;pausedMode=null;startMission(id)};document.querySelector('#pause-missions').onclick=()=>{document.querySelector('#pause-menu').classList.add('hidden');pausedMode=null;openMissionBoard()};
addEventListener('keydown',e=>{if((e.key==='Escape'||e.key.toLowerCase()==='p')&&['drive','missionDrive','missionWalk','rafi','rafiDone','aftermath','freeRoam'].includes(mode))togglePause()});

// After a crash the only known facts are the skid, impact and failed brake pedal.
crash=function(){
 mode='crash';pursuer.visible=false;pursuer2.visible=false;pursuer3.visible=false;crashAt=performance.now();setObjective('');say('THE BRAKES ARE NOT RESPONDING',1900);driveCar.visible=false;fadeTo(1);
 setTimeout(()=>{wreck.visible=true;bystanders.forEach(n=>n.group.visible=true);if(abraham)abraham.visible=false},600);
 setTimeout(()=>{fadeTo(0);document.body.classList.remove('cinema');controls.classList.add('hidden');hint.classList.add('hidden');completeMission(1,'THE ACCIDENT','Abraham dies after his car crashes in heavy rain. Three unidentified vehicles were seen following him, but their purpose and any connection to the brake failure remain unknown.')},1700)
};

// 2004 warehouse and current-day industrial scene car locations stay separate from the story conclusion.
function resetMissionVisuals(){pursuer2.visible=false;pursuer3.visible=false;}

// Fix keyboard interactions so the same interaction button works across all missions.
addEventListener('keydown',e=>{if(e.key==='Escape'&& !missionBoard.classList.contains('hidden'))closeMissionBoard();if(e.key==='Escape'&& !dialoguePanel.classList.contains('hidden'))dialogueNext.click()});

// Build the mission board defensively so a UI rendering issue cannot abort the rest of game initialization.
try{buildMissionBoard()}catch(err){console.error('Mission board initialization failed:',err)}


// Persistent campaign state and functional main/pause menu navigation.
const SAVE_KEY='kochiHomecoming.save.v1';
function persistGameSave(extra={}){
 try{const old=JSON.parse(localStorage.getItem(SAVE_KEY)||'{}');const id=extra.missionId??currentMissionId;const title=missionData.find(m=>m.id===id)?.title||'Act I';localStorage.setItem(SAVE_KEY,JSON.stringify({...old,...extra,missionTitle:title,savedAt:Date.now()}));}catch(e){console.warn('Kochi save could not be written',e)}
}
function readGameSave(){try{const x=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');return x&&typeof x==='object'?x:null}catch(_){return null}}
function continueSavedGame(){const save=readGameSave();if(!save){say('No save yet. Choose NEW GAME to begin.',1800);return}const id=save.status==='complete'?(save.nextMissionId||Math.min(13,(save.missionId||1)+1)):(save.missionId||1);document.querySelector('#title-card').classList.add('hidden');document.querySelector('#load-panel')?.classList.add('hidden');startMission(Math.max(1,Math.min(14,id)));}
function returnToMainMenu(){
 persistGameSave({status:'in-progress',missionId:currentMissionId||1,nextMissionId:currentMissionId||1,cash:cashBalance,completed:[...completedMissions]});
 for(const id of ['pause-menu','load-panel','settings-panel','credits-panel','mission-board','end-card','dialogue-panel','side-job-panel'])document.getElementById(id)?.classList.add('hidden');
 controls.classList.add('hidden');hint.classList.add('hidden');document.querySelector('#phone-shell')?.classList.add('hidden');document.querySelector('#vehicle-diagnostics')?.classList.add('hidden');document.querySelector('#loading-screen')?.classList.add('hidden');document.querySelector('#title-card').classList.remove('hidden');document.body.classList.remove('cinema');document.body.classList.add('menu-state');mode='title';setWorldLayerForMode(false);pausedMode=null;player.visible=false;driveCar.visible=false;wreck.visible=false;pursuer.visible=pursuer2.visible=pursuer3.visible=false;trafficCars.forEach(c=>c.visible=false);freeRoamNPCs.forEach(n=>n.group.visible=false);policeCars.forEach(c=>c.visible=false);document.querySelector('#wanted-level').textContent='';window.KochiAudio?.setMenuActive(true);cameraYaw=0;cameraPitch=.1;cameraDistance=12;followCamera(new THREE.Vector3(0,0,0),15);
}
window.KochiGame={readSave:readGameSave,continueGame:continueSavedGame,returnToMainMenu,save:()=>persistGameSave({status:'in-progress',missionId:currentMissionId||1,nextMissionId:currentMissionId||1,cash:cashBalance,completed:[...completedMissions]})};
document.querySelector('#continue-game')?.addEventListener('click',continueSavedGame);

document.querySelector('#begin').onclick=()=>{const save=readGameSave();if(save&&!confirm('Start a new game? Your saved campaign progress will be replaced.'))return;persistGameSave({status:'in-progress',missionId:1,nextMissionId:1,cash:2500,completed:[]});completedMissions.clear();cashBalance=2500;document.querySelector('#cash-value').textContent='2,500';startMission(1)};
document.querySelector('#return-main-menu')?.addEventListener('click',returnToMainMenu);
document.querySelector('#pause-button').onclick=togglePause;
// Restore the saved money and completion count on cold launch; mission restart remains explicit.
try{const saved=readGameSave();if(saved){cashBalance=Number(saved.cash)||2500;document.querySelector('#cash-value').textContent=cashBalance.toLocaleString('en-IN');for(const id of (saved.completed||[]))if(Number.isInteger(id))completedMissions.add(id);document.querySelector('#mission-progress').textContent=`ACT I · ${[...completedMissions].filter(n=>n>=1&&n<=13).length}/13`;}}catch(_){ }
// Graphics option genuinely adjusts render pixel ratio/shadows, within the renderer already in use.
window.KochiApplyGraphics=(quality)=>{if(!renderer)return;const dpr=quality==='low'?1:quality==='high'?Math.min(devicePixelRatio,1.7):Math.min(devicePixelRatio,1.35);renderer.setPixelRatio(dpr);renderer.shadowMap.enabled=quality!=='low';renderer.setSize(innerWidth,innerHeight)};window.KochiApplyGraphics(window.KochiAudio?.getSettings?.().graphics||'balanced');

// HUD expansion: sprint, vehicle telemetry, camera toggle and a usable in-game phone.
let sprintHeld=false,phoneReturnMode=null,firstPersonView=false,fuelPercent=86,vehicleTypeIndex=0;
const vehicleLabels=['SEDAN'];
const sprintButton=document.querySelector('#sprint');
if(sprintButton){const setSprint=v=>{sprintHeld=v;sprintButton.classList.toggle('active',v)};sprintButton.addEventListener('pointerdown',e=>{e.preventDefault();setSprint(true)});['pointerup','pointercancel','pointerleave'].forEach(ev=>sprintButton.addEventListener(ev,()=>setSprint(false)));}
function refreshVehicleDiagnostics(){const panel=document.querySelector('#vehicle-diagnostics');if(!panel)return;const active=freeRoamActive&&!freeRoamOnFoot&&['freeRoam','map','phone'].includes(mode);panel.classList.toggle('hidden',!active);if(active){document.querySelector('#speed-value').textContent=String(Math.round(Math.abs(carSpeed)*GAME_METERS_PER_UNIT*3.6)).padStart(3,'0');document.querySelector('#fuel-value').textContent=Math.round(fuelPercent)+'%';document.querySelector('#fuel-fill').style.width=fuelPercent+'%';document.querySelector('#camera-mode').textContent='CAMERA · '+(firstPersonView?'FIRST PERSON':'THIRD PERSON');document.querySelector('#vehicle-type').textContent='VEHICLE · '+vehicleLabels[vehicleTypeIndex];}}
const baseUpdateFreeRoam=updateFreeRoam;
updateFreeRoam=function(dt){baseUpdateFreeRoam(dt);if(freeRoamActive&&!freeRoamOnFoot&&Math.abs(carSpeed)>.05)fuelPercent=Math.max(0,fuelPercent-dt*.012);refreshVehicleDiagnostics()};
const cameraButton=document.querySelector('#camera-mode');cameraButton?.addEventListener('click',()=>{firstPersonView=!firstPersonView;cameraDistance=firstPersonView?1.15:8;cameraPitch=firstPersonView?.02:.18;refreshVehicleDiagnostics();say(firstPersonView?'FIRST-PERSON CAMERA · PROTOTYPE':'THIRD-PERSON CAMERA',1200)});
document.querySelector('#vehicle-type')?.addEventListener('click',()=>{say('Only the sedan model is currently drivable. Other vehicle classes are planned, not implemented.',2200)});
function openPhone(){if(!freeRoamActive||!['freeRoam','map'].includes(mode))return;clearHeldControls();phoneReturnMode=mode;mode='phone';document.querySelector('#phone-shell').classList.remove('hidden');document.querySelector('#phone-clock').textContent=`${String(Math.floor(freeRoamClockMinutes/60)).padStart(2,'0')}:${String(Math.floor(freeRoamClockMinutes%60)).padStart(2,'0')}`;document.querySelector('#phone-status').textContent='OFFLINE · ON DEVICE';refreshVehicleDiagnostics()}
function closePhone(){document.querySelector('#phone-shell').classList.add('hidden');if(mode==='phone')mode=phoneReturnMode||'freeRoam';phoneReturnMode=null;refreshVehicleDiagnostics()}
document.querySelector('#phone-open')?.addEventListener('click',openPhone);document.querySelector('#phone-close')?.addEventListener('click',closePhone);
document.querySelectorAll('[data-phone-action]').forEach(btn=>btn.addEventListener('click',()=>{const action=btn.dataset.phoneAction;if(action==='map'){closePhone();openWorldMap()}else if(action==='missions'){closePhone();openMissionBoard()}else if(action==='jobs'){closePhone();openSideJobs()}else if(action==='save'){window.KochiGame?.save?.();document.querySelector('#phone-message').textContent='GAME SAVED ON THIS DEVICE';window.KochiAudio?.playImpactSfx?.('confirm');}}));
const phoneModeKeyHandler=e=>{if(e.key==='Escape'&&mode==='phone')closePhone()};addEventListener('keydown',phoneModeKeyHandler);
