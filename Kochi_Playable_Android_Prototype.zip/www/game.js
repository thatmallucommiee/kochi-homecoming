import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const host=document.querySelector('#game');
// Prevent Android WebView's native text-copy menu from appearing over the game HUD.
document.addEventListener('contextmenu', event => event.preventDefault());

const scene=new THREE.Scene();scene.background=new THREE.Color(0x11191e);scene.fog=new THREE.FogExp2(0x11191e,.018);
const camera=new THREE.PerspectiveCamera(58,innerWidth/innerHeight,.1,260);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;host.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0x9aafc0,0x211a16,1.15));const moon=new THREE.DirectionalLight(0x9eb7ce,1.2);moon.position.set(-15,22,9);moon.castShadow=true;moon.shadow.mapSize.set(1024,1024);scene.add(moon);
const amber=new THREE.PointLight(0xffa15c,23,25,2);amber.position.set(4,4,-13);scene.add(amber);const redLight=new THREE.PointLight(0xf12d23,16,16,2);redLight.position.set(-5,2,-20);scene.add(redLight);
const mat=(c,r=.86,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
const M={asphalt:mat(0x222b30,.42),line:mat(0xb5a88e,.65),concrete:mat(0x4b514f),roof:mat(0x252b2c),leaf:mat(0x193b2e),trunk:mat(0x45372b),glass:mat(0x101d24,.15,.3),rubber:mat(0x111315),metal:mat(0x454b4d,.35,.65),rust:mat(0x6a3b2a),skin:mat(0x966849),shirt:mat(0x7a3028),pants:mat(0x302c29),lamp:mat(0xffd4a0,.2)};
function mesh(g,m,x=0,y=0,z=0,parent=scene){const o=new THREE.Mesh(g,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o}function box(parent,x,y,z,w,h,d,m){return mesh(new THREE.BoxGeometry(w,h,d),m,x,y,z,parent)}function cyl(parent,x,y,z,r1,r2,h,m,n=10){return mesh(new THREE.CylinderGeometry(r1,r2,h,n),m,x,y,z,parent)}
const ground=mesh(new THREE.PlaneGeometry(220,220),mat(0x17221f),0,-.12,0);ground.rotation.x=-Math.PI/2;const road=mesh(new THREE.PlaneGeometry(15,170),M.asphalt,0,-.045,-18);road.rotation.x=-Math.PI/2;const sheen=mesh(new THREE.PlaneGeometry(14.6,150),new THREE.MeshStandardMaterial({color:0x344149,roughness:.18,metalness:.22,transparent:true,opacity:.28}),0,-.025,-18);sheen.rotation.x=-Math.PI/2;
for(let z=-92;z<58;z+=8){box(scene,0,.018,z,.12,.008,3.2,M.line);box(scene,-7.4,.018,z,.12,.008,3.2,M.line);box(scene,7.4,.018,z,.12,.008,3.2,M.line)}for(let z=-80;z<42;z+=13){box(scene,-8.5,.08,z,.5,.16,1.1,M.concrete);box(scene,8.5,.08,z,.5,.16,1.1,M.concrete)}
function palm(x,z,h=7){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);cyl(g,0,h/2,0,.15,.3,h,M.trunk,7);for(let i=0;i<7;i++){const a=i*Math.PI*2/7;const f=box(g,Math.cos(a)*1.1,h+.05,Math.sin(a)*1.1,2.8,.08,.35,M.leaf);f.rotation.y=-a;f.rotation.z=Math.cos(a)*-.3}cyl(g,0,h,0,.24,.24,.25,M.leaf,8)}
function house(x,z,w,d,h,color,shop=false){const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);box(g,0,h/2,0,w,h,d,mat(color));box(g,0,h+.18,0,w+.3,.35,d+.3,M.roof);for(let f=0;f<Math.max(1,Math.floor(h/2.5));f++)for(let xx=-w/2+1;xx<w/2-.5;xx+=2){box(g,xx,1.35+f*2.4,d/2+.03,.8,1.05,.06,M.glass);box(g,xx,1.9+f*2.4,d/2+.08,.9,.08,.07,M.concrete)}if(shop){box(g,0,1.25,d/2+.08,w*.6,1.45,.08,M.glass);box(g,0,2.12,d/2+.12,w*.72,.24,.1,mat(0x703d2a))}}
house(-13,-26,9,9,6,0x716454);house(13,-30,9,9,8,0x5d6864);house(-15,-8,7,8,4.5,0x8b6c55,true);house(15,-4,8,8,5,0x66685f,true);house(-14,14,8,8,6,0x64584d);house(15,19,9,8,7,0x5d6260);for(const [x,z,h] of [[-11,-34,8],[11,-39,7],[-20,-18,9],[20,-22,8],[-10,3,7],[10,8,8],[-22,20,9],[23,28,8],[-11,-52,8],[11,-55,9]])palm(x,z,h);
function streetLamp(x,z){cyl(scene,x,3.1,z,.08,.11,6.2,M.metal,8);box(scene,x+.6,6.1,z,1.25,.09,.1,M.metal);box(scene,x+1.12,5.95,z,.42,.13,.28,M.lamp);const l=new THREE.PointLight(0xffb86d,18,19,2);l.position.set(x+1,5.7,z);scene.add(l)}streetLamp(-9,-18);streetLamp(9,-42);streetLamp(-9,8);
// Static accident set dressing: damaged sedan, bent rail, skid marks and glass shards.
const wreck=new THREE.Group();wreck.position.set(-1.2,0,-18);wreck.rotation.y=-.34;scene.add(wreck);wreck.visible=false;
box(wreck,0,.57,0,2.05,.58,4.05,M.rust);box(wreck,0,1.05,-.12,1.62,.72,1.85,M.glass);box(wreck,0,1.13,1.18,1.8,.25,1.15,M.metal);box(wreck,0,.94,-1.72,1.8,.2,.55,M.rust);for(const x of [-1.03,1.03])for(const z of [-1.25,1.25]){const wh=cyl(wreck,x,.33,z,.34,.34,.22,M.rubber,14);wh.rotation.z=Math.PI/2;const hub=cyl(wreck,x*1.01,.33,z,.16,.16,.23,M.metal,12);hub.rotation.z=Math.PI/2}const hood=box(wreck,-.24,1.48,-1.15,.9,.12,1.2,M.rust);hood.rotation.z=-.22;hood.rotation.x=.13;const door=box(wreck,1.16,.78,.12,.12,.75,1.3,M.metal);door.rotation.y=.2;door.rotation.z=-.08;
for(let i=0;i<11;i++){const shard=mesh(new THREE.TetrahedronGeometry(.1+Math.random()*.13),new THREE.MeshStandardMaterial({color:0x7f9ca4,metalness:.25,roughness:.12,transparent:true,opacity:.7}),-3+Math.random()*5,.08+Math.random()*.16,-19+Math.random()*4);shard.rotation.set(Math.random(),Math.random(),Math.random())}for(let i=0;i<4;i++){const debris=box(scene,-3.5+Math.random()*5,.09,-22+Math.random()*7,.4+Math.random()*.7,.09,.15+Math.random()*.35,i%2?M.rust:M.metal);debris.rotation.y=Math.random()*2}for(let i=0;i<6;i++){const mark=box(scene,-2.7+i*.32,.012,-10-i*1.1,.09,.008,2.8,mat(0x101518,.95));mark.rotation.y=-.16}for(let i=0;i<4;i++){const post=box(scene,4.8,.45,-18-i*1.1,.12,.9,.12,M.metal);post.rotation.z=i%2?.2:-.12}box(scene,4.8,.08,-20,5,.13,.18,M.metal);
const rainCount=460,rainGeo=new THREE.BufferGeometry(),rainPos=new Float32Array(rainCount*3);for(let i=0;i<rainCount;i++){rainPos[i*3]=(Math.random()-.5)*42;rainPos[i*3+1]=Math.random()*18;rainPos[i*3+2]=-28+Math.random()*48}rainGeo.setAttribute('position',new THREE.BufferAttribute(rainPos,3));const rain=new THREE.Points(rainGeo,new THREE.PointsMaterial({color:0x9fb6c3,size:.045,transparent:true,opacity:.48}));scene.add(rain);
// Static Meshy geometry candidate. This export is NOT a faithful, rigged Abraham character yet.
// Do not invent costume regions with procedural vertex colours; preserve its supplied mesh/materials.
let abraham=null;
new GLTFLoader().load('assets/models/abraham.glb',g=>{
  const root=new THREE.Group();
  root.add(g.scene);
  const b=new THREE.Box3().setFromObject(root);
  const size=b.getSize(new THREE.Vector3());
  const scale=1.68/Math.max(size.y,.01);
  root.scale.setScalar(scale);
  const bb=new THREE.Box3().setFromObject(root);
  root.position.y=-bb.min.y;
  root.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});
  // Keep this unverified mesh hidden until a correctly matching, rigged Abraham asset is available.
  root.visible=false;
  scene.add(root);
  abraham=root;
},undefined,()=>console.warn('Abraham GLB failed to load'));
// Simple driver silhouette in the moving car until the static character export is seated/rigged.
const driver=new THREE.Group();cyl(driver,0,.95,-.12,.23,.25,.5,M.shirt,12);mesh(new THREE.SphereGeometry(.18,12,10),M.skin,0,1.34,-.12,driver);mesh(new THREE.SphereGeometry(.19,12,8,0,Math.PI*2,0,Math.PI*.55),M.rubber,0,1.39,-.12,driver);
const player=new THREE.Group();scene.add(player);player.position.set(2,0,-11);
cyl(player,0,1.12,0,.27,.31,.66,M.shirt,12);
mesh(new THREE.SphereGeometry(.2,14,12),M.skin,0,1.78,0,player);
mesh(new THREE.SphereGeometry(.205,12,8,0,Math.PI*2,0,Math.PI*.58),M.rubber,0,1.83,0,player);
// Lightweight procedural rig: pivot the limbs at shoulders/hips for a visible walk cycle.
const walkRig={legs:[],arms:[]};
for(const side of [-1,1]){
  const hip=new THREE.Group();hip.position.set(side*.13,.79,0);player.add(hip);
  box(hip,0,-.36,0,.15,.72,.18,M.pants);walkRig.legs.push(hip);
  const shoulder=new THREE.Group();shoulder.position.set(side*.31,1.38,0);player.add(shoulder);
  const arm=box(shoulder,0,-.27,0,.13,.54,.14,M.skin);arm.rotation.z=side*-.08;walkRig.arms.push(shoulder);
}
player.visible=false;let walkCycle=0;
let mode='title',startedAt=0,crashAt=0,found=false,steer=0,braking=false,toastTimer=0;const fade=document.querySelector('#fade'),caption=document.querySelector('#caption'),hint=document.querySelector('#hint'),controls=document.querySelector('#controls'),objective=document.querySelector('#objective-text'),phase=document.querySelector('#phase-label');
function say(t,ms=2800){caption.textContent=t;caption.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>caption.classList.add('hidden'),ms)}function fadeTo(v){fade.style.opacity=String(v)}function setObjective(t,p='PROLOGUE'){objective.textContent=t;phase.textContent=p}function hold(id,fn){const b=document.querySelector(id);b.addEventListener('pointerdown',e=>{e.preventDefault();fn(true)});for(const ev of ['pointerup','pointercancel','pointerleave'])b.addEventListener(ev,()=>fn(false))}
hold('#left',v=>{steer=v?-1:0});hold('#right',v=>{steer=v?1:0});hold('#brake',v=>{braking=v});let throttle=false;hold('#throttle',v=>{throttle=v});const walk={up:false,down:false,left:false,right:false};hold('#up',v=>walk.up=v);hold('#down',v=>walk.down=v);hold('#walk-left',v=>walk.left=v);hold('#walk-right',v=>walk.right=v);
document.querySelector('#begin').onclick=()=>{document.querySelector('#title-card').classList.add('hidden');document.body.classList.add('cinema');controls.classList.remove('hidden');document.querySelector('#drive-controls').classList.remove('hidden');document.querySelector('#walk-controls').classList.add('hidden');hint.classList.remove('hidden');mode='drive';startedAt=performance.now();setObjective('Keep the car on the road');say('KOCHI OUTSKIRTS · LATE NIGHT',2600)};
document.querySelector('#inspect').onclick=()=>{if(mode!=='aftermath')return;const d=player.position.distanceTo(new THREE.Vector3(-1.2,0,-18));if(d<7){if(!found){found=true;setObjective('Clue found · cause unknown','THE MORNING AFTER');say('The car is wrecked. The cause is not clear from here.',4000)}else say('The wreck offers no easy answers.',3000)}else say('Move closer to the wreck first.',1800)};
document.querySelector('#continue').onclick=()=>{document.querySelector('#end-card').classList.add('hidden');mode='aftermath';player.visible=true;player.position.set(2,0,-11);camera.position.set(2,4,-3);setObjective('Inspect the wreck','THE MORNING AFTER');hint.textContent='Move around the roadside and inspect the wreck.';hint.classList.remove('hidden');controls.classList.remove('hidden');document.querySelector('#drive-controls').classList.add('hidden');document.querySelector('#walk-controls').classList.remove('hidden')};
const keys={};addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key==='ArrowLeft')steer=-1;if(e.key==='ArrowRight')steer=1;if(e.key===' '&&mode==='drive')braking=true;if(e.key.toLowerCase()==='e')document.querySelector('#inspect').click()});addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;if(e.key==='ArrowLeft'&&steer===-1)steer=0;if(e.key==='ArrowRight'&&steer===1)steer=0;if(e.key===' ')braking=false});
// Drag to orbit the camera. Controls/cards are excluded so button presses never rotate the view.
let cameraYaw=0,cameraPitch=.22,cameraDistance=8,dragging=false,lastX=0,lastY=0;
renderer.domElement.addEventListener('pointerdown',e=>{if(e.target.closest('button')||mode==='title'||mode==='end')return;dragging=true;lastX=e.clientX;lastY=e.clientY;renderer.domElement.setPointerCapture?.(e.pointerId)});
renderer.domElement.addEventListener('pointermove',e=>{if(!dragging)return;const dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;cameraYaw-=dx*.008;cameraPitch=THREE.MathUtils.clamp(cameraPitch+dy*.006,-.15,.8)});
for(const ev of ['pointerup','pointercancel','pointerleave'])renderer.domElement.addEventListener(ev,()=>dragging=false);
function followCamera(target,dist=cameraDistance){const horizontal=Math.cos(cameraPitch)*dist;const desired=new THREE.Vector3(target.x+Math.sin(cameraYaw)*horizontal,target.y+2.1+Math.sin(cameraPitch)*dist,target.z+Math.cos(cameraYaw)*horizontal);camera.position.lerp(desired,.16);camera.lookAt(target.x,target.y+1,target.z)}
const clock=new THREE.Clock();let carYaw=0,carSpeed=0;const driveCar=new THREE.Group();driveCar.position.set(0,.02,10);scene.add(driveCar);box(driveCar,0,.58,0,1.95,.58,3.8,M.rust);box(driveCar,0,1.03,-.18,1.58,.62,1.85,M.glass);for(const x of [-.98,.98])for(const z of [-1.18,1.18]){const wh=cyl(driveCar,x,.32,z,.31,.31,.2,M.rubber,12);wh.rotation.z=Math.PI/2}driveCar.add(driver);for(const x of [-.56,.56]){mesh(new THREE.BoxGeometry(.36,.14,.08),new THREE.MeshBasicMaterial({color:0xffe0ac}),x,.7,-1.92,driveCar);const beam=new THREE.SpotLight(0xffd6a0,8,23,.36,.55,1.4);beam.position.set(x,.7,-1.85);beam.target.position.set(x,0,-18);driveCar.add(beam,beam.target)}
function crash(){mode='crash';crashAt=performance.now();setObjective('');say('THE BRAKES ARE NOT RESPONDING',1900);driveCar.visible=false;fadeTo(1);setTimeout(()=>{wreck.visible=true;if(abraham)abraham.visible=false},600);setTimeout(()=>{fadeTo(0);document.body.classList.remove('cinema');document.querySelector('#end-card').classList.remove('hidden');controls.classList.add('hidden');hint.classList.add('hidden');say('RAIN. SILENCE. DISTANT TRAFFIC.',2800);mode='end'},1600)}
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04),now=performance.now();if(mode==='drive'){
  const inputThrottle=throttle||keys.w||keys.arrowup;
  const inputBrake=braking||keys.s||keys.arrowdown;
  // Responsive arcade handling with acceleration, coasting, braking and speed-sensitive steering.
  if(inputThrottle)carSpeed=Math.min(carSpeed+dt*5.2,13);
  else carSpeed=Math.max(0,carSpeed-dt*1.05);
  if(inputBrake)carSpeed=Math.max(0,carSpeed-dt*8.5);
  const steerStrength=.25+Math.min(carSpeed/13,1)*.9;
  carYaw+=steer*dt*steerStrength*(carSpeed>.2?1:0);
  driveCar.position.x+=Math.sin(carYaw)*carSpeed*dt;
  driveCar.position.z-=Math.cos(carYaw)*carSpeed*dt;
  driveCar.rotation.y=carYaw;
  followCamera(new THREE.Vector3(driveCar.position.x,driveCar.position.y,driveCar.position.z-1.2),cameraDistance+2);
  // Story event: after a short drive the cut brake line fails, independent of the player's input.
  if(now-startedAt>9500){say('The brake pedal drops to the floor.',2400);mode='failure';crashAt=now;}
  if(Math.abs(driveCar.position.x)>5.8){driveCar.position.x=THREE.MathUtils.clamp(driveCar.position.x,-5.8,5.8);carYaw*=-.35;carSpeed*=.72;steer=0}
}else if(mode==='failure'){
  carSpeed=Math.min(15,carSpeed+dt*1.2);carYaw+=steer*dt*1.05;
  driveCar.position.x+=Math.sin(carYaw)*carSpeed*dt;driveCar.position.z-=Math.cos(carYaw)*carSpeed*dt;driveCar.rotation.y=carYaw;
  followCamera(new THREE.Vector3(driveCar.position.x,driveCar.position.y,driveCar.position.z-1),cameraDistance+1);
  if(now-crashAt>3200)crash();
}else if(mode==='aftermath'){
  const f=(walk.up||keys.w||keys.arrowup?1:0)-(walk.down||keys.s||keys.arrowdown?1:0);
  const s=(walk.right||keys.d?1:0)-(walk.left||keys.a?1:0);
  const move=new THREE.Vector3(s,0,-f);let moving=false;
  if(move.lengthSq()>0){moving=true;move.normalize();move.applyAxisAngle(new THREE.Vector3(0,1,0),cameraYaw);player.position.addScaledVector(move,dt*3.1);player.rotation.y=Math.atan2(move.x,-move.z)}
  // Animate the placeholder's arms and legs while moving; ease back to idle when stopped.
  if(moving){walkCycle+=dt*9;const swing=Math.sin(walkCycle)*.62;walkRig.legs[0].rotation.x=swing;walkRig.legs[1].rotation.x=-swing;walkRig.arms[0].rotation.x=-swing*.72;walkRig.arms[1].rotation.x=swing*.72;player.position.y=Math.abs(Math.sin(walkCycle*2))*.035}
  else{walkCycle=0;player.position.y=THREE.MathUtils.damp(player.position.y,0,10,dt);for(const limb of [...walkRig.legs,...walkRig.arms]){limb.rotation.x=THREE.MathUtils.damp(limb.rotation.x,0,10,dt)}}
  player.position.x=THREE.MathUtils.clamp(player.position.x,-7,7);player.position.z=THREE.MathUtils.clamp(player.position.z,-37,5);
  followCamera(new THREE.Vector3(player.position.x,player.position.y,player.position.z),cameraDistance);
}const p=rainGeo.attributes.position;for(let i=0;i<rainCount;i++){p.array[i*3+1]-=dt*11;if(p.array[i*3+1]<0){p.array[i*3+1]=16+Math.random()*2;p.array[i*3]=camera.position.x+(Math.random()-.5)*38;p.array[i*3+2]=camera.position.z+(Math.random()-.5)*42}}p.needsUpdate=true;amber.intensity=23+Math.sin(now*.002)*2;redLight.intensity=16+Math.sin(now*.006)*7;renderer.render(scene,camera)}cameraYaw=0;cameraPitch=.22;camera.position.set(0,4,20);camera.lookAt(0,0,0);animate();addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
