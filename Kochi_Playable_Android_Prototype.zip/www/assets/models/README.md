# Abraham character asset

`abraham.glb` is the Meshy export supplied for the prototype. It contains a single static mesh, but no embedded materials, textures, skeleton, or animations. The runtime applies approximate vertex colours for the first mission. This is a prototype integration, not a finished rigged character. Inspect and replace with a textured/rigged export when available.
