# KOCHI: HOMECOMING — Visual Rebuild Pass

This is a source-level visual pass, not a finished AAA/GTA V-equivalent game.

## Changes in this pass
- Reworked the procedural human model silhouette with rounded torso/limbs, improved head/hair proportions, facial details, clothing seams and better limb proportions while retaining the existing procedural animation rig.
- Reworked the procedural sedan with a clearer hood/trunk, cabin roof and pillars, door seams/handles, mirrors, bumpers, grille, light clusters, four wheels and hubs.
- Improved default scene readability with a warmer key light, brighter hemisphere fill and lighter atmospheric fog.
- Disabled unnecessary per-mesh cast/receive-shadow flags while renderer shadow maps are disabled, reducing CPU bookkeeping without claiming dynamic shadows.
- Kept the existing offline OpenStreetMap build pipeline and mobile rendering settings; did not enable costly real-time shadows or increase pixel ratio because the target phone already experiences lag.

## Limitations
- Character and vehicle meshes remain procedural low-poly models; they are not licensed photorealistic GLB assets and do not have motion-captured animation.
- This does not rebuild all buildings into hand-authored architecture or add enterable interiors.
- This does not provide a full GTA V replica. It is a visual improvement pass within the existing Three.js prototype.
- Syntax and archive integrity can be checked here; live rendering, touch controls and FPS still require a new APK tested on the Poco X7 5G.
