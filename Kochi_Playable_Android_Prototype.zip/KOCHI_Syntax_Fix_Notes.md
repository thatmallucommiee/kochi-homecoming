# KOCHI: HOMECOMING — Syntax / Black Screen Fix

## Root cause
`www/game.js` was missing the closing brace for `animate()` after its render-loop `try/catch`. Because the function was left open, the initialization code after the render loop—including the initial camera setup and `animate()` call—was parsed as function-body code instead of top-level startup code. The HTML HUD could remain visible while the WebGL scene never began rendering, matching the reported black-screen symptom.

## Fix
Added the missing closing brace immediately after the animation loop's error-recovery `try/catch`, before initial camera setup, the top-level `animate()` call, and the resize listener.

## Checks completed locally
- `node --input-type=module --check < www/game.js` — passed.
- `node --check www/audio.js` — passed.
- `python3 -m py_compile scripts/fetch_kochi_map.py` — passed.
- Static HTML ID check: 88 direct `querySelector('#...')` references found matching IDs among 131 HTML IDs; no missing IDs.
- Required offline-source assets present.
- No external CDN references detected under `www/`.
- ZIP integrity test — passed.

## Not yet verified
This fix has not yet been uploaded to the GitHub repository, rebuilt by Actions, or tested on a physical Android device. The next APK should come from a new successful Actions run and must then be tested on-device. A syntax check alone is not a guarantee against all runtime or visual bugs.
