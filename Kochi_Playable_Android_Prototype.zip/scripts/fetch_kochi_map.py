#!/usr/bin/env python3
"""Fetch a compact OpenStreetMap extract for the KOCHI: HOMECOMING offline build.

The map is fetched only during packaging. The resulting JSON is included in the APK;
the installed game never contacts Overpass or any tile server.
"""
from __future__ import annotations
import json, os, sys, time, urllib.parse, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "www" / "assets" / "data" / "kochi-map.json"
# Central Kochi playable region spanning Fort Kochi/Mattancherry, Ernakulam and east toward Vyttila.
SOUTH, WEST, NORTH, EAST = 9.9400, 76.2250, 10.0200, 76.3450
BBOX = f"{SOUTH},{WEST},{NORTH},{EAST}"
QUERY = f'''[out:json][timeout:120];(
 way["highway"]({BBOX});
 way["building"]({BBOX});
 way["waterway"]({BBOX});
 way["natural"~"water|wood|scrub|tree_row"]({BBOX});
 way["landuse"~"forest|grass|residential|commercial|retail|industrial|recreation_ground|park|orchard"]({BBOX});
 way["leisure"~"park|pitch|garden|playground"]({BBOX});
 way["railway"]({BBOX});
 node["amenity"~"cinema|hospital|marketplace|police|school|college|bus_station|ferry_terminal|place_of_worship"]({BBOX});
 node["shop"]({BBOX});
 node["tourism"~"museum|attraction|viewpoint|hotel"]({BBOX});
);out geom;'''
ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
]

def compact(element):
    tags = element.get("tags", {})
    typ = element.get("type")
    if typ == "way":
        geom = element.get("geometry") or []
        coords = [[p.get("lon"), p.get("lat")] for p in geom if "lon" in p and "lat" in p]
        if len(coords) < 2:
            return None
        if "building" in tags and len(coords) < 3:
            return None
        return {"type": "way", "id": element.get("id"), "tags": tags, "coordinates": coords}
    if typ == "node" and "lat" in element and "lon" in element:
        if not any(k in tags for k in ("amenity", "shop", "tourism", "name", "railway")):
            return None
        return {"type": "node", "id": element.get("id"), "tags": tags, "coordinates": [[element["lon"], element["lat"]]]}
    return None

def main():
    if os.environ.get("KOCHI_MAP_SKIP_DOWNLOAD") == "1":
        raise SystemExit("Refusing to produce an offline APK with missing Kochi map data.")
    payload = urllib.parse.urlencode({"data": QUERY}).encode()
    last_error = None
    for endpoint in ENDPOINTS:
        for attempt in range(3):
            try:
                req = urllib.request.Request(endpoint, data=payload, headers={
                    "User-Agent": "KochiHomecoming-OfflineMapBuilder/0.3 (OpenStreetMap data; ODbL attribution included)",
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "Accept": "application/json",
                })
                with urllib.request.urlopen(req, timeout=150) as response:
                    raw = json.loads(response.read())
                break
            except Exception as exc:
                last_error = exc
                time.sleep(2 + attempt * 3)
        else:
            continue
        if raw.get("elements"):
            features = [item for el in raw["elements"] if (item := compact(el))]
            # Keep only map features with at least one useful coordinate in the requested bounds.
            features = [f for f in features if any(WEST - .003 <= p[0] <= EAST + .003 and SOUTH - .003 <= p[1] <= NORTH + .003 for p in f["coordinates"])]
            if len(features) < 100:
                raise SystemExit(f"OpenStreetMap response unexpectedly small: {len(features)} features; refusing to package a fake map.")
            OUT.parent.mkdir(parents=True, exist_ok=True)
            document = {
                "schema": 1,
                "source": "OpenStreetMap contributors",
                "license": "Open Database License (ODbL) 1.0",
                "attribution": "© OpenStreetMap contributors · ODbL 1.0",
                "center": [76.2828, 9.9817],
                "bbox": [WEST, SOUTH, EAST, NORTH],
                "features": features,
            }
            OUT.write_text(json.dumps(document, separators=(",", ":")), encoding="utf-8")
            print(f"Saved {len(features)} offline OSM features ({OUT.stat().st_size:,} bytes) to {OUT}")
            return
    raise SystemExit(f"Could not fetch OpenStreetMap data from configured Overpass endpoints: {last_error}")

if __name__ == "__main__":
    main()
