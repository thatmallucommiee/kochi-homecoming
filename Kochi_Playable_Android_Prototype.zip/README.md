# KOCHI: The Uncounted Road — Android prototype

This is an early playable prototype, not the complete Unreal Engine game. It preserves the premise: Vivek returns to Kochi after Abraham's apparent road-accident death and begins investigating.

## Play immediately
Open `www/index.html` in a modern mobile browser. Internet access is currently needed for the Three.js module loaded from jsDelivr.

## Build a debug APK with GitHub Actions (no PC needed)
1. Create a new **public or private** GitHub repository in your phone browser.
2. Upload the contents of this ZIP (not the ZIP itself) to the repository. Keep `.github/workflows/android-apk.yml` and `package.json`.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Run **Build Android APK** using **Run workflow** (or push a commit; it also runs on pushes).
5. Wait for the workflow to finish, open its run, and download the `Kochi-Android-Debug-APK` artifact.
6. Extract the artifact ZIP and install the APK. Android may ask permission to install from that source.

The workflow builds a Capacitor Android shell using GitHub-hosted runners. It does **not** compile the Unreal Engine C++ project.

## Current prototype
- Touch joystick and on-screen action buttons
- Third-person follow camera
- Small tropical coastal-city blockout with roads, buildings, palms and a garage
- Walk/run and basic vehicle interaction
- Opening clue: inspect Abraham's damaged car and find the cut-brake-line clue
- Save-free vertical slice; no weapons or invented syndicate plot

## Limitations
- Early prototype geometry, not photorealistic assets.
- The Three.js library is loaded from a CDN, so first launch needs internet.
- Debug APK is unsigned for Play Store distribution; it can be installed locally.
- Android packaging depends on GitHub Actions and your repository permissions. No APK is included until the workflow succeeds.
