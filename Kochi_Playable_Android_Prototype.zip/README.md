# Kochi: Homecoming — phone-first accident mission prototype

This is still a **Three.js + Capacitor prototype**, not a Unity or Unreal project. This update focuses on correcting basic mobile playability before any engine migration.

## Improvements in this pass
- Landscape Android orientation is configured by `.github/workflows/main.yml` (the workflow file is provided separately).
- Touch-drag on the gameplay area rotates the follow camera; controls are excluded from camera dragging.
- On-foot movement is relative to camera direction and the character turns toward movement.
- Vehicle has hold-to-accelerate, hold-to-brake, coasting and speed-sensitive steering instead of automatic acceleration only.
- Abraham's current GLB is preserved as a source asset but deliberately not rendered as the character because it is an unrigged, untextured mesh and does not reliably match the supplied face/costume reference. The on-foot body remains a temporary placeholder.

## Known limitations (do not call this finished)
- The scene uses procedural geometry, not realistic scanned/production assets.
- The character placeholder is not animated; the Abraham GLB has no rig or animation clips.
- Vehicle handling is improved arcade handling, not a full physics simulation.
- The brake failure is a scripted story event, not a simulated damaged brake system.
- The scene has not been device-tested after these changes. A successful APK build only proves compilation.
- This project remains Three.js/Capacitor. Unity/Unreal migration requires an editor/build environment not available directly on the user's Android phone.

## Build
Upload this ZIP as `Kochi_Playable_Android_Prototype.zip` in the GitHub repository, and replace `.github/workflows/main.yml` with the accompanying `main.yml`. Commit both; the GitHub Actions workflow builds the debug APK and sets Android orientation to landscape.
