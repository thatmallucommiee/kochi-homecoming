# Kochi: Homecoming — Android prototype

This ZIP is intended to replace `Kochi_Playable_Android_Prototype.zip` in the GitHub repository. The existing GitHub Actions workflow extracts the ZIP and builds an Android debug APK.

## Prologue: The Accident
- Cinematic late-night drive on a wet, fictionalized Kochi road.
- Brake failure and crash transition.
- Rain, wet-road sheen, sodium street lamps, Kerala-style buildings and palms, damaged sedan, debris, skid marks and bent roadside rail.
- After the crash, a short exploration phase lets the player approach and inspect the wreck.
- The cause is deliberately left unknown; the scene does not confirm who tampered with the car.

## Character asset status
`www/assets/models/abraham.glb` contains the supplied Meshy model. It is a static, untextured, unrigged mesh. The runtime adds approximate vertex colours; it is not a final production character and has no animations.

## Build
The repo's `.github/workflows/main.yml` runs `npm install`, `npx cap add android`, `npx cap sync android`, then `./gradlew assembleDebug`. It uses Three.js via a CDN import map, so the first launch requires network access.

## Replace on GitHub using a phone
Upload this ZIP and choose to replace the existing `Kochi_Playable_Android_Prototype.zip` in the repository root. Commit the change to `main`; the existing Actions workflow should start automatically. Download the `Kochi-Homecoming-APK` artifact after the run succeeds. The APK has not been built or device-tested as part of preparing this ZIP.
