# KOCHI: HOMECOMING — Android Playable Act I Prototype

**Archive name expected by the repository workflow:** `Kochi_Playable_Android_Prototype.zip`

This is a phone-first **Three.js + Capacitor** playable prototype. It is not an Unreal Engine project and is not yet a finished AAA open-world game. FREE ROAM contains a bounded, fictionalized Kochi district with roads, traffic, pedestrians, enter/exit vehicle controls, side jobs, cash rewards and a basic wanted/police response. The latest map/weapon patch adds an interactive online OpenStreetMap view centred near central Kochi, a heading-up rotating local radar, a Free Roam weapon wheel with functional prototype firearms, synthesized gun/impact effects, and basic static building collision. The real-world map pin is an approximate projection: the Three.js city roads and buildings are still procedural and do not yet match the real streets precisely. The mission board contains all **13 Act I story missions** and one optional roadside-assistance side mission.

## Act I story / mission list

### Prologue — The Accident (2026, heavy rain)
Play as Abraham on the road outside Kochi. Learn steering, acceleration, braking and reverse. Three anonymous vehicles appear behind him and pressure the drive. Their identity and purpose are not shown. The brake pedal then fails at a bend; Abraham crashes and dies. The chase is **not** proof that the unknown vehicles caused the brake failure.

### Chapter 1 — Homecoming
**2. The Call** — At his residence outside Kochi, Vivek receives the call from a family member telling him that Abraham died in an accident. The scene establishes the loss and starts Vivek’s return.

**3. Back to Kochi** — Vivek reaches the family home. A relative says, “They said it was an accident.” The city continues around him while he enters the house.

**4. A House Full of Silence** — Explore Abraham’s room. Examine family photographs, papers and the car keys. The relative explains that the wrecked car has been released and can be taken to a mechanic the next day. The room gives no definitive answer about the crash.

### Chapter 2 — Another Side of the City
**5. Rafi’s Day (2026)** — Play as Rafi at the garage. Inspect the customer’s broken-down car; a tense exchange escalates into a short, grounded hand-to-hand fight. Counter with PUNCH, hold BLOCK to reduce damage, and use DODGE to evade. After the customer backs off, move the car into the bay, repair it, and complete a short test drive using the driving controls. The established dialogue beats include “That’s why you brought it to one” and “I’ll change what needs changing. Not everything that can be changed.” The customer is not presented as a criminal mastermind.

**6. The Car (2026)** — Play as Vivek. Inspect Abraham’s damaged vehicle and its brake-line area. Rafi finds the condition concerning but cannot prove intentional tampering. Vivek asks how Rafi knew Abraham; Rafi explains that he was a recurring customer but that he never knew everything about Abraham’s life.

### Chapter 3 — Before Vivek
**7. The First Time (2015)** — Play as Rafi at around 21. Abraham arrives at a small repair workplace on a rainy night. Diagnose and repair his car, then speak to Abraham before he pays and leaves. This is an ordinary mechanic-customer interaction; they are not yet close.

**8. What Rafi Remembers (2026)** — Vivek asks Rafi what he remembers. Rafi repeats that Abraham was a regular customer and that he never knew the whole story. He believes something about the car damage is wrong, but cannot say that it was deliberate.

### Chapter 4 — The Past Does Not Stay Buried
**9. The Date (2026)** — Search Abraham’s papers and examine an old photograph dated 2004. It shows Abraham beside an Ambassador outside an industrial building. The date and image are a lead, not an exact location.

**10. The Warehouse (2004, around 2 a.m.)** — Drive the old white Ambassador through rain toward an isolated warehouse. Abraham carries a small black bag; another car waits. Approach the bag and the unidentified figure. The person asks, “Did you open it?” Abraham answers, “No. I brought what you asked for.” A sudden noise and gunshots cut the scene to black. The bag’s contents, the people’s identities and the outcome remain unknown.

### Chapter 5 — Connecting the Pieces
**11. The Photograph (2026)** — Vivek shows the dated photograph to Rafi. Neither can identify the precise building. They agree to start with evidence: Rafi will finish checking the car while Vivek searches Abraham’s papers. The playable characters do not know what the player saw in the 2004 flashback.

**12. The Old Road (2026, next day)** — Vivek and Rafi investigate an industrial area and enter a possible warehouse. Inspect a patch of floor that looks as if something was moved recently; it cannot reveal who, when or what. A distant engine starts, headlights sweep a wall, and an unidentified vehicle leaves. Rafi advises leaving rather than confronting the unknown person. This building is **not confirmed** to be the 2004 warehouse, and the vehicle is not confirmed to be related.

**13. The First Question (2026, night)** — At Rafi’s garage, review the damaged car, photograph and inspection notes. Vivek asks what if Abraham’s death was not an accident. Rafi answers that they must find who knew enough to make it happen. The game holds on Abraham’s photograph and ends Act I with the key questions open.

### Optional side mission
**14. Roadside Assistance (2026)** — After the crash, roadside bystanders are present and a stranded driver needs help moving a car out of the road. Talk to the driver and complete the assistance interaction. This is a small world-building encounter; it does not connect the driver to Abraham’s death.

## Important story constraints preserved

- The unidentified vehicles’ purpose and their link, if any, to Abraham’s brake failure are unresolved.
- Nothing confirms that the brake line was deliberately cut.
- The unidentified warehouse person, black bag contents, gunshots’ outcome and identities remain unresolved.
- Rafi knows part of Abraham’s life through the garage, not the complete truth.
- The 2026 industrial building and departing car are not confirmed to be the 2004 warehouse or its occupants.
- No newly invented syndicate, conspiracy or culprit is established.

## New free-roam mode (this version)

From the title screen choose **FREE ROAM · KOCHI**. The player starts in a car inside a bounded, connected street-grid district (approximately 180 × 180 game units). It is designed for roaming between roads, junctions, shops, homes and industrial blocks rather than remaining on the prologue road.

- Traffic cars follow simple horizontal/vertical loops; pedestrians stroll short routes along the sidewalks.
- **EXIT VEHICLE** parks the current car and switches to on-foot controls. Walk close to the parked car and tap **ENTER VEHICLE** to return to driving.
- **SIDE JOBS** opens Courier, Taxi Fare and Street Sprint activities. Follow the gold marker on the heading-up local radar and reach each target to earn cash.
- **MAP**: the minimap rotates into the direction you are travelling. Tap **OPEN CITY MAP** to show real OpenStreetMap streets for Kochi. Pinch to zoom, drag to pan, rotate with two fingers and use **FOLLOW** to recenter. The full map is online-only and the pin uses a rough game-world-to-geographic projection; the 3D roads are not yet geospatially aligned.
- **WEAPONS** are enabled in **FREE ROAM while on foot** only. Exit the car, tap **WEAPONS**, choose PISTOL / SMG / SHOTGUN / UNARMED, hold FIRE to shoot, and tap RELOAD to refill from reserve ammunition. Story missions remain unarmed. Shooting can trigger a wanted response. The prototype uses simple procedural gun meshes, raycast hit detection and synthesized transient SFX; it is not realistic firearm animation or a finished ballistics simulation.
- High-speed collisions with traffic or pedestrians can raise a basic five-star wanted level. Simple police cars pursue while the heat cools. This is a prototype mechanic and should be balanced after on-device testing.
- Free-roam steering uses a gentler speed-sensitive turning rate; the car is no longer clamped to the prologue's narrow road corridor. BRAKE stops the car; REVERSE first slows forward motion and then moves backward.

The district is deliberately bounded rather than an endless world. Traffic avoidance, pedestrians, police behavior and driving physics are simplified and are not yet at GTA production quality.

## Controls (landscape, touch first)

### Driving — Abraham’s prologue and the 2004 flashback
- **◀ / ▶:** steer left / right (hold).
- **ACCELERATE:** hold to drive forward.
- **BRAKE:** hold to slow down and stop.
- **REVERSE:** hold; first slows forward motion, then reverses the car.
- **Camera:** drag on open gameplay space, away from buttons, to orbit. Steering now uses a lower speed-sensitive yaw rate and reverse steering direction, and free-roam driving is not locked to the prologue road corridor.
- **Pause:** tap Ⅱ in the HUD; resume, restart the current mission or open mission select. Press Escape/P on a keyboard.
- **Keyboard:** Left / Right arrow to steer; W or Up to accelerate; S / Down or Space to brake; X to reverse.

### Walking / investigation
- Use the **D-pad** to move. Follow the objective marker on the minimap. Approach the highlighted/marked object or NPC and tap the context action button (for example, INSPECT PAPERS, TALK TO RAFI, PICK UP THE BAG or HELP DRIVER).
- **Camera:** drag on open gameplay space.
- **Keyboard:** W/A/S/D or arrow keys to move; E activates the context action.

### Rafi’s fight
- **D-pad:** move.
- **PUNCH:** tap to counter when close to the customer.
- **BLOCK:** press and hold to reduce incoming damage.
- **DODGE:** tap to evade an incoming swing.
- **Keyboard:** J punch, hold K to block, L to dodge.
- There are no weapons in this fight. Combat is distance-based prototype logic, not motion-captured animation.

## Project and build notes

- Android packaging: Capacitor 7; renderer: Three.js 0.160.0.
- App ID: `com.aswinmohan.kochihomecoming`; title: `Kochi: Homecoming`.
- `www/assets/models/abraham.glb` is preserved in the project but is not assumed to be a faithful rigged character; the current playable bodies are low-poly procedural placeholders.
- The web entry currently loads Three.js and its GLTF loader from jsDelivr, so the app requires a network connection to load those modules at runtime.
- The prototype includes a GTA-inspired quality-of-life layer: rotating local radar, an interactive real-world OpenStreetMap overlay and objective blips, cash and rewards, mission progress, pause/restart/mission-select, low-poly buildings, garage/workbench and warehouse spaces, story dialogue, and a bounded free-roam district with a connected street grid, moving traffic, strolling pedestrians, player enter/exit of the current car, courier/taxi/street-sprint side jobs, and a basic five-star wanted indicator with simple police pursuit after a high-speed collision. The wanted/police and side-job systems are prototype mechanics, not finished simulation. These are original implementations of familiar open-world conventions, not GTA assets. This is a closed playable district, not a city-scale GTA map. It still lacks production-quality models, voice acting, advanced vehicle suspension/traction, arbitrary vehicle theft/entry, sophisticated traffic AI, full police tactics, and fully rigged character animation.
- JavaScript syntax and ZIP integrity should be checked before committing. Android compilation still must be confirmed by GitHub Actions, and actual touch/gameplay behavior must be tested on the Poco X7 5G.

## Build through the existing repository workflow

1. Upload this ZIP to the repository root using the **exact filename** `Kochi_Playable_Android_Prototype.zip` (replace the previous file; do not rename it to the `_NPCs` variant).
2. Commit the upload to `main`.
3. Open the repository’s **Actions** tab and inspect the new build.
4. After a green tick, download the `Kochi-Homecoming-APK` artifact, extract it and install the APK.

The workflow’s extraction step expects `Kochi_Playable_Android_Prototype.zip`, which is why retaining that exact name matters.


## October 2026 presentation, audio and handling update

- Reuses the developer-supplied logo at `www/assets/images/kochi-homecoming-logo.png` without altering the original artwork.
- Adds the user-supplied main-menu track at `www/assets/audio/rain-slicked_perimeter.mp3`, looping only while the main menu is active and controlled by persisted master/music/mute preferences.
- Adds master/music/SFX/ambience volume controls, touch-steering sensitivity and low/balanced/high renderer options; preferences are stored in localStorage.
- Adds a save summary/load UI and stores the current/next campaign mission, completion IDs and cash locally. Saves are per-device WebView storage, not cloud saves.
- Corrects the Three.js local-forward-axis mismatch between vehicle yaw and world-space translation. The car's forward axis is local -Z, so turning and translation now use the same sign convention.
- Enlarges the bounded free-roam district and adds an industrial port edge with warehouses, containers and crane silhouettes.
- Adds a missing-safe audio-effect hook and an explicit manifest. No separate SFX or compatible character animation clips were supplied; the project still uses procedural low-poly character meshes and cannot honestly claim mocap/skeletal fight animation or a complete soundscape.
- `www/assets/audio/manifest.json` documents the source and rights caveat for the supplied main-menu theme. Developer must confirm publication/commercial rights.

### Limitations to verify on device
The project is a Three.js/Capacitor prototype, not a full GTA-scale game. The expanded environment still uses lightweight procedural geometry and has only basic rectangular Free Roam collision footprints; it does not include a complete collision mesh for every prop, traffic vehicle or story set. It has no full skeletal player rig or supplied compatible melee animation clips. Weapon/impact sounds are synthesized in the browser because there is no dedicated SFX pack. The online map requires connectivity and does not yet align the 3D road graph with real OSM roads. Static checks cannot validate driving feel, aiming or touch response; those still need on-device play testing.
