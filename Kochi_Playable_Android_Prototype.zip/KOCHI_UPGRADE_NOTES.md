KOCHI: HOMECOMING — UI/CONTROL PASS (v0.3.0)

Implemented in this source package:
- Revised mobile HUD styling inspired by the supplied GTA-style reference: custom outlined controls rather than emoji buttons.
- Hold-to-sprint on foot in Free Roam.
- Vehicle speed display and a prototype fuel meter while driving in Free Roam.
- Camera perspective toggle (first-person-like close camera / third-person chase camera).
- In-game phone overlay with links to the real street map, mission board and side jobs; save app explains checkpoint autosave status.
- Main-menu version label.
- Additional temporary hair/moustache detail on the procedural Vivek model.
- Existing MapLibre/OpenStreetMap raster map retained, centered around Kochi with touch pan/zoom/rotation and approximate game position.

Limitations — NOT implemented by this pass:
- The 3D district is still procedural and does not line up with OSM roads. This is not a full detailed 3D Kochi reconstruction.
- The first-person camera is a close follow camera, not a true vehicle cockpit/interior.
- The current drivable vehicle is still the sedan. Bikes, scooters, buses, auto-rickshaws, metro stations/train, accessible building interiors, cinema with licensed playable movie content, advanced NPC AI, realistic enter/exit animations, and a fully rigged realistic Vivek character require real models, animation assets and further gameplay work.
- Audio assets and game sounds still need on-device verification. External OSM map tiles require internet access and should follow OpenStreetMap tile usage policy.
- No APK has been built or device-tested from this package in this pass.
