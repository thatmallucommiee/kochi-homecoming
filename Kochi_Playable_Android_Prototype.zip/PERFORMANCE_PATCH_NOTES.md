# KOCHI: HOMECOMING mobile performance patch

This patch targets the lag visible on mid-range Android WebView devices.

Changes in `www/game.js`:
- Disabled realtime shadow-map rendering (a major mobile GPU cost).
- Disabled WebGL antialiasing and capped default device pixel ratio at 1.0.
- Reduced generated texture noise work at startup.
- Reduced procedural mapped-building instances from 14,000 to 5,500.
- Reduced facade window instances from 23,000 to 6,500.
- Reduced natural polygon meshes from 800 to 220, trees from 900 to 320, hedges from 1,500 to 420, and pet spawn candidates from 90 to 45.
- Capped texture anisotropy at 2.
- Kept the offline OpenStreetMap geometry and gameplay systems; this is a performance tradeoff, not a visual-fidelity claim.

Checks performed:
- `node --input-type=module --check < www/game.js`
- `node --check www/audio.js`
- `python3 -m py_compile scripts/fetch_kochi_map.py`
- ZIP integrity check after packaging.

Not yet verified:
- Real-time FPS, heat, battery drain, and gameplay on a physical Poco X7 5G.
- Runtime correctness of all controls and the full city.

Build the APK through the repository workflow and test on device. The workflow downloads/builds the map during CI; the installed game is intended to use packaged map data offline.
