# Kochi: Homecoming — Android playable prototype

This is a phone-first **Three.js + Capacitor** prototype, not an Unreal Engine project. It now contains two separate playable slices: Abraham's rainy prologue drive with an unidentified vehicle following him, and Rafi's garage introduction with a short hand-to-hand confrontation against an aggressive customer.

## Controls (landscape)

### Abraham — driving / chase
- **◀ / ▶**: steer left / right (hold)
- **ACCELERATE**: hold to gain speed
- **BRAKE**: hold to slow down; the scripted brake failure later overrides normal braking
- **Camera**: drag on open gameplay space, away from buttons, to orbit
- **Keyboard alternative**: Left/Right arrows to steer, W/Up to accelerate, S/Down or Space to brake

### Vivek — roadside aftermath
- **▲ / ▼ / ◀ / ▶ D-pad**: move around the roadside
- **INSPECT WRECK**: inspect when close enough
- **Camera**: drag on open gameplay space
- **Keyboard alternative**: W/A/S/D or arrow keys to move, E to inspect

### Rafi — garage fight
- **D-pad**: move Rafi
- **PUNCH**: tap to counter when close to the customer
- **BLOCK**: press and hold to reduce incoming damage
- **DODGE**: tap to evade an incoming swing
- **Camera**: drag on open gameplay space
- **Keyboard alternative**: J punch, hold K to block, L dodge
- After the customer backs off, tap **REPAIR JOB** to finish the introduction.

## Mission flow
1. Begin Prologue.
2. Drive through the rainy road. An unidentified vehicle appears behind Abraham; its identity and purpose are unknown.
3. The brake pedal fails as a separate scripted event. The game does not confirm that the following vehicle caused the failure.
4. After the crash, choose **CONTINUE TO THE WRECK** for the roadside aftermath or **PLAY RAFI'S DAY** to play Rafi's garage introduction.
5. Rafi's customer fight is a grounded encounter and is not presented as connected to Abraham's death.

## Important limitations
- This is an early procedural prototype with placeholder geometry and placeholder character bodies; it is not a finished open world.
- The customer confrontation uses simple distance-based combat, not motion-captured fight animation.
- The chase uses an anonymous placeholder car. No identity, motive, or link to the accident is established.
- The current Abraham GLB is preserved but hidden because it is not a verified faithful, rigged character asset.
- JavaScript syntax has been checked locally; Android compilation and on-device gameplay still need to be verified by GitHub Actions and tested on the Poco X7 5G.

## Build
Upload this archive to the repository root with the exact filename `Kochi_Playable_Android_Prototype.zip`. The existing GitHub Actions workflow should build the Android debug APK artifact `Kochi-Homecoming-APK`.


## NPC and mission update
- Prologue chase now uses three anonymous pursuing vehicles; their identity and purpose remain unknown.
- Roadside bystanders appear during the morning-after wreck exploration.
- Rafi's Day retains the aggressive-customer fight.
- Optional Side Mission: Roadside Assistance lets the player walk to a stranded driver and interact using HELP DRIVER.
- Controls: driving uses left/right, ACCELERATE, BRAKE, REVERSE; on-foot movement uses the D-pad; Rafi's fight uses PUNCH, BLOCK (hold), and DODGE; E activates the current interaction on keyboard.
- These remain low-poly prototype NPCs, not final animated character assets.
